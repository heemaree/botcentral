# Quick Deploy to mc-node - BotCentral

## Essential Steps:

### 1. Download Files
✅ **botcentral-deployment.tar.gz** is ready to download

### 2. Upload to mc-node
- Upload the tar.gz file to your mc-node hosting
- Extract: `tar -xzf botcentral-deployment.tar.gz`
- Enter directory: `cd deployment-package`

### 3. Configure Environment
Copy and edit the environment file:
```bash
cp .env.example .env
nano .env  # or your preferred editor
```

**Required settings:**
```env
DATABASE_URL=your_postgresql_url
DISCORD_CLIENT_ID=1389008016367685723
DISCORD_CLIENT_SECRET=your_secret_here
SESSION_SECRET=generate_random_string
NODE_ENV=production
PORT=3000
REPLIT_DOMAINS=yourdomain.com
```

### 4. Install and Build
```bash
npm install
npm run build
```

### 5. Update Discord App Settings
In Discord Developer Portal:
- Go to OAuth2 → Redirects
- Add: `https://yourdomain.com/api/discord/callback`
- Remove old Replit URLs

### 6. Start Application
```bash
npm start
```

## Database Options:

**Option A: Use existing Neon database**
- Keep your current `DATABASE_URL`
- No data migration needed

**Option B: New database**
- Set up new PostgreSQL on mc-node
- Update `DATABASE_URL`
- Run: `npm run db:push`

## Testing:
- Visit: `https://yourdomain.com` (should show landing page)
- Test login and Discord connection
- Verify premium features work

## Support:
Your BotCentral platform includes:
- ✅ Discord OAuth integration
- ✅ Premium features (Channel Stats, Booster Announcements)
- ✅ Personal access tokens
- ✅ Complete bot management system
- ✅ Community features (polls, events, leaderboards)

All features are production-ready!