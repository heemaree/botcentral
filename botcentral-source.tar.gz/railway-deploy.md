# Deploy BotCentral to Railway.app

## Quick Setup (5 minutes):

1. Go to [railway.app](https://railway.app)
2. Sign up with GitHub
3. Click "Deploy from GitHub repo"
4. Connect this repository

## Environment Variables:
Add these in Railway dashboard:

```
DATABASE_URL=your_neon_database_url
DISCORD_CLIENT_ID=1389008016367685723
DISCORD_CLIENT_SECRET=your_discord_secret
SESSION_SECRET=your_random_string_here
REPLIT_DOMAINS=your-app-name.up.railway.app
```

## Automatic Deployment:
Railway will:
- Install dependencies automatically
- Build the project
- Start the server
- Provide a public URL

## Benefits:
- No SSH needed
- Instant deployment
- Free tier available
- Automatic SSL certificates
- Easy domain setup

Your BotCentral will be live in minutes!