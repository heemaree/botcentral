# BotCentral Management Hub

## Overview

BotCentral is a comprehensive Discord bot management platform built with a modern full-stack architecture. The application provides users with tools to create, manage, and monitor Discord bots, organize community events, track analytics, and manage user leaderboards. The platform features a gaming-themed UI designed specifically for Discord communities.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management
- **UI Components**: Radix UI primitives with custom shadcn/ui components
- **Styling**: Tailwind CSS with custom gaming theme variables
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Authentication**: Replit OIDC integration with Passport.js
- **Session Management**: Express sessions with PostgreSQL store

### Database Schema Design
The application uses a relational database structure with the following core entities:
- **Users**: Stores user profile information from Replit OIDC
- **Bots**: Discord bot configurations and metadata
- **Events**: Community events and tournaments
- **Announcements**: Community announcements and updates
- **Activity Logs**: System activity tracking
- **Leaderboard Entries**: User rankings and statistics
- **Sessions**: User session storage for authentication

## Key Components

### Authentication System
- Uses Replit's OIDC provider for seamless authentication
- Session-based authentication with PostgreSQL session store
- Protected routes with middleware validation
- User profile management with Discord integration

### Bot Management
- Create and configure Discord bots
- Monitor bot status (online/offline/idle)
- Track server count and user engagement
- Bot token management and security

### Community Features
- Event creation and management
- Community announcements
- User leaderboards and rankings
- Activity logging and monitoring

### Analytics Dashboard
- Real-time bot statistics
- Server growth tracking
- User engagement metrics
- Command usage analytics

## Data Flow

1. **Authentication Flow**:
   - User authenticates via Replit OIDC
   - Session created and stored in PostgreSQL
   - User profile synchronized with database
   - Protected routes accessible after authentication

2. **Bot Management Flow**:
   - User creates bot configuration
   - Bot data stored with owner relationship
   - Real-time status monitoring
   - Activity logging for all bot actions

3. **Event Management Flow**:
   - Community events created and managed
   - Attendance tracking and management
   - Integration with leaderboard system

## External Dependencies

### Core Technologies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management and caching
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

### UI Framework
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **react-hook-form**: Form state management
- **zod**: Schema validation

### Development Tools
- **vite**: Build tool and dev server
- **typescript**: Type safety and developer experience
- **tsx**: TypeScript execution for development

## Deployment Strategy

### Development Environment
- Vite dev server for frontend with HMR
- Express server with TypeScript compilation via tsx
- Database migrations managed by Drizzle Kit
- Replit-specific development tooling integration

### Production Build
- Frontend built with Vite and served as static files
- Backend compiled with esbuild for Node.js runtime
- Environment variables for database and authentication
- Session-based authentication with secure cookies

### Database Management
- PostgreSQL database provisioned via Neon
- Schema managed through Drizzle migrations
- Connection pooling for performance
- Automated table creation for sessions

## Changelog

```
Changelog:
- June 28, 2025. Initial setup and full platform development
- June 28, 2025. Fixed CSS styling issues and implemented consistent dark gaming theme
- June 28, 2025. Successfully deployed complete BotForge platform with user authentication
- June 28, 2025. Added comprehensive moderation system with user roles, content filters, reports, and moderation logs
- June 28, 2025. Rebranded platform from "BotForge" to "BotCentral" per user request
- June 28, 2025. Implemented standard Discord bot with subscription system (free/premium tiers)
- June 28, 2025. Added bot features database with 12 pre-configured features for free and premium users
- June 28, 2025. Created subscription management system ready for Stripe integration when API keys are provided
- June 28, 2025. Updated Discord bot features: removed slash commands, clarified basic moderation, limited reaction roles to 3 embeds for free tier
- June 28, 2025. Added custom bot token feature for personalized bot names and profile pictures (premium)
- June 28, 2025. Implemented scheduled messages with time scheduling options (premium)
- June 28, 2025. Updated pricing: monthly plan now $12.99, yearly remains $99
- June 28, 2025. Renamed navigation: "Standard Bot" to "Premium Plan", "Bot Management" to "Customized Bot"
- June 28, 2025. Added database tables for user custom bots and scheduled messages
- June 28, 2025. Updated Premium Plan logo to use custom BotCentral brand image
- June 28, 2025. Changed navigation URL from /standard-bot to /premium-plan (with backward compatibility)
- June 28, 2025. Added Channel Statistics Configuration section with voice channel (recommended), text channel, and category options
- June 28, 2025. Added Booster Announcements section with Discord embed preview, customizable colors, messages, and configuration options
- June 28, 2025. Moved Channel Statistics Configuration and Booster Announcements sections to Dashboard (home page) for better accessibility
- June 28, 2025. Enhanced Booster Announcements with customizable embed title, description, user ping message (outside embed), and separate configuration fields
- June 28, 2025. Removed Channel Statistics and Booster Announcements sections from Premium Plan page (moved to Dashboard)
- June 28, 2025. Implemented subscription-based server selection system - premium features limited to one Discord server per subscription
- June 28, 2025. Added premium feature notifications in Dashboard components requiring server selection in Premium Plan section
- June 28, 2025. Implemented premium feature preview functionality - users can see disabled but functional interfaces of Channel Statistics and Booster Announcements before purchasing
- June 28, 2025. Added "Get Premium Access" buttons in Dashboard components directing users to Premium Plan page for subscription
- June 28, 2025. Restructured Dashboard layout: removed Quick Actions component, moved System Status to full-width section, moved Upcoming Events component to Events page
- June 28, 2025. Reorganized navigation flow - Upcoming Events now appears at top of Events page for better user experience
- June 28, 2025. Created dedicated "Premium Features" section on Dashboard with Channel Statistics and Booster Announcements in 2-column grid layout
- June 28, 2025. Added "Free Features" section to Dashboard with Custom Embeds and Reaction Roles components (3 embeds limit each)
- June 28, 2025. Organized Dashboard into clean categories: "Free Features" (Custom Embeds, Reaction Roles) and "Premium Features" (Channel Statistics, Booster Announcements)
- June 28, 2025. Updated Reaction Roles to be a free feature with 3-embed limit instead of premium feature
- June 28, 2025. Added "Community Management" category with Events Overview and Polls Overview components
- June 28, 2025. Added "Server Management" category with Moderation Overview and Rewards Overview components
- June 28, 2025. Added "Premium Plans" category with Premium Plan and Personalized Bot management cards
- June 28, 2025. Renamed "Customized Bot" to "Personalized Bot" throughout the application and navigation
- June 28, 2025. Complete Dashboard reorganization into 5 categories: Free Features, Community Management, Server Management, Premium Features, and Premium Plans
- June 28, 2025. Major navigation restructure: moved from Dashboard categories to individual dedicated pages
- June 28, 2025. Created separate pages for Custom Embeds and Reaction Roles with dedicated interfaces
- June 28, 2025. Renamed "Server Management" to "Moderation" throughout the application
- June 28, 2025. Implemented categorized sidebar navigation with sections: Free Tools, Community, Management, and Premium
- June 28, 2025. Added subscription status display to Premium Plans page showing current user subscription tier and bot statistics
- June 28, 2025. Removed "Free Tools" category and moved Custom Embeds and Reaction Roles to Community section
- June 28, 2025. Added new Tickets section under Community with ticket panel creation functionality
- June 28, 2025. Implemented ticket system with thread permissions as premium feature - visible to all users but thread creation requires premium subscription
- June 28, 2025. Reorganized sidebar navigation: Dashboard, Community (Custom Embeds, Reaction Roles, Community Hub, Events, Polls, Leaderboards, Tickets), Management, Premium
- June 28, 2025. Enhanced Custom Embeds with user tagging functionality - users can be mentioned in embeds and appear as clickable profile links
- June 28, 2025. Added interactive user tag management system with quick insert buttons and visual mention highlighting in embed previews
- June 28, 2025. Updated Leaderboards system: changed "events" to "inviters", "engagement" to track most messages sent, added "levels" leaderboard for most XP
- June 28, 2025. Added comprehensive announcement system under Leaderboards with custom embed creation and user tagging functionality
- June 28, 2025. Restructured leaderboard categories: Inviters, Engagement (most messages), Levels (most XP), and Messages for better community tracking
- June 29, 2025. Created new "Rewards" category with comprehensive reward system including level rewards, message rewards, and invite rewards
- June 29, 2025. Added Rewards page with 5 tabs: Level System, Message Rewards, Invite Rewards, Leaderboards, and Setup
- June 29, 2025. Implemented custom announcement messages and channel selection for reward notifications
- June 29, 2025. Moved Leaderboards under Rewards category in sidebar navigation for better organization
- June 29, 2025. Added comprehensive color picker system with basic colors and custom hex input functionality
- June 29, 2025. Implemented global color settings in Settings page allowing users to apply one color across all embed systems
- June 29, 2025. Created automatic white embed titles as default with premium title color customization feature
- June 29, 2025. Added premium-only custom title color functionality - all titles are white by default but can be customized with premium subscription
- June 29, 2025. Reorganized sidebar navigation: moved Management category above Community, relocated Events/Tickets/Polls to Management, moved Discord Settings to Other category
- June 29, 2025. Updated navigation structure: moved Analytics from Management to Other category
- June 29, 2025. Added custom scrollbar functionality to sidebar navigation with hover effects and smooth scrolling
- June 29, 2025. Added Channel Statistics Configuration to Community section with comprehensive server stats display options
- June 29, 2025. Created Booster Announcements feature in Premium section with customizable embed announcements for server boosters
- June 29, 2025. Both new features include premium upgrade prompts and are properly categorized in navigation structure
- June 29, 2025. Fixed sidebar navigation visibility - moved Booster Announcements to Premium section and ensured sidebar remains visible across all pages
- June 29, 2025. Reorganized Channel Statistics as "Server Stats" under Management section for better categorization and user accessibility
- June 29, 2025. Created comprehensive Bot Setup page showing standard bot configuration for all users
- June 29, 2025. Maintained premium-only custom bot token configuration - free users use standard BotCentral bot, premium users can configure their own Discord application
- June 29, 2025. Added proper onboarding flow: users add standard bot to access free features, upgrade to premium for custom bot tokens
- June 29, 2025. Implemented clear feature distinction: standard bot for free users, custom bot tokens as premium feature
- June 29, 2025. Added Bot Setup section to sidebar navigation for easy access to bot invitation and feature overview
- June 29, 2025. Fixed bot name from "BotCentral Bot" to "BotCentral" in database configuration
- June 29, 2025. Implemented personalized bot configuration wizard with smart recommendations based on server type
- June 29, 2025. Added 4-step wizard: Server Type Selection, Feature Selection with smart recommendations, Bot Customization, Review & Deploy
- June 29, 2025. Created 6 server types (Gaming, Business, Community, Support, Education, Creative) with tailored feature recommendations
- June 29, 2025. Implemented intelligent feature categorization and premium feature detection with upgrade prompts
- June 29, 2025. Removed "Personalized Bots" section from sidebar navigation per user request
- June 29, 2025. Moved Bot Setup from sidebar to home page (Dashboard) as primary feature
- June 29, 2025. Created comprehensive Bot Setup dashboard component with free and premium bot options, setup guide, and direct integration links
- June 29, 2025. Deleted bot wizard functionality per user request - removed wizard files, routes, and references
- June 29, 2025. Removed "Bot Wizard" from Premium section in sidebar navigation
- June 29, 2025. Deleted premium-features.tsx page and removed from navigation and routing
- June 29, 2025. Successfully deployed Discord bot with Python (discord.py) on user's mc-node hosting service
- June 29, 2025. Fixed command conflict by changing !bc help to !bc commands - bot now online and functional
- June 29, 2025. Bot ready for testing with commands: !bc commands, !bc stats, !bc embed, !bc reaction, !bc warn, !bc clear
- June 29, 2025. Successfully implemented elegant personal dashboard URL generator with access token authentication
- June 29, 2025. Added Personal Access Tokens management system in Settings page with premium permissions
- June 29, 2025. Created secure token-based dashboard access with custom URLs and premium feature enablement
- June 29, 2025. Fixed API request parameter order issue for token creation functionality
- June 29, 2025. Successfully deployed complete personal access token authentication system with premium features
- June 29, 2025. Fixed subscription endpoint to properly detect token-based premium permissions
- June 29, 2025. All premium features (Booster Announcements, Server Stats) now fully functional with personal access tokens
- June 29, 2025. Personal dashboard URLs with premium access confirmed working - ready for Discord server integration
- June 29, 2025. Successfully implemented complete Discord OAuth2 integration with real server connections
- June 29, 2025. Fixed Discord application configuration and redirect URI issues for seamless authentication
- June 29, 2025. Discord connection now fully operational - users can connect Discord accounts and access real server data
- June 29, 2025. Premium features can now be tested with actual Discord servers for complete functionality validation
- June 29, 2025. Fixed Discord disconnect functionality - resolved API parameter order issue and improved database cleanup process
- June 29, 2025. Discord OAuth integration fully tested and working - disconnect/reconnect cycle operational
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```