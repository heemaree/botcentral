import { Link, useLocation } from "wouter";
import { FaTachometerAlt, FaRobot, FaUsers, FaCalendarAlt, FaTrophy, FaChartLine, FaCog, FaDiscord, FaUser, FaPoll, FaUserShield, FaGift, FaCrown, FaTicketAlt, FaCode, FaUserTag, FaHome, FaChartBar, FaShieldAlt, FaGem, FaComments, FaUserPlus, FaLevelUpAlt, FaMagic } from "react-icons/fa";
import { useAuth } from "@/hooks/useAuth";
import logoImage from "@assets/Workflows_1751144604247.png";

const navigationSections = [
  {
    category: "Dashboard",
    items: [
      { name: "Home", href: "/", icon: FaHome },
    ]
  },

  {
    category: "Premium",
    items: [
      { name: "Premium Plans", href: "/premium-plans", icon: FaGem },
      { name: "Booster Announcements", href: "/booster-announcements", icon: FaGift },
    ]
  },
  {
    category: "Management", 
    items: [
      { name: "Events", href: "/events", icon: FaCalendarAlt },
      { name: "Tickets", href: "/tickets", icon: FaTicketAlt },
      { name: "Polls", href: "/polls", icon: FaPoll },
      { name: "Server Stats", href: "/channel-stats", icon: FaChartLine },
      { name: "Moderation", href: "/moderation", icon: FaShieldAlt },
    ]
  },
  {
    category: "Community",
    items: [
      { name: "Custom Embeds", href: "/custom-embeds", icon: FaCode },
      { name: "Reaction Roles", href: "/reaction-roles", icon: FaUserTag },
      { name: "Community Hub", href: "/community", icon: FaUsers },
    ]
  },
  {
    category: "Rewards",
    items: [
      { name: "Level System", href: "/level-system", icon: FaLevelUpAlt },
      { name: "Message Rewards", href: "/message-rewards", icon: FaComments },
      { name: "Invite Rewards", href: "/invite-rewards", icon: FaUserPlus },
      { name: "Leaderboards", href: "/leaderboards", icon: FaTrophy },
    ]
  },
  {
    category: "Other",
    items: [
      { name: "Analytics", href: "/analytics", icon: FaChartBar },
      { name: "Discord Settings", href: "/discord", icon: FaDiscord },
      { name: "Discord Connection", href: "/discord-settings", icon: FaDiscord },
      { name: "Settings", href: "/settings", icon: FaCog },
    ]
  }
];

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  return (
    <div className="w-64 bg-[hsl(230,10%,12%)] border-r border-[hsl(30,3%,22%)] flex flex-col">
      {/* Logo & Brand */}
      <div className="p-6 border-b border-[hsl(30,3%,22%)]">
        <div className="flex items-center space-x-3">
          <img 
            src={logoImage} 
            alt="BotCentral Logo" 
            className="w-12 h-12 object-contain"
          />
          <div>
            <h1 className="text-xl font-bold text-white">BotCentral</h1>
            <p className="text-gray-400 text-sm">Management Hub</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-4 overflow-y-auto custom-scrollbar">
        {navigationSections.map((section) => (
          <div key={section.category}>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 px-4">
              {section.category}
            </h3>
            <div className="space-y-1">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href || 
                  (item.href !== "/" && location.startsWith(item.href));
                
                return (
                  <Link key={item.name} href={item.href} className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                    isActive 
                      ? "bg-[hsl(var(--discord-primary))] text-white" 
                      : "text-gray-300 hover:bg-[hsl(var(--gaming-hover))] hover:text-white"
                  }`}>
                    <Icon className="text-lg" />
                    <span>{item.name}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-[hsl(var(--gaming-border))]">
        <div className="flex items-center space-x-3 p-3 rounded-lg bg-[hsl(var(--gaming-hover))]">
          <div className="w-10 h-10 rounded-full overflow-hidden bg-[hsl(var(--discord-primary))]/20 flex items-center justify-center">
            {user?.profileImageUrl ? (
              <img 
                src={user.profileImageUrl} 
                alt="User avatar" 
                className="w-10 h-10 rounded-full object-cover" 
              />
            ) : (
              <FaUser className="text-[hsl(var(--discord-primary))]" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">
              {user?.firstName && user?.lastName 
                ? `${user.firstName} ${user.lastName}` 
                : user?.email?.split('@')[0] || "User"}
            </p>
            <p className="text-xs text-gray-400 truncate">
              {user?.email?.includes('@') ? `@${user.email.split('@')[0]}` : "@user"}
            </p>
          </div>
          <div className="w-3 h-3 bg-[hsl(var(--status-online))] rounded-full"></div>
        </div>
      </div>
    </div>
  );
}
