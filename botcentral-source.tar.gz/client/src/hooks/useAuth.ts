import { useQuery } from "@tanstack/react-query";

// Helper function to get token from URL parameters
function getTokenFromUrl(): string | null {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get('token');
}

export function useAuth() {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  const token = getTokenFromUrl();
  const hasTokenAccess = !!token;

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    hasTokenAccess,
    token,
  };
}
