import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { FaPlus, FaDiscord, FaEdit, FaTrash, FaCheck, FaTimes, FaCopy } from "react-icons/fa";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertDiscordChannelSchema, type DiscordChannel, type InsertDiscordChannel } from "@shared/schema";

const createChannelSchema = insertDiscordChannelSchema.extend({
  webhookUrl: z.string().url("Must be a valid webhook URL").optional().or(z.literal("")),
});

const updateChannelSchema = createChannelSchema.partial().extend({
  isActive: z.boolean().optional(),
});

type CreateChannelForm = z.infer<typeof createChannelSchema>;
type UpdateChannelForm = z.infer<typeof updateChannelSchema>;

export default function DiscordSettings() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Form setup
  const form = useForm<CreateChannelForm>({
    resolver: zodResolver(createChannelSchema),
    defaultValues: {
      guildId: "",
      channelId: "",
      channelName: "",
      channelType: "polls",
      webhookUrl: "",
      isActive: true,
    },
  });

  // Queries
  const { data: channels, isLoading: channelsLoading } = useQuery({
    queryKey: ['/api/discord/channels'],
    enabled: isAuthenticated,
  });

  // Mutations
  const createChannelMutation = useMutation({
    mutationFn: async (channelData: CreateChannelForm) => {
      return apiRequest('/api/discord/channels', 'POST', channelData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/discord/channels'] });
      toast({
        title: "Success",
        description: "Discord channel configured successfully!",
      });
      setIsCreateDialogOpen(false);
      form.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to configure Discord channel. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateChannelMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<UpdateChannelForm>) => {
      return apiRequest(`/api/discord/channels/${id}`, 'PUT', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/discord/channels'] });
      toast({
        title: "Success",
        description: "Discord channel updated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update Discord channel.",
        variant: "destructive",
      });
    },
  });

  const deleteChannelMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/discord/channels/${id}`, 'DELETE');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/discord/channels'] });
      toast({
        title: "Success",
        description: "Discord channel removed successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to remove Discord channel.",
        variant: "destructive",
      });
    },
  });

  // Handlers
  const onSubmit = (data: CreateChannelForm) => {
    createChannelMutation.mutate(data);
  };

  const toggleChannelStatus = (id: number, isActive: boolean) => {
    updateChannelMutation.mutate({ id, isActive: !isActive });
  };

  const copyWebhookExample = () => {
    const example = "https://discord.com/api/webhooks/123456789012345678/AbCdEfGhIjKlMnOpQrStUvWxYz";
    navigator.clipboard.writeText(example);
    toast({
      title: "Copied",
      description: "Example webhook URL copied to clipboard!",
    });
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const channelTypes = [
    { value: "polls", label: "Polls & Voting", description: "Automatically post new polls" },
    { value: "announcements", label: "Announcements", description: "Community announcements" },
    { value: "events", label: "Events", description: "Event notifications" },
    { value: "general", label: "General", description: "Other notifications" },
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Discord Integration" subtitle="Configure Discord channels and webhooks" />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Top Controls */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div className="text-gray-300">
              <h2 className="text-lg font-semibold">Discord Channels</h2>
              <p className="text-sm text-gray-500">Configure where your content gets posted in Discord</p>
            </div>

            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white">
                  <FaPlus className="mr-2" />
                  Add Discord Channel
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="text-xl font-semibold text-white flex items-center">
                    <FaDiscord className="mr-2 text-[#5865F2]" />
                    Configure Discord Channel
                  </DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Set up Discord channel integration for your server. Configure webhooks and channel settings.
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="guildId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-200">Server (Guild) ID</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="123456789012345678"
                                {...field}
                                className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                              />
                            </FormControl>
                            <p className="text-xs text-gray-500">Your Discord server ID</p>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="channelId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-200">Channel ID</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="123456789012345678"
                                {...field}
                                className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                              />
                            </FormControl>
                            <p className="text-xs text-gray-500">Target Discord channel ID</p>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="channelName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-200">Channel Name</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="polls"
                                {...field}
                                className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                              />
                            </FormControl>
                            <p className="text-xs text-gray-500">Display name for the channel</p>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="channelType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-200">Content Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                  <SelectValue placeholder="Select content type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                {channelTypes.map((type) => (
                                  <SelectItem key={type.value} value={type.value}>
                                    <div>
                                      <div className="font-medium">{type.label}</div>
                                      <div className="text-xs text-gray-400">{type.description}</div>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="webhookUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-200 flex items-center gap-2">
                            Webhook URL (Optional)
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={copyWebhookExample}
                              className="h-6 px-2 text-xs text-[hsl(235,86%,65%)]"
                            >
                              <FaCopy className="mr-1" /> Example
                            </Button>
                          </FormLabel>
                          <FormControl>
                            <Input
                              placeholder="https://discord.com/api/webhooks/..."
                              {...field}
                              className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                            />
                          </FormControl>
                          <p className="text-xs text-gray-500">
                            Discord webhook URL for posting content. Create one in your Discord channel settings.
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-end gap-3 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsCreateDialogOpen(false)}
                        className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={createChannelMutation.isPending}
                        className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                      >
                        {createChannelMutation.isPending ? "Configuring..." : "Configure Channel"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Channels Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {channelsLoading ? (
              // Loading skeleton
              Array.from({ length: 4 }, (_, i) => (
                <Card key={i} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                  <CardHeader>
                    <div className="h-6 bg-[hsl(237,71%,7%)] rounded animate-pulse"></div>
                    <div className="h-4 bg-[hsl(237,71%,7%)] rounded w-2/3 animate-pulse"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {Array.from({ length: 2 }, (_, j) => (
                        <div key={j} className="h-4 bg-[hsl(237,71%,7%)] rounded animate-pulse"></div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              (channels as any[])?.map((channel: any) => (
                <Card key={channel.id} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-white text-lg font-semibold mb-2 flex items-center gap-2">
                          <FaDiscord className="text-[#5865F2]" />
                          #{channel.channelName}
                        </CardTitle>
                        <div className="flex gap-2 mb-2">
                          <Badge 
                            variant="outline" 
                            className="border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)]"
                          >
                            {channelTypes.find(t => t.value === channel.channelType)?.label || channel.channelType}
                          </Badge>
                          <Badge 
                            variant="outline" 
                            className={channel.isActive ? "border-green-500 text-green-500" : "border-red-500 text-red-500"}
                          >
                            {channel.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleChannelStatus(channel.id, channel.isActive)}
                          className={channel.isActive ? "text-red-400 hover:text-red-300" : "text-green-400 hover:text-green-300"}
                        >
                          {channel.isActive ? <FaTimes /> : <FaCheck />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteChannelMutation.mutate(channel.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-2 text-sm text-gray-400">
                      <div><strong>Server ID:</strong> {channel.guildId}</div>
                      <div><strong>Channel ID:</strong> {channel.channelId}</div>
                      {channel.webhookUrl && (
                        <div><strong>Webhook:</strong> Configured ✓</div>
                      )}
                      <div className="text-xs text-gray-500 mt-3">
                        {channelTypes.find(t => t.value === channel.channelType)?.description}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )) || []
            )}
          </div>

          {channels && (channels as any[]).length === 0 && (
            <div className="text-center py-16">
              <FaDiscord className="mx-auto text-6xl text-gray-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-300 mb-2">No Discord channels configured</h3>
              <p className="text-gray-500 mb-6">Add your first Discord channel to start posting content automatically!</p>
              <Button 
                onClick={() => setIsCreateDialogOpen(true)}
                className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
              >
                <FaPlus className="mr-2" />
                Configure First Channel
              </Button>
            </div>
          )}

          {/* Help Section */}
          <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] mt-8">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <FaDiscord className="text-[#5865F2]" />
                How to Set Up Discord Integration
              </CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300 space-y-4">
              <div>
                <h4 className="font-semibold mb-2">1. Get Discord IDs</h4>
                <p className="text-sm text-gray-400">
                  Enable Developer Mode in Discord (User Settings → Advanced → Developer Mode), then right-click your server and channel to copy their IDs.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">2. Create a Webhook (Optional)</h4>
                <p className="text-sm text-gray-400">
                  In your Discord channel, go to Settings → Integrations → Webhooks → New Webhook. Copy the webhook URL for enhanced message formatting.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">3. Configure Channel Types</h4>
                <p className="text-sm text-gray-400">
                  Set up different channels for different content types (polls, announcements, events) to keep your Discord organized.
                </p>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}