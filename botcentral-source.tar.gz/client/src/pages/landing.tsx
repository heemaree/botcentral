import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FaDiscord, FaRobot, FaUsers, FaCalendarAlt, FaTrophy, FaChartLine } from "react-icons/fa";
import logoImage from "@assets/Workflows_1751144604247.png";

export default function Landing() {
  return (
    <div className="min-h-screen bg-[hsl(237,71%,7%)] text-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[hsl(235,86%,65%)] via-transparent to-[hsl(258,84%,67%)] opacity-20"></div>
        <div className="relative container mx-auto px-6 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <div className="flex items-center justify-center mb-8">
              <img 
                src={logoImage} 
                alt="BotCentral Logo" 
                className="w-20 h-20 object-contain"
              />
            </div>
            <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent">
              BotCentral
            </h1>
            <p className="text-2xl text-gray-300 mb-4">Management Hub</p>
            <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto">
              The ultimate platform for Discord bot management, community building, and gaming experiences. 
              Create, manage, and scale your Discord presence with ease.
            </p>
            <Button
              onClick={() => window.location.href = '/api/login'}
              className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white px-8 py-4 text-lg rounded-xl glow-effect transition-all duration-300"
            >
              <FaDiscord className="mr-3" />
              Sign in with Discord
            </Button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Powerful Features</h2>
          <p className="text-xl text-gray-400">Everything you need to manage your Discord community</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all duration-300">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-[hsl(160,84%,39%)]/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                <FaRobot className="text-3xl text-[hsl(160,84%,39%)]" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Bot Management</h3>
              <p className="text-gray-400">
                Create, configure, and monitor multiple Discord bots from a single dashboard. 
                Real-time status updates and comprehensive logging.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all duration-300">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-[hsl(258,84%,67%)]/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                <FaUsers className="text-3xl text-[hsl(258,84%,67%)]" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Community Management</h3>
              <p className="text-gray-400">
                Manage your community with moderation tools, member insights, 
                and engagement analytics to grow your server.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all duration-300">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-[hsl(186,100%,50%)]/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                <FaCalendarAlt className="text-3xl text-[hsl(186,100%,50%)]" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Event Scheduling</h3>
              <p className="text-gray-400">
                Plan and organize community events, tournaments, and activities. 
                Automated reminders and RSVP tracking.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all duration-300">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-[hsl(43,96%,56%)]/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                <FaTrophy className="text-3xl text-[hsl(43,96%,56%)]" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Leaderboards</h3>
              <p className="text-gray-400">
                Track member activity and engagement with customizable leaderboards. 
                Gamify your community experience.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all duration-300">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-[hsl(235,86%,65%)]/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                <FaChartLine className="text-3xl text-[hsl(235,86%,65%)]" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Analytics & Insights</h3>
              <p className="text-gray-400">
                Detailed analytics on bot performance, user engagement, 
                and community growth trends.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all duration-300">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-[hsl(139,66%,42%)]/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                <FaRobot className="text-3xl text-[hsl(139,66%,42%)]" />
              </div>
              <h3 className="text-xl font-semibold mb-4">24/7 Uptime</h3>
              <p className="text-gray-400">
                Reliable hosting with 99.9% uptime guarantee. 
                Your bots stay online even when you're not.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="container mx-auto px-6 py-20">
        <Card className="gaming-card border-[hsl(var(--gaming-border))] overflow-hidden">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-[hsl(var(--discord-primary))]/10 to-[hsl(var(--gaming-purple))]/10"></div>
            <CardContent className="relative p-12 text-center">
              <h2 className="text-4xl font-bold mb-4">Ready to Get Started?</h2>
              <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
                Join thousands of Discord server owners who trust BotForge to power their communities.
              </p>
              <Button
                onClick={() => window.location.href = '/api/login'}
                className="bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))] text-white px-8 py-4 text-lg rounded-xl glow-effect transition-all duration-300"
              >
                <FaDiscord className="mr-3" />
                Start Building Today
              </Button>
            </CardContent>
          </div>
        </Card>
      </div>
    </div>
  );
}
