import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import logoImage from "@assets/Workflows_1751144604247.png";
import { 
  FaDiscord, 
  FaRobot, 
  FaChartLine, 
  FaCrown, 
  FaCheck, 
  FaPlus,
  FaStar,
  FaInfinity,
  FaRocket,
  FaEye,
  FaHashtag,
  FaSave,
  FaPlay,
  FaCog,
  FaKey,
  FaEdit
} from "react-icons/fa";
import { FaUserShield } from "react-icons/fa";

interface BotFeature {
  id: number;
  name: string;
  description: string;
  isPremium: boolean;
  category: string;
  isActive: boolean;
}

interface StandardBotConfig {
  id: number;
  name: string;
  clientId: string;
  token: string;
  isActive: boolean;
  version: string;
}

export default function StandardBot() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedTier, setSelectedTier] = useState<'free' | 'premium'>('free');
  const [botToken, setBotToken] = useState('');
  const [isEditingToken, setIsEditingToken] = useState(false);

  // Fetch bot features
  const { data: features = [], isLoading: featuresLoading } = useQuery<BotFeature[]>({
    queryKey: ['/api/bot-features'],
  });

  // Fetch standard bot config
  const { data: botConfig } = useQuery<StandardBotConfig>({
    queryKey: ['/api/standard-bot/config'],
  });

  // Fetch user's current subscription status
  const { data: subscription } = useQuery({
    queryKey: ['/api/user/subscription'],
  });

  const freeFeatures = features.filter(f => !f.isPremium && f.isActive);
  const premiumFeatures = features.filter(f => f.isPremium && f.isActive);

  const discordInviteUrl = botConfig?.clientId 
    ? `https://discord.com/api/oauth2/authorize?client_id=${botConfig.clientId}&permissions=8&scope=bot%20applications.commands`
    : '';

  const handleInviteBot = () => {
    if (!discordInviteUrl) {
      toast({
        title: "Error",
        description: "Bot configuration not available. Please try again later.",
        variant: "destructive",
      });
      return;
    }
    window.open(discordInviteUrl, '_blank');
  };

  const subscriptionMutation = useMutation({
    mutationFn: async (tier: 'monthly' | 'yearly') => {
      return apiRequest('POST', '/api/subscription/create', { tier });
    },
    onSuccess: (data) => {
      // Redirect to Stripe checkout
      if (data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
      }
    },
    onError: (error: any) => {
      toast({
        title: "Subscription Error",
        description: error.message || "Failed to create subscription",
        variant: "destructive",
      });
    },
  });

  const updateBotTokenMutation = useMutation({
    mutationFn: async (token: string) => {
      return apiRequest('POST', '/api/standard-bot/token', { token });
    },
    onSuccess: () => {
      toast({
        title: "Bot Token Updated",
        description: "The bot token has been successfully updated. Your bot is now ready for testing.",
        variant: "default",
      });
      setIsEditingToken(false);
      queryClient.invalidateQueries({ queryKey: ['/api/standard-bot/config'] });
    },
    onError: (error: any) => {
      toast({
        title: "Token Update Failed",
        description: error.message || "Failed to update bot token",
        variant: "destructive",
      });
    },
  });

  const handleSaveBotToken = () => {
    if (!botToken.trim()) {
      toast({
        title: "Invalid Token",
        description: "Please enter a valid bot token",
        variant: "destructive",
      });
      return;
    }
    updateBotTokenMutation.mutate(botToken);
  };

  // Load current bot token if available
  useEffect(() => {
    if (botConfig?.token) {
      setBotToken(botConfig.token);
    }
  }, [botConfig]);

  const isPremiumUser = user?.subscriptionTier?.includes('premium');

  return (
    <div className="min-h-screen bg-[hsl(237,71%,7%)] text-white">
      <div className="container mx-auto p-6 space-y-8">
        {/* Header Section */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center mb-4">
            <img 
              src={logoImage} 
              alt="BotCentral Logo" 
              className="w-24 h-24 object-contain"
            />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">BotCentral Premium Plan</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Add our feature-rich Discord bot to your server. Get started for free with essential Discord bot features, 
            or upgrade to premium for advanced moderation, analytics, custom automation, and your own custom bot token.
          </p>
        </div>

      {/* Bot Invite Section */}
      <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <FaDiscord className="mr-3 text-[hsl(235,86%,65%)]" />
            Add Bot to Your Server
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-400">
            Click the button below to invite BotCentral Bot to your Discord server. 
            You'll be redirected to Discord to select your server and configure permissions.
          </p>
          <Button
            onClick={handleInviteBot}
            disabled={!botConfig?.isActive}
            className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white px-6 py-3"
          >
            <FaPlus className="mr-2" />
            Add to Discord Server
          </Button>
          {botConfig && (
            <div className="text-sm text-gray-500">
              Bot Version: {botConfig.version} • Status: {botConfig.isActive ? 'Active' : 'Inactive'}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bot Token Configuration */}
      <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <FaKey className="mr-3 text-[hsl(235,86%,65%)]" />
            Bot Token Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-400">
            Configure your Discord bot token to enable testing of all premium features. 
            This allows you to test the bot functionality before subscribing.
          </p>
          
          <div className="space-y-3">
            <Label htmlFor="bot-token" className="text-white">Discord Bot Token</Label>
            <div className="flex space-x-2">
              <Input
                id="bot-token"
                type={isEditingToken ? "text" : "password"}
                value={botToken}
                onChange={(e) => setBotToken(e.target.value)}
                placeholder="Enter your Discord bot token..."
                disabled={!isEditingToken}
                className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
              />
              {!isEditingToken ? (
                <Button
                  onClick={() => setIsEditingToken(true)}
                  variant="outline"
                  className="border-[hsl(30,3%,22%)] text-white hover:bg-[hsl(230,10%,15%)]"
                >
                  <FaEdit className="mr-2" />
                  Edit
                </Button>
              ) : (
                <div className="flex space-x-2">
                  <Button
                    onClick={handleSaveBotToken}
                    disabled={updateBotTokenMutation.isPending}
                    className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                  >
                    <FaSave className="mr-2" />
                    {updateBotTokenMutation.isPending ? 'Saving...' : 'Save'}
                  </Button>
                  <Button
                    onClick={() => {
                      setIsEditingToken(false);
                      setBotToken(botConfig?.token || '');
                    }}
                    variant="outline"
                    className="border-[hsl(30,3%,22%)] text-white hover:bg-[hsl(230,10%,15%)]"
                  >
                    Cancel
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="bg-[hsl(237,71%,7%)] p-4 rounded-lg border border-[hsl(30,3%,22%)]">
            <h4 className="font-semibold text-white mb-2 flex items-center">
              <FaRobot className="mr-2 text-[hsl(235,86%,65%)]" />
              How to get your Discord Bot Token:
            </h4>
            <ol className="text-sm text-gray-300 space-y-2">
              <li>1. Go to <a href="https://discord.com/developers/applications" target="_blank" rel="noopener noreferrer" className="text-[hsl(235,86%,65%)] hover:underline">Discord Developer Portal</a></li>
              <li>2. Create a new application or select an existing one</li>
              <li>3. Go to the "Bot" section in the left sidebar</li>
              <li>4. Click "Reset Token" and copy the new token</li>
              <li>5. Paste the token above and save</li>
            </ol>
            <p className="text-xs text-gray-500 mt-3">
              ⚠️ Keep your bot token secure. Never share it publicly or commit it to version control.
            </p>
          </div>

          {botConfig?.token && (
            <div className="flex items-center space-x-2 text-sm">
              <FaCheck className="text-[hsl(160,84%,39%)]" />
              <span className="text-gray-300">Bot token is configured and ready for testing</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Subscription Plans */}
      <div className="grid md:grid-cols-2 gap-8">
        {/* Free Plan */}
        <Card className={`bg-[hsl(230,10%,12%)] border-2 transition-all duration-300 ${
          selectedTier === 'free' ? 'border-[hsl(160,84%,39%)]' : 'border-[hsl(30,3%,22%)]'
        }`}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl text-white flex items-center">
                <FaUserShield className="mr-3 text-[hsl(160,84%,39%)]" />
                Free Plan
              </CardTitle>
              <Badge className="bg-[hsl(160,84%,39%)] text-white">$0/month</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-400">Perfect for getting started with basic Discord bot features.</p>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-white">Free Features:</h4>
              {featuresLoading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="h-4 bg-gray-700 rounded animate-pulse" />
                  ))}
                </div>
              ) : (
                <ul className="space-y-2">
                  {freeFeatures.map((feature) => (
                    <li key={feature.id} className="flex items-center text-gray-300">
                      <FaCheck className="mr-2 text-[hsl(160,84%,39%)] text-sm" />
                      <span className="text-sm">{feature.name}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <Button
              onClick={() => setSelectedTier('free')}
              variant={selectedTier === 'free' ? 'default' : 'outline'}
              className="w-full"
            >
              Get Started Free
            </Button>
          </CardContent>
        </Card>

        {/* Premium Plan */}
        <Card className={`bg-[hsl(230,10%,12%)] border-2 transition-all duration-300 relative ${
          selectedTier === 'premium' ? 'border-[hsl(235,86%,65%)]' : 'border-[hsl(30,3%,22%)]'
        }`}>
          <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
            <Badge className="bg-gradient-to-r from-[hsl(235,86%,65%)] to-[hsl(260,73%,74%)] text-white px-4 py-1">
              <FaCrown className="mr-1" />
              Most Popular
            </Badge>
          </div>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl text-white flex items-center">
                <FaStar className="mr-3 text-[hsl(235,86%,65%)]" />
                Premium Plan
              </CardTitle>
              <div className="text-right">
                <Badge className="bg-[hsl(235,86%,65%)] text-white">$12.99/month</Badge>
                <div className="text-sm text-gray-400 mt-1">or $99/year (save 35%)</div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-400">Unlock advanced features and premium support for your Discord community.</p>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-white flex items-center">
                All Free Features +
                <FaInfinity className="ml-2 text-[hsl(235,86%,65%)]" />
              </h4>
              {featuresLoading ? (
                <div className="space-y-2">
                  {[1, 2, 3, 4, 5].map(i => (
                    <div key={i} className="h-4 bg-gray-700 rounded animate-pulse" />
                  ))}
                </div>
              ) : (
                <ul className="space-y-2">
                  {premiumFeatures.map((feature) => (
                    <li key={feature.id} className="flex items-center text-gray-300">
                      <FaCheck className="mr-2 text-[hsl(235,86%,65%)] text-sm" />
                      <span className="text-sm">{feature.name}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="space-y-2">
              {!isPremiumUser ? (
                <>
                  <Button
                    onClick={() => subscriptionMutation.mutate('monthly')}
                    disabled={subscriptionMutation.isPending}
                    className="w-full bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                  >
                    {subscriptionMutation.isPending ? 'Processing...' : 'Start Monthly Plan'}
                  </Button>
                  <Button
                    onClick={() => subscriptionMutation.mutate('yearly')}
                    disabled={subscriptionMutation.isPending}
                    variant="outline"
                    className="w-full border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,65%)] hover:text-white"
                  >
                    {subscriptionMutation.isPending ? 'Processing...' : 'Start Yearly Plan (Save 35%)'}
                  </Button>
                </>
              ) : (
                <div className="text-center p-4 bg-[hsl(235,86%,65%)]/20 rounded-lg">
                  <FaCrown className="mx-auto text-2xl text-[hsl(235,86%,65%)] mb-2" />
                  <p className="text-white font-semibold">You're Premium!</p>
                  <p className="text-sm text-gray-400">Enjoy all premium features</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Feature Categories */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
          <CardContent className="p-6 text-center">
            <FaUserShield className="mx-auto text-3xl text-[hsl(160,84%,39%)] mb-4" />
            <h3 className="font-semibold mb-2">Moderation</h3>
            <p className="text-sm text-gray-400">Slash commands, auto-moderation, kicks, bans, and member management</p>
          </CardContent>
        </Card>

        <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
          <CardContent className="p-6 text-center">
            <FaRobot className="mx-auto text-3xl text-[hsl(235,86%,65%)] mb-4" />
            <h3 className="font-semibold mb-2">Automation</h3>
            <p className="text-sm text-gray-400">Role management, welcome messages, and automated workflows</p>
          </CardContent>
        </Card>

        <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
          <CardContent className="p-6 text-center">
            <FaChartLine className="mx-auto text-3xl text-[hsl(258,84%,67%)] mb-4" />
            <h3 className="font-semibold mb-2">Analytics</h3>
            <p className="text-sm text-gray-400">Server statistics, member activity, and growth insights</p>
          </CardContent>
        </Card>

        <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
          <CardContent className="p-6 text-center">
            <FaDiscord className="mx-auto text-3xl text-[hsl(88,70%,60%)] mb-4" />
            <h3 className="font-semibold mb-2">Discord Features</h3>
            <p className="text-sm text-gray-400">Voice channels, reaction roles, and Discord-specific integrations</p>
          </CardContent>
        </Card>
      </div>



      {/* Server Selection for Premium Features */}
      <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <FaDiscord className="mr-3 text-[hsl(235,86%,65%)]" />
            Premium Server Selection
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-gray-400">
            Your premium subscription allows you to use advanced features for one Discord server. Select which server should receive premium benefits.
          </p>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">Select Premium Server</label>
              <Button 
                variant="outline" 
                className="w-full justify-start border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,65%)] hover:text-white"
              >
                <FaDiscord className="mr-2" />
                Choose Discord Server
              </Button>
            </div>
            
            <div className="bg-[hsl(235,86%,65%)]/10 border border-[hsl(235,86%,65%)]/20 rounded-lg p-4">
              <h5 className="font-semibold text-white mb-2">Premium Features Include:</h5>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• Advanced moderation tools</li>
                <li>• Custom bot token and branding</li>
                <li>• Scheduled messages and automation</li>
                <li>• Advanced analytics and insights</li>
                <li>• Priority support</li>
              </ul>
            </div>
            
            <div className="bg-[hsl(25,95%,53%)]/10 border border-[hsl(25,95%,53%)]/20 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <FaCheck className="text-[hsl(25,95%,53%)] mt-1" />
                <div>
                  <h5 className="font-semibold text-white mb-1">One Server Per Subscription</h5>
                  <p className="text-sm text-gray-300">
                    Each premium subscription covers premium features for one Discord server. You can change your selected server at any time, but only one server can have premium features active.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Premium Features Highlight */}
      {isPremiumUser && (
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Premium Features</h2>
            <p className="text-gray-400">Unlock advanced functionality with your premium subscription</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Custom Bot Token */}
            <Card className="bg-[hsl(230,10%,12%)] border-[hsl(235,86%,65%)] text-white">
              <CardHeader>
                <CardTitle className="flex items-center text-xl">
                  <FaRobot className="mr-3 text-[hsl(235,86%,65%)]" />
                  Custom Bot Token
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Use your own Discord bot token to customize the bot's name and profile picture. 
                  Perfect for branding your server with a personalized bot experience.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-300">
                    <FaCheck className="mr-2 text-[hsl(160,84%,39%)]" />
                    Custom bot name and avatar
                  </div>
                  <div className="flex items-center text-sm text-gray-300">
                    <FaCheck className="mr-2 text-[hsl(160,84%,39%)]" />
                    Your own bot token and permissions
                  </div>
                  <div className="flex items-center text-sm text-gray-300">
                    <FaCheck className="mr-2 text-[hsl(160,84%,39%)]" />
                    Full control over bot branding
                  </div>
                </div>
                <Button 
                  className="w-full bg-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,55%)]"
                  onClick={() => window.location.href = '/bots'}
                >
                  Set Up Custom Bot
                </Button>
              </CardContent>
            </Card>

            {/* Scheduled Messages */}
            <Card className="bg-[hsl(230,10%,12%)] border-[hsl(235,86%,65%)] text-white">
              <CardHeader>
                <CardTitle className="flex items-center text-xl">
                  <FaDiscord className="mr-3 text-[hsl(235,86%,65%)]" />
                  Scheduled Messages
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Schedule automated messages at specific times. Perfect for announcements, 
                  reminders, and regular community engagement.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-300">
                    <FaCheck className="mr-2 text-[hsl(160,84%,39%)]" />
                    Schedule messages by time and date
                  </div>
                  <div className="flex items-center text-sm text-gray-300">
                    <FaCheck className="mr-2 text-[hsl(160,84%,39%)]" />
                    Recurring daily, weekly, monthly options
                  </div>
                  <div className="flex items-center text-sm text-gray-300">
                    <FaCheck className="mr-2 text-[hsl(160,84%,39%)]" />
                    Perfect for announcements and reminders
                  </div>
                </div>
                <Button 
                  className="w-full bg-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,55%)]"
                  onClick={() => window.location.href = '/discord'}
                >
                  Schedule Messages
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
      </div>
    </div>
  );
}