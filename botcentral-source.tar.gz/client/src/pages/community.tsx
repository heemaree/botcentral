import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { type Announcement } from "@shared/schema";
import { FaBullhorn, FaUsers, FaComments, FaCalendarAlt, FaThumbtack } from "react-icons/fa";

export default function Community() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: announcements, isLoading: announcementsLoading } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Community" subtitle="Manage your community and announcements" />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Community Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="gaming-card border-[hsl(var(--gaming-border))] hover:border-[hsl(var(--gaming-cyan))] transition-all">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm font-medium">Total Members</p>
                    <p className="text-3xl font-bold text-white mt-1">2,547</p>
                  </div>
                  <div className="w-12 h-12 bg-[hsl(var(--gaming-cyan))]/20 rounded-lg flex items-center justify-center">
                    <FaUsers className="text-[hsl(var(--gaming-cyan))] text-xl" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="gaming-card border-[hsl(var(--gaming-border))] hover:border-[hsl(var(--gaming-purple))] transition-all">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm font-medium">Active Today</p>
                    <p className="text-3xl font-bold text-white mt-1">342</p>
                  </div>
                  <div className="w-12 h-12 bg-[hsl(var(--gaming-purple))]/20 rounded-lg flex items-center justify-center">
                    <FaComments className="text-[hsl(var(--gaming-purple))] text-xl" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="gaming-card border-[hsl(var(--gaming-border))] hover:border-[hsl(var(--gaming-emerald))] transition-all">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm font-medium">Messages Today</p>
                    <p className="text-3xl font-bold text-white mt-1">1,234</p>
                  </div>
                  <div className="w-12 h-12 bg-[hsl(var(--gaming-emerald))]/20 rounded-lg flex items-center justify-center">
                    <FaComments className="text-[hsl(var(--gaming-emerald))] text-xl" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="gaming-card border-[hsl(var(--gaming-border))] hover:border-[hsl(var(--gaming-amber))] transition-all">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm font-medium">Events This Week</p>
                    <p className="text-3xl font-bold text-white mt-1">5</p>
                  </div>
                  <div className="w-12 h-12 bg-[hsl(var(--gaming-amber))]/20 rounded-lg flex items-center justify-center">
                    <FaCalendarAlt className="text-[hsl(var(--gaming-amber))] text-xl" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Announcements Section */}
          <Card className="gaming-card border-[hsl(var(--gaming-border))]">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaBullhorn className="mr-3 text-[hsl(var(--gaming-amber))]" />
                  Community Announcements
                </CardTitle>
                <Button className="bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))] text-white">
                  Create Announcement
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {announcementsLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="flex items-start space-x-4 p-4 gaming-bg rounded-lg">
                        <div className="w-12 h-12 bg-gray-700 rounded-full"></div>
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-gray-700 rounded w-1/3"></div>
                          <div className="h-3 bg-gray-700 rounded w-full"></div>
                          <div className="h-3 bg-gray-700 rounded w-2/3"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : announcements && announcements.length > 0 ? (
                <div className="space-y-4">
                  {announcements.map((announcement) => (
                    <div key={announcement.id} className="p-4 gaming-bg rounded-lg border border-[hsl(var(--gaming-border))] hover:border-[hsl(var(--discord-primary))] transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-semibold text-white">{announcement.title}</h3>
                            {announcement.isPinned && (
                              <Badge className="bg-[hsl(var(--gaming-amber))]/20 text-[hsl(var(--gaming-amber))] border-[hsl(var(--gaming-amber))]">
                                <FaThumbtack className="mr-1" />
                                Pinned
                              </Badge>
                            )}
                          </div>
                          <p className="text-gray-300 mb-3">{announcement.content}</p>
                          <p className="text-sm text-gray-400">
                            Posted {formatDate(announcement.createdAt)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <FaBullhorn className="text-6xl text-gray-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">No Announcements Yet</h3>
                  <p className="text-gray-400 mb-6">Create your first community announcement</p>
                  <Button className="bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))] text-white">
                    Create Announcement
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
