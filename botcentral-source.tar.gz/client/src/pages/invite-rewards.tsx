import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { FaUserPlus, FaPlus, FaTrash, FaSave, FaBullhorn, FaHashtag, FaEnvelope, FaComment, FaUsers, FaTrophy, FaSearch, FaTimes } from "react-icons/fa";

interface InviteReward {
  id: number;
  inviteCount: number;
  reward: string;
  roleId?: string;
  enabled: boolean;
}

export default function InviteRewards() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Invite rewards data
  const [inviteRewards, setInviteRewards] = useState<InviteReward[]>([
    { id: 1, inviteCount: 1, reward: 'First Invite', roleId: '123456789', enabled: true },
    { id: 2, inviteCount: 5, reward: 'Community Builder', roleId: '987654321', enabled: true },
    { id: 3, inviteCount: 15, reward: 'Growth Champion', roleId: '456789123', enabled: true },
    { id: 4, inviteCount: 50, reward: 'Recruitment Master', roleId: '789123456', enabled: true }
  ]);

  // Announcement settings
  const [announcementSettings, setAnnouncementSettings] = useState({
    enabled: true,
    useEmbed: true,
    customChannelId: '',
    customMessage: "🚀 Fantastic work {user}! You've invited {count} members and earned the {reward} role!",
    pingMessage: "🚀 {user} reached an invite milestone!"
  });

  // Role selection for mentions
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [roleSearchOpen, setRoleSearchOpen] = useState(false);
  
  // Mock Discord roles data
  const mockRoles = [
    { id: '123456789', name: 'Admin', color: '#e74c3c' },
    { id: '987654321', name: 'Moderator', color: '#3498db' },
    { id: '456789123', name: 'VIP Member', color: '#f39c12' },
    { id: '789123456', name: 'Active Member', color: '#2ecc71' },
    { id: '321654987', name: 'Member', color: '#95a5a6' },
    { id: '654321987', name: 'Newcomer', color: '#9b59b6' },
    { id: '147258369', name: 'Bot Developer', color: '#e67e22' },
    { id: '963852741', name: 'Event Host', color: '#1abc9c' }
  ];

  const [newReward, setNewReward] = useState({
    inviteCount: 0,
    reward: '',
    roleId: '',
    enabled: true
  });

  // Helper functions for role management
  const addRole = (roleId: string) => {
    if (!selectedRoles.includes(roleId)) {
      setSelectedRoles([...selectedRoles, roleId]);
    }
  };

  const removeRole = (roleId: string) => {
    setSelectedRoles(selectedRoles.filter(id => id !== roleId));
  };

  const insertRoleMention = (roleId: string) => {
    const role = mockRoles.find(r => r.id === roleId);
    if (role) {
      const mention = `<@&${roleId}>`;
      const currentMessage = announcementSettings.pingMessage;
      setAnnouncementSettings(prev => ({
        ...prev,
        pingMessage: currentMessage + (currentMessage ? ' ' : '') + mention
      }));
    }
  };

  const addInviteReward = () => {
    if (newReward.inviteCount > 0 && newReward.reward.trim()) {
      const reward: InviteReward = {
        id: Date.now(),
        ...newReward
      };
      setInviteRewards(prev => [...prev, reward]);
      setNewReward({
        inviteCount: 0,
        reward: '',
        roleId: '',
        enabled: true
      });
      toast({
        title: "Success",
        description: "Invite reward added successfully!",
      });
    }
  };

  const removeInviteReward = (id: number) => {
    setInviteRewards(prev => prev.filter(reward => reward.id !== id));
    toast({
      title: "Success",
      description: "Invite reward removed successfully!",
    });
  };

  const toggleInviteReward = (id: number) => {
    setInviteRewards(prev => prev.map(reward => 
      reward.id === id ? { ...reward, enabled: !reward.enabled } : reward
    ));
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="dark min-h-screen bg-[#0b0f1e]" style={{ backgroundColor: '#0b0f1e', color: '#fafafa' }}>
      <div className="min-h-screen bg-[#0b0f1e] flex" style={{ backgroundColor: '#0b0f1e' }}>
        <Sidebar />
        <div className="flex-1 flex flex-col">
          <Header />
          <main className="flex-1 p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2 flex items-center">
                  <FaUserPlus className="mr-3 text-[hsl(var(--gaming-primary))]" />
                  Invite Rewards
                </h1>
                <p className="text-gray-400">Reward community builders who bring new members to your server</p>
              </div>
            </div>

            {/* Invite Rewards Configuration */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaTrophy className="mr-3 text-[hsl(var(--gaming-primary))]" />
                  Invite-Based Rewards
                  <span className="ml-auto text-sm bg-[hsl(var(--gaming-primary))]/20 text-[hsl(var(--gaming-primary))] px-2 py-1 rounded-full">
                    {inviteRewards.filter(r => r.enabled).length} Active
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Reward community builders who bring new members to your server. Encourage growth through referrals and community expansion.
                </p>
                
                {/* Current Invite Rewards */}
                <div className="space-y-3">
                  {inviteRewards.map((reward) => (
                    <div key={reward.id} className="flex items-center justify-between p-4 bg-[hsl(var(--gaming-muted))] rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FaUserPlus className="text-[hsl(var(--gaming-primary))]" />
                        <div>
                          <div className="font-medium text-white">{reward.inviteCount} Invite{reward.inviteCount !== 1 ? 's' : ''}</div>
                          <div className="text-sm text-gray-400">{reward.reward}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={reward.enabled}
                          onCheckedChange={() => toggleInviteReward(reward.id)}
                        />
                        <Button
                          onClick={() => removeInviteReward(reward.id)}
                          size="sm"
                          variant="destructive"
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Add New Invite Reward */}
                <div className="border-t border-[hsl(var(--gaming-border))] pt-4 space-y-3">
                  <h4 className="font-semibold text-white">Add New Invite Reward</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <Label className="text-white">Invite Count</Label>
                      <Input
                        type="number"
                        value={newReward.inviteCount || ''}
                        onChange={(e) => setNewReward(prev => ({ ...prev, inviteCount: parseInt(e.target.value) || 0 }))}
                        placeholder="10"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Reward Name</Label>
                      <Input
                        value={newReward.reward}
                        onChange={(e) => setNewReward(prev => ({ ...prev, reward: e.target.value }))}
                        placeholder="Growth Leader"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={addInviteReward} className="w-full bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80">
                        <FaPlus className="mr-2" />
                        Add Reward
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Invite Reward Announcements */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaBullhorn className="mr-3 text-[hsl(var(--gaming-accent))]" />
                  Invite Reward Announcements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Configure how invite milestone announcements are sent when users reach invite count goals.
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <FaBullhorn className="text-[hsl(var(--gaming-accent))]" />
                    <span className="text-white">Enable Invite Reward Announcements</span>
                  </div>
                  <Switch
                    checked={announcementSettings.enabled}
                    onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, enabled: checked }))}
                  />
                </div>

                {announcementSettings.enabled && (
                  <div className="space-y-4 pl-6">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <FaEnvelope className="text-[hsl(var(--gaming-primary))]" />
                        <span className="text-white text-sm">Use Embed</span>
                        <Switch
                          checked={announcementSettings.useEmbed}
                          onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, useEmbed: checked }))}
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <FaComment className="text-[hsl(var(--gaming-accent))]" />
                        <span className="text-white text-sm">Plain Text</span>
                        <Switch
                          checked={!announcementSettings.useEmbed}
                          onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, useEmbed: !checked }))}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-white">Announcement Channel</Label>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start border-[hsl(var(--gaming-border))] text-gray-400 hover:bg-[hsl(var(--gaming-muted))]"
                      >
                        <FaHashtag className="mr-2" />
                        Select Channel for Invite Announcements
                      </Button>
                      <p className="text-xs text-gray-400 mt-1">
                        Choose where invite milestone announcements will be sent
                      </p>
                    </div>
                    
                    {announcementSettings.useEmbed && (
                      <div>
                        <Label className="text-white">User Ping Message (Outside Embed)</Label>
                        <Textarea
                          value={announcementSettings.pingMessage}
                          onChange={(e) => setAnnouncementSettings(prev => ({ ...prev, pingMessage: e.target.value }))}
                          className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white h-16"
                          placeholder="🚀 {user} reached an invite milestone!"
                        />
                        <p className="text-xs text-gray-400 mt-1">
                          This message will appear above the embed to ping the user. Variables: {'{user}'}, {'{count}'}, {'{reward}'}
                        </p>
                        
                        {/* Role Selector */}
                        <div className="mt-3">
                          <Label className="text-white text-sm">Add Role Mentions</Label>
                          <div className="flex items-center space-x-2 mt-2">
                            <Popover open={roleSearchOpen} onOpenChange={setRoleSearchOpen}>
                              <PopoverTrigger asChild>
                                <Button
                                  variant="outline"
                                  className="border-[hsl(var(--gaming-border))] text-gray-400 hover:bg-[hsl(var(--gaming-muted))]"
                                >
                                  <FaSearch className="mr-2" />
                                  Add Role
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-[300px] p-0 bg-[hsl(var(--gaming-card))] border-[hsl(var(--gaming-border))]">
                                <Command className="bg-[hsl(var(--gaming-card))]">
                                  <CommandInput 
                                    placeholder="Search roles..." 
                                    className="text-white placeholder:text-gray-400"
                                  />
                                  <CommandEmpty className="text-gray-400 py-4 text-center">
                                    No roles found.
                                  </CommandEmpty>
                                  <CommandGroup className="max-h-60 overflow-auto">
                                    {mockRoles.map((role) => (
                                      <CommandItem
                                        key={role.id}
                                        value={role.name}
                                        onSelect={() => {
                                          insertRoleMention(role.id);
                                          setRoleSearchOpen(false);
                                        }}
                                        className="text-white hover:bg-[hsl(var(--gaming-hover))] cursor-pointer"
                                      >
                                        <div className="flex items-center space-x-2">
                                          <div 
                                            className="w-3 h-3 rounded-full"
                                            style={{ backgroundColor: role.color }}
                                          />
                                          <span>@{role.name}</span>
                                        </div>
                                      </CommandItem>
                                    ))}
                                  </CommandGroup>
                                </Command>
                              </PopoverContent>
                            </Popover>
                          </div>
                          <p className="text-xs text-gray-400 mt-1">
                            Click "Add Role" to search and insert role mentions into your ping message
                          </p>
                        </div>
                      </div>
                    )}
                    
                    <div>
                      <Label className="text-white">
                        {announcementSettings.useEmbed ? 'Embed Description' : 'Custom Message'}
                      </Label>
                      <Textarea
                        value={announcementSettings.customMessage}
                        onChange={(e) => setAnnouncementSettings(prev => ({ ...prev, customMessage: e.target.value }))}
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white h-20"
                        placeholder={announcementSettings.useEmbed 
                          ? "Fantastic work! You've invited {count} members and earned the {reward} role!" 
                          : "🚀 Fantastic work {user}! You've invited {count} members!"
                        }
                      />
                      <p className="text-xs text-gray-400 mt-1">
                        {announcementSettings.useEmbed 
                          ? 'This text will appear inside the embed description'
                          : 'Variables: {user}, {count}, {reward}'
                        }
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Invite Tracking Configuration */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaUsers className="mr-3 text-[hsl(var(--gaming-primary))]" />
                  Invite Tracking Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Configure how invites are tracked and counted for rewards.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Track Permanent Invites Only</Label>
                      <p className="text-xs text-gray-400 mt-1">Only count invites that don't expire</p>
                    </div>
                    <Switch defaultChecked={true} />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Require Member Retention</Label>
                      <p className="text-xs text-gray-400 mt-1">Members must stay for reward to count</p>
                    </div>
                    <Switch defaultChecked={true} />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Count Vanity URL Invites</Label>
                      <p className="text-xs text-gray-400 mt-1">Include custom vanity invites</p>
                    </div>
                    <Switch defaultChecked={false} />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Count Bot Invites</Label>
                      <p className="text-xs text-gray-400 mt-1">Include invites of bot accounts</p>
                    </div>
                    <Switch defaultChecked={false} />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">Minimum Member Age</Label>
                    <Input
                      type="number"
                      defaultValue={7}
                      className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      Days account must exist before counting
                    </p>
                  </div>
                  <div>
                    <Label className="text-white">Required Stay Duration</Label>
                    <Input
                      type="number"
                      defaultValue={24}
                      className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      Hours member must stay to count
                    </p>
                  </div>
                </div>

                <div className="border-t border-[hsl(var(--gaming-border))] pt-4">
                  <h4 className="font-semibold text-white mb-3">Bonus Multipliers</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white">Weekend Invite Bonus</Label>
                      <Input
                        type="number"
                        step="0.1"
                        defaultValue={1.5}
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                      <p className="text-xs text-gray-400 mt-1">
                        Multiplier for weekend invites
                      </p>
                    </div>
                    <div>
                      <Label className="text-white">Event Period Bonus</Label>
                      <Input
                        type="number"
                        step="0.1"
                        defaultValue={2.0}
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                      <p className="text-xs text-gray-400 mt-1">
                        Multiplier during special events
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <Button className="bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80 text-white">
                    <FaSave className="mr-2" />
                    Save Invite Reward Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    </div>
  );
}