import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";

export default function PremiumPlans() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Premium Plans" subtitle="Subscription plans and personalized bot management" />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            <div className="bg-[hsl(230,10%,12%)] border border-[hsl(30,3%,22%)] rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-[hsl(258,84%,67%)] rounded-lg flex items-center justify-center mr-4">
                    <span className="text-white font-bold text-xl">P</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Premium Plan</h3>
                    <p className="text-gray-400">Unlock advanced features and unlimited access</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-900/50 text-red-300 border border-red-600/30">
                    Free Plan
                  </span>
                </div>
              </div>
              <p className="text-gray-400 mb-4">
                Get access to advanced Discord bot features and unlimited functionality with our premium subscription.
              </p>
              
              {/* Premium Features List */}
              <div className="bg-[hsl(237,71%,7%)] rounded-lg p-4 mb-4">
                <h4 className="text-white font-semibold mb-3 flex items-center">
                  <span className="text-[hsl(258,84%,67%)] mr-2">✦</span>
                  Premium Features
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Channel Statistics
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Booster Announcements
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Unlimited Embeds
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Invite Rewards
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Message Rewards
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Level System Rewards
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Advanced Leaderboards
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Unlimited Reaction Roles
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Custom Bot Token Support
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Scheduled Messages
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Thread-based Ticket System
                  </div>
                  <div className="flex items-center text-gray-300">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    Priority Support
                  </div>
                  <div className="flex items-center text-gray-300 font-medium">
                    <span className="text-[hsl(258,84%,67%)] mr-2">▸</span>
                    And more...
                  </div>
                </div>
              </div>
              <div className="bg-[hsl(237,71%,7%)] rounded-lg p-3 mb-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-400">Current Plan:</span>
                  <span className="text-white font-medium">Free</span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-400">Status:</span>
                  <span className="text-red-400">Not Subscribed</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Next Billing:</span>
                  <span className="text-gray-500">N/A</span>
                </div>
              </div>
              <button 
                className="w-full bg-[hsl(258,84%,67%)] hover:bg-[hsl(258,84%,67%)]/80 text-white py-2 px-4 rounded-lg font-semibold"
                onClick={() => window.location.href = '/premium-plan'}
              >
                Upgrade to Premium
              </button>
            </div>

            <div className="bg-[hsl(230,10%,12%)] border border-[hsl(30,3%,22%)] rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-[hsl(160,84%,39%)] rounded-lg flex items-center justify-center mr-4">
                    <span className="text-white font-bold text-xl">B</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Personalized Bot</h3>
                    <p className="text-gray-400">Create and manage your custom Discord bots</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-900/50 text-green-300 border border-green-600/30">
                    0 Bots
                  </span>
                </div>
              </div>
              <p className="text-gray-400 mb-4">
                Build fully customized Discord bots with your own token, branding, and specialized features for your community.
              </p>
              <div className="bg-[hsl(237,71%,7%)] rounded-lg p-3 mb-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-400">Active Bots:</span>
                  <span className="text-white font-medium">0</span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-400">Total Created:</span>
                  <span className="text-white">0</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Last Activity:</span>
                  <span className="text-gray-500">Never</span>
                </div>
              </div>
              <button 
                className="w-full bg-[hsl(160,84%,39%)] hover:bg-[hsl(160,84%,39%)]/80 text-white py-2 px-4 rounded-lg font-semibold"
                onClick={() => window.location.href = '/bots'}
              >
                Manage Personalized Bots
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}