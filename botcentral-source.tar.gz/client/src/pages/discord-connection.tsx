import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  FaDiscord, 
  FaCheckCircle, 
  FaExclamationTriangle, 
  FaSync, 
  FaUnlink,
  FaCrown,
  FaUsers,
  FaServer
} from "react-icons/fa";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";

interface DiscordConnection {
  id: string;
  discordUserId: string;
  discordUsername: string;
  discordAvatar: string;
  tokenExpiresAt: string;
  isActive: boolean;
}

interface DiscordServer {
  id: string;
  serverId: string;
  serverName: string;
  serverIcon?: string;
  serverOwner: boolean;
  permissions: string;
  memberCount?: number;
  isSelected: boolean;
}

export default function DiscordConnection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isConnecting, setIsConnecting] = useState(false);

  // Check for connection success/error in URL params
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    
    if (params.get('connected') === 'true') {
      toast({
        title: "Discord Connected",
        description: "Your Discord account has been successfully connected!",
      });
      
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/discord/connection"] });
      queryClient.invalidateQueries({ queryKey: ["/api/discord/servers"] });
    }
    
    if (params.get('error') === 'auth_failed') {
      toast({
        title: "Connection Failed",
        description: "Failed to connect to Discord. Please try again.",
        variant: "destructive",
      });
      
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
    
    if (params.get('error') === 'discord_denied') {
      const reason = params.get('reason') || 'access_denied';
      toast({
        title: "Discord Access Denied",
        description: `Discord authorization was denied: ${reason}. Please check your Discord application settings.`,
        variant: "destructive",
      });
      
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [toast, queryClient]);

  // Get Discord connection status
  const { data: connection, isLoading: connectionLoading } = useQuery({
    queryKey: ["/api/discord/connection"],
  });

  // Get user's Discord servers
  const { data: servers = [], isLoading: serversLoading } = useQuery({
    queryKey: ["/api/discord/servers"],
    enabled: !!connection,
  });

  // Connect to Discord
  const connectMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/discord/auth", {
        method: "GET",
        credentials: "include",
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response.json();
    },
    onSuccess: (data) => {
      setIsConnecting(true);
      // Open in new tab to bypass any browser cache issues
      const authWindow = window.open(data.authUrl, '_blank', 'noopener,noreferrer');
      if (!authWindow) {
        // Fallback to same tab if popup blocked
        window.location.href = data.authUrl;
      }
    },
    onError: (error) => {
      toast({
        title: "Connection Error",
        description: "Failed to initiate Discord connection",
        variant: "destructive",
      });
    },
  });

  // Select server
  const selectServerMutation = useMutation({
    mutationFn: async (serverId: string) => {
      const response = await apiRequest("POST", "/api/discord/select-server", { serverId });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Server Selected",
        description: "Discord server has been selected for bot management",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/discord/servers"] });
    },
    onError: (error) => {
      toast({
        title: "Selection Error",
        description: "Failed to select Discord server",
        variant: "destructive",
      });
    },
  });

  // Disconnect from Discord
  const disconnectMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", "/api/discord/connection");
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Discord Disconnected",
        description: "Your Discord account has been disconnected",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/discord/connection"] });
      queryClient.invalidateQueries({ queryKey: ["/api/discord/servers"] });
    },
    onError: (error) => {
      toast({
        title: "Disconnect Error",
        description: "Failed to disconnect from Discord",
        variant: "destructive",
      });
    },
  });

  const selectedServer = servers.find((server: DiscordServer) => server.isSelected);

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Discord Connection" subtitle="Connect your Discord account to manage servers" />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            
            {/* Connection Status */}
            <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <FaDiscord className="mr-3 text-[hsl(235,86%,65%)]" />
                  Discord Connection Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {connectionLoading ? (
                  <div className="flex items-center space-x-3">
                    <FaSync className="animate-spin text-[hsl(235,86%,65%)]" />
                    <span>Checking connection status...</span>
                  </div>
                ) : connection ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FaCheckCircle className="text-green-400" />
                        <div>
                          <p className="font-medium text-white">Connected as {connection.discordUsername}</p>
                          <p className="text-sm text-gray-400">
                            Token expires: {new Date(connection.tokenExpiresAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => disconnectMutation.mutate()}
                        disabled={disconnectMutation.isPending}
                        className="border-red-500 text-red-400 hover:bg-red-500/10"
                      >
                        <FaUnlink className="mr-2" />
                        Disconnect
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                      <FaExclamationTriangle className="text-yellow-400" />
                      <div>
                        <p className="font-medium text-white">Not Connected</p>
                        <p className="text-sm text-gray-400">
                          Connect your Discord account to access server management features
                        </p>
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => connectMutation.mutate()}
                      disabled={connectMutation.isPending || isConnecting}
                      className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,55%)] text-white"
                    >
                      <FaDiscord className="mr-2" />
                      {connectMutation.isPending || isConnecting ? "Connecting..." : "Connect Discord"}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Server Selection */}
            {connection && (
              <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
                <CardHeader>
                  <CardTitle className="flex items-center text-2xl">
                    <FaServer className="mr-3 text-[hsl(235,86%,65%)]" />
                    Discord Servers
                  </CardTitle>
                  <p className="text-gray-400">
                    Select a Discord server to manage with BotCentral
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  {serversLoading ? (
                    <div className="flex items-center space-x-3">
                      <FaSync className="animate-spin text-[hsl(235,86%,65%)]" />
                      <span>Loading your Discord servers...</span>
                    </div>
                  ) : servers.length > 0 ? (
                    <div className="grid gap-4">
                      {servers.map((server: DiscordServer) => (
                        <div
                          key={server.serverId}
                          className={`p-4 rounded-lg border transition-colors ${
                            server.isSelected
                              ? "border-[hsl(235,86%,65%)] bg-[hsl(235,86%,65%)]/10"
                              : "border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)]/50"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              {server.serverIcon ? (
                                <img
                                  src={`https://cdn.discordapp.com/icons/${server.serverId}/${server.serverIcon}.png`}
                                  alt={server.serverName}
                                  className="w-12 h-12 rounded-full"
                                />
                              ) : (
                                <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center">
                                  <FaServer className="text-gray-400" />
                                </div>
                              )}
                              <div>
                                <div className="flex items-center space-x-2">
                                  <h3 className="font-medium text-white">{server.serverName}</h3>
                                  {server.serverOwner && (
                                    <Badge variant="secondary" className="bg-yellow-600 text-white">
                                      <FaCrown className="mr-1" />
                                      Owner
                                    </Badge>
                                  )}
                                  {server.isSelected && (
                                    <Badge className="bg-[hsl(235,86%,65%)] text-white">
                                      Selected
                                    </Badge>
                                  )}
                                </div>
                                {server.memberCount && (
                                  <p className="text-sm text-gray-400 flex items-center">
                                    <FaUsers className="mr-1" />
                                    {server.memberCount.toLocaleString()} members
                                  </p>
                                )}
                              </div>
                            </div>
                            
                            <Button
                              onClick={() => selectServerMutation.mutate(server.serverId)}
                              disabled={selectServerMutation.isPending || server.isSelected}
                              variant={server.isSelected ? "secondary" : "default"}
                              className={
                                server.isSelected
                                  ? "bg-green-600 hover:bg-green-700 text-white"
                                  : "bg-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,55%)] text-white"
                              }
                            >
                              {server.isSelected ? "Selected" : "Select"}
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <FaExclamationTriangle className="mx-auto text-yellow-400 text-4xl mb-4" />
                      <p className="text-white font-medium">No Discord servers found</p>
                      <p className="text-gray-400 text-sm">
                        Make sure you have admin permissions in at least one Discord server
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Selected Server Info */}
            {selectedServer && (
              <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
                <CardHeader>
                  <CardTitle className="flex items-center text-2xl">
                    <FaCheckCircle className="mr-3 text-green-400" />
                    Active Server
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-4 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                    {selectedServer.serverIcon ? (
                      <img
                        src={`https://cdn.discordapp.com/icons/${selectedServer.serverId}/${selectedServer.serverIcon}.png`}
                        alt={selectedServer.serverName}
                        className="w-16 h-16 rounded-full"
                      />
                    ) : (
                      <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center">
                        <FaServer className="text-gray-400 text-xl" />
                      </div>
                    )}
                    <div>
                      <h3 className="font-bold text-white text-lg">{selectedServer.serverName}</h3>
                      <p className="text-gray-400">
                        All bot features will be applied to this server
                      </p>
                      {selectedServer.memberCount && (
                        <p className="text-sm text-gray-400 flex items-center mt-1">
                          <FaUsers className="mr-1" />
                          {selectedServer.memberCount.toLocaleString()} members
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}