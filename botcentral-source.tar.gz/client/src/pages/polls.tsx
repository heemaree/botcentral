import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { FaPlus, FaPoll, FaVoteYea, FaClock, FaUsers, FaCheck, FaEdit, FaTrash } from "react-icons/fa";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const createPollSchema = z.object({
  title: z.string().min(1, "Title is required").max(255, "Title too long"),
  description: z.string().optional(),
  category: z.string().min(1, "Category is required"),
  expiresAt: z.string().optional(),
  allowMultipleVotes: z.boolean().default(false),
  isAnonymous: z.boolean().default(false),
  postToDiscord: z.boolean().default(false),
  discordChannelId: z.string().optional(),
  options: z.array(z.string().min(1, "Option cannot be empty")).min(2, "At least 2 options required").max(10, "Maximum 10 options allowed"),
});

type CreatePollForm = z.infer<typeof createPollSchema>;

export default function Polls() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [newOption, setNewOption] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Form setup
  const form = useForm<CreatePollForm>({
    resolver: zodResolver(createPollSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "general",
      expiresAt: "",
      allowMultipleVotes: false,
      isAnonymous: false,
      postToDiscord: false,
      discordChannelId: "",
      options: ["", ""],
    },
  });

  // Queries
  const { data: polls, isLoading: pollsLoading } = useQuery({
    queryKey: ['/api/polls', selectedCategory === "all" ? undefined : selectedCategory],
    enabled: isAuthenticated,
  });

  // Mutations
  const createPollMutation = useMutation({
    mutationFn: async (pollData: any) => {
      return apiRequest('/api/polls', 'POST', pollData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/polls'] });
      toast({
        title: "Success",
        description: "Poll created successfully!",
      });
      setIsCreateDialogOpen(false);
      form.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create poll. Please try again.",
        variant: "destructive",
      });
    },
  });

  const voteMutation = useMutation({
    mutationFn: async ({ pollId, optionId }: { pollId: number; optionId: number }) => {
      return apiRequest(`/api/polls/${pollId}/vote`, 'POST', { optionId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/polls'] });
      toast({
        title: "Success",
        description: "Vote submitted successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit vote. You may have already voted.",
        variant: "destructive",
      });
    },
  });

  // Handlers
  const onSubmit = (data: CreatePollForm) => {
    const pollData = {
      ...data,
      expiresAt: data.expiresAt ? new Date(data.expiresAt).toISOString() : null,
    };
    createPollMutation.mutate(pollData);
  };

  const addOption = () => {
    if (newOption.trim() && form.getValues("options").length < 10) {
      const currentOptions = form.getValues("options");
      form.setValue("options", [...currentOptions, newOption.trim()]);
      setNewOption("");
    }
  };

  const removeOption = (index: number) => {
    const currentOptions = form.getValues("options");
    if (currentOptions.length > 2) {
      form.setValue("options", currentOptions.filter((_, i) => i !== index));
    }
  };

  const updateOption = (index: number, value: string) => {
    const currentOptions = form.getValues("options");
    currentOptions[index] = value;
    form.setValue("options", [...currentOptions]);
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const categories = [
    { value: "all", label: "All Polls" },
    { value: "general", label: "General" },
    { value: "community", label: "Community" },
    { value: "events", label: "Events" },
    { value: "features", label: "Features" },
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Community Polls" subtitle="Create and participate in community voting" />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Top Controls */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category.value}
                  variant={selectedCategory === category.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.value)}
                  className={selectedCategory === category.value ? 
                    "bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)]" : 
                    "border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                  }
                >
                  {category.label}
                </Button>
              ))}
            </div>

            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white">
                  <FaPlus className="mr-2" />
                  Create Poll
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-xl font-semibold text-white flex items-center">
                    <FaPoll className="mr-2 text-[hsl(235,86%,65%)]" />
                    Create New Poll
                  </DialogTitle>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-200">Poll Title</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="What should we discuss next?"
                              {...field}
                              className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-200">Description (Optional)</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Provide more context about this poll..."
                              {...field}
                              className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-200">Category</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                <SelectItem value="general">General</SelectItem>
                                <SelectItem value="community">Community</SelectItem>
                                <SelectItem value="events">Events</SelectItem>
                                <SelectItem value="features">Features</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="expiresAt"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-200">Expires At (Optional)</FormLabel>
                            <FormControl>
                              <Input
                                type="datetime-local"
                                {...field}
                                className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Poll Options */}
                    <div className="space-y-4">
                      <Label className="text-gray-200 text-base font-medium">Poll Options</Label>
                      {form.watch("options").map((option, index) => (
                        <div key={index} className="flex gap-2 items-center">
                          <Input
                            placeholder={`Option ${index + 1}`}
                            value={option}
                            onChange={(e) => updateOption(index, e.target.value)}
                            className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                          />
                          {form.watch("options").length > 2 && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removeOption(index)}
                              className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white"
                            >
                              <FaTrash />
                            </Button>
                          )}
                        </div>
                      ))}
                      
                      {form.watch("options").length < 10 && (
                        <div className="flex gap-2">
                          <Input
                            placeholder="Add new option"
                            value={newOption}
                            onChange={(e) => setNewOption(e.target.value)}
                            className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                            onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addOption())}
                          />
                          <Button
                            type="button"
                            variant="outline"
                            onClick={addOption}
                            disabled={!newOption.trim()}
                            className="border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,65%)] hover:text-white"
                          >
                            <FaPlus />
                          </Button>
                        </div>
                      )}
                    </div>

                    {/* Poll Settings */}
                    <div className="space-y-4">
                      <Label className="text-gray-200 text-base font-medium">Settings</Label>
                      <div className="space-y-3">
                        <FormField
                          control={form.control}
                          name="allowMultipleVotes"
                          render={({ field }) => (
                            <FormItem className="flex items-center justify-between">
                              <FormLabel className="text-gray-300">Allow multiple votes per user</FormLabel>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="isAnonymous"
                          render={({ field }) => (
                            <FormItem className="flex items-center justify-between">
                              <FormLabel className="text-gray-300">Anonymous voting</FormLabel>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="postToDiscord"
                          render={({ field }) => (
                            <FormItem className="flex items-center justify-between">
                              <FormLabel className="text-gray-300">Post to Discord channel</FormLabel>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>

                    {form.watch("postToDiscord") && (
                      <div className="space-y-4">
                        <Label className="text-gray-200 text-base font-medium">Discord Integration</Label>
                        <FormField
                          control={form.control}
                          name="discordChannelId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Discord Channel</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Enter Discord channel ID or webhook URL"
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <p className="text-xs text-gray-500">
                                Provide a Discord channel ID or webhook URL to automatically post the poll to your Discord server.
                              </p>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    <div className="flex justify-end gap-3 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsCreateDialogOpen(false)}
                        className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={createPollMutation.isPending}
                        className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                      >
                        {createPollMutation.isPending ? "Creating..." : "Create Poll"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Polls Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {pollsLoading ? (
              // Loading skeleton
              Array.from({ length: 4 }, (_, i) => (
                <Card key={i} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                  <CardHeader>
                    <div className="h-6 bg-[hsl(237,71%,7%)] rounded animate-pulse"></div>
                    <div className="h-4 bg-[hsl(237,71%,7%)] rounded w-2/3 animate-pulse"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {Array.from({ length: 3 }).map((_, j) => (
                        <div key={j} className="h-4 bg-[hsl(237,71%,7%)] rounded animate-pulse"></div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              (polls as any[])?.map((poll: any) => (
                <PollCard key={poll.id} poll={poll} onVote={voteMutation.mutate} isVoting={voteMutation.isPending} />
              )) || []
            )}
          </div>

          {polls && (polls as any[]).length === 0 && (
            <div className="text-center py-16">
              <FaPoll className="mx-auto text-6xl text-gray-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-300 mb-2">No polls found</h3>
              <p className="text-gray-500 mb-6">Be the first to create a poll for the community!</p>
              <Button 
                onClick={() => setIsCreateDialogOpen(true)}
                className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
              >
                <FaPlus className="mr-2" />
                Create First Poll
              </Button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

function PollCard({ poll, onVote, isVoting }: { poll: any; onVote: (data: { pollId: number; optionId: number }) => void; isVoting: boolean }) {
  const [showResults, setShowResults] = useState(false);

  // Get poll results and user vote
  const { data: pollResults = [] } = useQuery({
    queryKey: [`/api/polls/${poll.id}/results`],
  });

  const { data: userVote } = useQuery({
    queryKey: [`/api/polls/${poll.id}/my-vote`],
  });

  // Auto-show results if user has voted
  useEffect(() => {
    if (userVote) {
      setShowResults(true);
    }
  }, [userVote]);

  const totalVotes = (pollResults as any[]).reduce((sum, result) => sum + result.votes, 0);
  const isExpired = poll.expiresAt && new Date(poll.expiresAt) < new Date();

  const handleVote = (optionId: number) => {
    onVote({ pollId: poll.id, optionId });
  };

  return (
    <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-white text-lg font-semibold mb-2">{poll.title}</CardTitle>
            {poll.description && (
              <p className="text-gray-400 text-sm mb-3">{poll.description}</p>
            )}
          </div>
          <div className="flex gap-2 ml-4">
            <Badge 
              variant="outline" 
              className="border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)]"
            >
              {poll.category}
            </Badge>
            {isExpired && (
              <Badge variant="outline" className="border-red-500 text-red-500">
                Expired
              </Badge>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-sm text-gray-400">
          <div className="flex items-center gap-1">
            <FaUsers />
            <span>{totalVotes} votes</span>
          </div>
          {poll.expiresAt && (
            <div className="flex items-center gap-1">
              <FaClock />
              <span>Expires {new Date(poll.expiresAt).toLocaleDateString()}</span>
            </div>
          )}
          {poll.isAnonymous && (
            <Badge variant="outline" className="border-gray-500 text-gray-500 text-xs">
              Anonymous
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-3">
          {(pollResults as any[]).map((option: any) => {
            const percentage = totalVotes > 0 ? (option.votes / totalVotes) * 100 : 0;
            const isUserChoice = (userVote as any)?.optionId === option.optionId;
            
            return (
              <div key={option.optionId} className="space-y-2">
                {showResults || isExpired ? (
                  // Show results
                  <div className={`p-3 rounded-lg border ${isUserChoice ? 'border-[hsl(235,86%,65%)] bg-[hsl(235,86%,65%)]/10' : 'border-[hsl(30,3%,22%)] bg-[hsl(237,71%,7%)]'}`}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-white flex items-center gap-2">
                        {option.text}
                        {isUserChoice && <FaCheck className="text-[hsl(235,86%,65%)]" />}
                      </span>
                      <span className="text-gray-400 text-sm">
                        {option.votes} ({percentage.toFixed(1)}%)
                      </span>
                    </div>
                    <Progress 
                      value={percentage} 
                      className="h-2"
                    />
                  </div>
                ) : (
                  // Show voting option
                  <Button
                    variant="outline"
                    className="w-full justify-start p-3 h-auto border-[hsl(30,3%,22%)] text-white hover:bg-[hsl(235,86%,65%)]/10 hover:border-[hsl(235,86%,65%)]"
                    onClick={() => handleVote(option.optionId)}
                    disabled={isVoting || isExpired}
                  >
                    <FaVoteYea className="mr-2" />
                    {option.text}
                  </Button>
                )}
              </div>
            );
          })}
        </div>
        
        {!showResults && !isExpired && userVote === null && (
          <div className="mt-4 pt-4 border-t border-[hsl(30,3%,22%)]">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowResults(true)}
              className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
            >
              View Results
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}