import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { ColorPicker } from "@/components/ui/color-picker";
import { FaGift, FaBolt, FaHashtag, FaSave, FaCog, FaLock, FaEye, FaUser, FaAt } from "react-icons/fa";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";

export default function BoosterAnnouncements() {
  const [announcementConfig, setAnnouncementConfig] = useState({
    enabled: false,
    channel: "",
    embedTitle: "🎉 New Server Booster!",
    embedDescription: "Thank you {user} for boosting our server! Your support helps make this community amazing.",
    embedColor: "#ff73fa",
    pingMessage: "Welcome our new booster {user}! 🚀",
    showUserAvatar: true,
    includeBoostCount: true,
    customFooter: "Thanks for supporting our community!",
    useCustomColors: false
  });

  // Get user subscription status
  const { data: subscriptionData } = useQuery({
    queryKey: ["/api/user/subscription"],
  });
  
  const isPremium = subscriptionData?.subscriptionTier === "premium" || subscriptionData?.subscriptionTier === "yearly";

  const handleSave = () => {
    if (!isPremium) {
      // Show premium upgrade prompt
      return;
    }
    // Save configuration logic here
    console.log("Saving booster announcements configuration:", announcementConfig);
  };

  const userMentions = [
    { id: "1", username: "john_doe", displayName: "John Doe" },
    { id: "2", username: "jane_smith", displayName: "Jane Smith" },
    { id: "3", username: "alex_gaming", displayName: "Alex Gaming" }
  ];

  const insertUserMention = (username: string) => {
    const mention = `{user.${username}}`;
    setAnnouncementConfig(prev => ({
      ...prev,
      embedDescription: prev.embedDescription + ` ${mention}`
    }));
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Booster Announcements" subtitle="Celebrate server boosters with custom announcements" />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="border-b border-[hsl(30,3%,22%)] pb-6">
          <div className="flex items-center space-x-3 mb-2">
            <FaGift className="text-2xl text-[hsl(235,86%,65%)]" />
            <h1 className="text-3xl font-bold">Booster Announcements</h1>
            {!isPremium && (
              <Badge variant="secondary" className="bg-yellow-600 text-white">
                <FaLock className="mr-1" />
                Premium Feature
              </Badge>
            )}
          </div>
          <p className="text-gray-400">
            Celebrate new server boosters with customizable announcement messages and embeds
          </p>
        </div>

        {/* Premium Notice */}
        {!isPremium && (
          <Card className="bg-gradient-to-r from-yellow-900/20 to-orange-900/20 border-yellow-600/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <FaLock className="text-yellow-500 text-xl" />
                  <div>
                    <h3 className="text-lg font-semibold text-yellow-400">Premium Feature Required</h3>
                    <p className="text-gray-300">
                      Booster Announcements require a premium subscription to configure and use.
                    </p>
                  </div>
                </div>
                <Button 
                  onClick={() => window.location.href = '/premium-plans'}
                  className="bg-yellow-600 hover:bg-yellow-700 text-white"
                >
                  Upgrade Now
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Configuration Panel */}
          <div className="space-y-6">
            {/* Main Configuration */}
            <Card className={`bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] ${!isPremium ? 'opacity-60' : ''}`}>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FaCog className="text-[hsl(235,86%,65%)]" />
                  <span>Configuration</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Enable/Disable */}
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-white font-medium">Enable Booster Announcements</Label>
                    <p className="text-sm text-gray-400">
                      Automatically send announcements when someone boosts the server
                    </p>
                  </div>
                  <Switch
                    checked={announcementConfig.enabled}
                    onCheckedChange={(checked) => 
                      setAnnouncementConfig(prev => ({ ...prev, enabled: checked }))
                    }
                    disabled={!isPremium}
                  />
                </div>

                {/* Channel Selection */}
                <div className="space-y-4">
                  <Label className="text-white">Announcement Channel</Label>
                  <div className="flex items-center space-x-2">
                    <FaHashtag className="text-gray-400" />
                    <Input
                      value={announcementConfig.channel}
                      onChange={(e) => setAnnouncementConfig(prev => ({ ...prev, channel: e.target.value }))}
                      className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                      placeholder="Select announcement channel"
                      disabled={!isPremium}
                    />
                  </div>
                </div>

                {/* Ping Message */}
                <div className="space-y-4">
                  <Label className="text-white">User Ping Message (Outside Embed)</Label>
                  <Textarea
                    value={announcementConfig.pingMessage}
                    onChange={(e) => setAnnouncementConfig(prev => ({ ...prev, pingMessage: e.target.value }))}
                    className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                    placeholder="Welcome our new booster {user}! 🚀"
                    disabled={!isPremium}
                    rows={2}
                  />
                  <p className="text-sm text-gray-400">
                    This message appears above the embed and can mention the user
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Embed Configuration */}
            <Card className={`bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] ${!isPremium ? 'opacity-60' : ''}`}>
              <CardHeader>
                <CardTitle className="text-white">Embed Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Embed Title */}
                <div className="space-y-4">
                  <Label className="text-white">Embed Title</Label>
                  <Input
                    value={announcementConfig.embedTitle}
                    onChange={(e) => setAnnouncementConfig(prev => ({ ...prev, embedTitle: e.target.value }))}
                    className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                    placeholder="🎉 New Server Booster!"
                    disabled={!isPremium}
                  />
                </div>

                {/* Embed Description */}
                <div className="space-y-4">
                  <Label className="text-white">Embed Description</Label>
                  <Textarea
                    value={announcementConfig.embedDescription}
                    onChange={(e) => setAnnouncementConfig(prev => ({ ...prev, embedDescription: e.target.value }))}
                    className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                    placeholder="Thank you {user} for boosting our server!"
                    disabled={!isPremium}
                    rows={3}
                  />
                  
                  {/* User Mention Helper */}
                  <div className="space-y-2">
                    <Label className="text-sm text-gray-300">Quick Insert User Mentions</Label>
                    <div className="flex flex-wrap gap-2">
                      {userMentions.map((user) => (
                        <Button
                          key={user.id}
                          onClick={() => insertUserMention(user.username)}
                          variant="outline"
                          size="sm"
                          className="text-xs bg-[hsl(220,13%,18%)] border-[hsl(235,86%,65%)] text-white hover:bg-[hsl(235,86%,65%)]"
                          disabled={!isPremium}
                        >
                          <FaAt className="mr-1" />
                          {user.displayName}
                        </Button>
                      ))}
                      <Button
                        onClick={() => insertUserMention("booster")}
                        variant="outline"
                        size="sm"
                        className="text-xs bg-[hsl(220,13%,18%)] border-[hsl(235,86%,65%)] text-white hover:bg-[hsl(235,86%,65%)]"
                        disabled={!isPremium}
                      >
                        <FaUser className="mr-1" />
                        Generic User
                      </Button>
                    </div>
                    <p className="text-xs text-gray-400">
                      Use {"{user}"} for the booster's name or {"{user.username}"} for specific mentions
                    </p>
                  </div>
                </div>

                {/* Embed Color */}
                <div className="space-y-4">
                  <Label className="text-white">Embed Color</Label>
                  <ColorPicker
                    value={announcementConfig.embedColor}
                    onChange={(color) => setAnnouncementConfig(prev => ({ ...prev, embedColor: color }))}
                    disabled={!isPremium}
                  />
                </div>

                {/* Custom Footer */}
                <div className="space-y-4">
                  <Label className="text-white">Custom Footer</Label>
                  <Input
                    value={announcementConfig.customFooter}
                    onChange={(e) => setAnnouncementConfig(prev => ({ ...prev, customFooter: e.target.value }))}
                    className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                    placeholder="Thanks for supporting our community!"
                    disabled={!isPremium}
                  />
                </div>

                {/* Additional Options */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm text-white">Show User Avatar</Label>
                      <p className="text-xs text-gray-400">Display the booster's profile picture</p>
                    </div>
                    <Switch
                      checked={announcementConfig.showUserAvatar}
                      onCheckedChange={(checked) => 
                        setAnnouncementConfig(prev => ({ ...prev, showUserAvatar: checked }))
                      }
                      disabled={!isPremium}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm text-white">Include Total Boost Count</Label>
                      <p className="text-xs text-gray-400">Show current server boost level</p>
                    </div>
                    <Switch
                      checked={announcementConfig.includeBoostCount}
                      onCheckedChange={(checked) => 
                        setAnnouncementConfig(prev => ({ ...prev, includeBoostCount: checked }))
                      }
                      disabled={!isPremium}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Save Button */}
            <div className="flex justify-end">
              <Button 
                onClick={handleSave}
                disabled={!isPremium || !announcementConfig.enabled}
                className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,55%)] text-white px-6"
              >
                <FaSave className="mr-2" />
                Save Configuration
              </Button>
            </div>
          </div>

          {/* Preview Panel */}
          <div className="space-y-6">
            <Card className={`bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] ${!isPremium ? 'opacity-60' : ''}`}>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FaEye className="text-[hsl(235,86%,65%)]" />
                  <span>Live Preview</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Ping Message Preview */}
                  {announcementConfig.pingMessage && (
                    <div className="p-3 bg-[hsl(220,13%,18%)] rounded-lg">
                      <p className="text-white">
                        {announcementConfig.pingMessage.replace('{user}', '@TestUser')}
                      </p>
                    </div>
                  )}

                  {/* Embed Preview */}
                  <div 
                    className="border-l-4 bg-[hsl(220,13%,18%)] p-4 rounded-r-lg"
                    style={{ borderLeftColor: announcementConfig.embedColor }}
                  >
                    {/* Author */}
                    {announcementConfig.showUserAvatar && (
                      <div className="flex items-center space-x-2 mb-3">
                        <div className="w-6 h-6 bg-blue-500 rounded-full"></div>
                        <span className="text-sm text-white font-medium">TestUser</span>
                      </div>
                    )}

                    {/* Title */}
                    <h3 className="text-white font-semibold mb-2">
                      {announcementConfig.embedTitle}
                    </h3>

                    {/* Description */}
                    <div className="text-gray-300 mb-3">
                      {announcementConfig.embedDescription
                        .replace('{user}', '@TestUser')
                        .replace('{user.booster}', '@TestUser')
                        .split('\n')
                        .map((line, index) => (
                          <p key={index} className="mb-1">
                            {line.includes('@') ? (
                              <span className="text-blue-400 font-medium">{line}</span>
                            ) : (
                              line
                            )}
                          </p>
                        ))}
                    </div>

                    {/* Boost Count */}
                    {announcementConfig.includeBoostCount && (
                      <div className="flex items-center space-x-2 mb-3">
                        <FaBolt className="text-pink-400" />
                        <span className="text-sm text-gray-300">Server Boost Level: 2 (14 boosts)</span>
                      </div>
                    )}

                    {/* Footer */}
                    {announcementConfig.customFooter && (
                      <div className="text-xs text-gray-400 mt-3 pt-2 border-t border-gray-600">
                        {announcementConfig.customFooter}
                      </div>
                    )}
                  </div>

                  <p className="text-sm text-gray-400">
                    This preview shows how your booster announcement will appear in Discord
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
          </div>
        </main>
      </div>
    </div>
  );
}