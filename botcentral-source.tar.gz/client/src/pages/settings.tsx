import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { ColorPicker } from "@/components/ui/color-picker";
import PersonalAccessTokens from "@/components/settings/personal-access-tokens";
import { FaCog, FaBell, FaLock, FaUser, FaSignOutAlt, FaDiscord, FaPalette, FaCrown } from "react-icons/fa";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Settings() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Settings" subtitle="Manage your account and preferences" />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Profile Settings */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaUser className="mr-3 text-[hsl(var(--gaming-cyan))]" />
                  Profile Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-6">
                  <div className="w-20 h-20 bg-[hsl(var(--discord-primary))]/20 rounded-full flex items-center justify-center">
                    {user?.profileImageUrl ? (
                      <img 
                        src={user.profileImageUrl} 
                        alt="Profile" 
                        className="w-20 h-20 rounded-full object-cover"
                      />
                    ) : (
                      <FaUser className="text-[hsl(var(--discord-primary))] text-2xl" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-medium text-white">
                      {user?.firstName && user?.lastName 
                        ? `${user.firstName} ${user.lastName}` 
                        : user?.email || "User"}
                    </h3>
                    <p className="text-gray-400">{user?.email}</p>
                  </div>
                </div>
                
                <Separator className="border-[hsl(var(--gaming-border))]" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="firstName" className="text-gray-300">First Name</Label>
                    <Input 
                      id="firstName" 
                      defaultValue={user?.firstName || ""} 
                      className="gaming-bg border-[hsl(var(--gaming-border))] text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName" className="text-gray-300">Last Name</Label>
                    <Input 
                      id="lastName" 
                      defaultValue={user?.lastName || ""} 
                      className="gaming-bg border-[hsl(var(--gaming-border))] text-white"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-gray-300">Email</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    defaultValue={user?.email || ""} 
                    className="gaming-bg border-[hsl(var(--gaming-border))] text-white"
                    disabled
                  />
                  <p className="text-sm text-gray-400">Email is managed by Discord</p>
                </div>
                
                <Button className="bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))] text-white">
                  Save Changes
                </Button>
              </CardContent>
            </Card>

            {/* Notification Settings */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaBell className="mr-3 text-[hsl(var(--gaming-amber))]" />
                  Notification Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Bot Status Notifications</h4>
                    <p className="text-sm text-gray-400">Get notified when your bots go online or offline</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator className="border-[hsl(var(--gaming-border))]" />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Event Reminders</h4>
                    <p className="text-sm text-gray-400">Receive reminders for upcoming community events</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator className="border-[hsl(var(--gaming-border))]" />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Activity Digest</h4>
                    <p className="text-sm text-gray-400">Weekly summary of your community activity</p>
                  </div>
                  <Switch />
                </div>
                
                <Separator className="border-[hsl(var(--gaming-border))]" />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Security Alerts</h4>
                    <p className="text-sm text-gray-400">Important security notifications</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>

            {/* Security Settings */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaLock className="mr-3 text-[hsl(var(--gaming-emerald))]" />
                  Security & Privacy
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Two-Factor Authentication</h4>
                    <p className="text-sm text-gray-400">Managed through your Discord account</p>
                  </div>
                  <Button variant="outline" className="border-[hsl(var(--gaming-border))] text-gray-300">
                    <FaDiscord className="mr-2" />
                    Configure on Discord
                  </Button>
                </div>
                
                <Separator className="border-[hsl(var(--gaming-border))]" />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Bot Token Security</h4>
                    <p className="text-sm text-gray-400">Your bot tokens are encrypted and secure</p>
                  </div>
                  <Button variant="outline" className="border-[hsl(var(--gaming-border))] text-gray-300">
                    View Security
                  </Button>
                </div>
                
                <Separator className="border-[hsl(var(--gaming-border))]" />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Data Export</h4>
                    <p className="text-sm text-gray-400">Download your bot data and configurations</p>
                  </div>
                  <Button variant="outline" className="border-[hsl(var(--gaming-border))] text-gray-300">
                    Export Data
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* App Settings */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaCog className="mr-3 text-[hsl(var(--gaming-purple))]" />
                  Application Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Auto-refresh Dashboard</h4>
                    <p className="text-sm text-gray-400">Automatically refresh bot status and metrics</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator className="border-[hsl(var(--gaming-border))]" />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Compact Mode</h4>
                    <p className="text-sm text-gray-400">Use a more compact layout for the dashboard</p>
                  </div>
                  <Switch />
                </div>
                
                <Separator className="border-[hsl(var(--gaming-border))]" />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">Developer Mode</h4>
                    <p className="text-sm text-gray-400">Show additional debugging information</p>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>

            {/* Personal Access Tokens */}
            <PersonalAccessTokens />

            {/* Global Color Settings */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaPalette className="mr-3 text-[hsl(var(--gaming-purple))]" />
                  Global Embed Colors
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <GlobalColorSettings />
              </CardContent>
            </Card>

            {/* Account Actions */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white">Account Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={() => window.location.href = '/api/logout'}
                  variant="outline" 
                  className="w-full border-[hsl(var(--status-offline))] text-[hsl(var(--status-offline))] hover:bg-[hsl(var(--status-offline))] hover:text-white"
                >
                  <FaSignOutAlt className="mr-2" />
                  Sign Out
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}

// Global Color Settings Component
function GlobalColorSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [globalColor, setGlobalColor] = useState("#5865F2");
  const [useGlobalColor, setUseGlobalColor] = useState(false);
  const [titleColor, setTitleColor] = useState("#FFFFFF");
  const [useCustomTitleColor, setUseCustomTitleColor] = useState(false);

  // Fetch current color settings
  const { data: colorSettings, isLoading } = useQuery({
    queryKey: ["/api/embed-color-settings"],
  });

  // Update mutation
  const updateColorSettingsMutation = useMutation({
    mutationFn: async (settings: { globalColor: string; useGlobalColor: boolean; titleColor: string; useCustomTitleColor: boolean }) => {
      return await apiRequest("POST", "/api/embed-color-settings", settings);
    },
    onSuccess: () => {
      toast({
        title: "Settings Updated",
        description: "Your global embed color settings have been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/embed-color-settings"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update color settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update local state when data loads
  useEffect(() => {
    if (colorSettings) {
      setGlobalColor(colorSettings.globalColor || "#5865F2");
      setUseGlobalColor(colorSettings.useGlobalColor || false);
      setTitleColor(colorSettings.titleColor || "#FFFFFF");
      setUseCustomTitleColor(colorSettings.useCustomTitleColor || false);
    }
  }, [colorSettings]);

  const handleSave = () => {
    updateColorSettingsMutation.mutate({
      globalColor,
      useGlobalColor,
      titleColor,
      useCustomTitleColor,
    });
  };

  if (isLoading) {
    return <div className="text-gray-400">Loading color settings...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <Switch
          checked={useGlobalColor}
          onCheckedChange={setUseGlobalColor}
        />
        <div>
          <h4 className="font-medium text-white">Use Global Color for All Embeds</h4>
          <p className="text-sm text-gray-400">
            When enabled, all embeds will use the color selected below
          </p>
        </div>
      </div>

      <div className="space-y-3">
        <ColorPicker
          value={globalColor}
          onChange={setGlobalColor}
          label="Global Embed Color"
          disabled={!useGlobalColor}
        />
        
        <p className="text-xs text-gray-500">
          This color will be applied to all custom embeds, reaction roles, announcements, and other embed messages when global color is enabled.
        </p>
      </div>

      {/* Premium Title Color Customization */}
      <div className="border-t border-gray-700 pt-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="font-medium text-white flex items-center">
              <FaLock className="mr-2 text-yellow-500" />
              Custom Title Colors
            </h4>
            <p className="text-sm text-gray-400">
              Premium feature: Customize embed title colors (default: white)
            </p>
          </div>
          <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black px-3 py-1 rounded-full text-xs font-semibold">
            PREMIUM
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <Switch
              checked={useCustomTitleColor}
              onCheckedChange={setUseCustomTitleColor}
              disabled={true} // Disabled for now as premium feature
            />
            <div>
              <h5 className="font-medium text-white">Enable Custom Title Colors</h5>
              <p className="text-sm text-gray-400">
                Allows you to set custom colors for embed titles (requires premium subscription)
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <ColorPicker
              value={titleColor}
              onChange={setTitleColor}
              label="Title Color"
              disabled={true} // Disabled for now as premium feature
            />
            
            <p className="text-xs text-gray-500">
              By default, all embed titles are white. With premium, you can customize the title color for better branding.
            </p>
          </div>

          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
            <h6 className="font-medium text-white mb-2">Preview</h6>
            <div className="bg-gray-900 rounded-lg p-4 border-l-4" style={{ borderLeftColor: globalColor }}>
              <h6 className="font-semibold mb-2" style={{ color: useCustomTitleColor ? titleColor : '#FFFFFF' }}>
                📢 Sample Embed Title
              </h6>
              <p className="text-gray-300 text-sm">
                This is how your embed title will look with the selected color settings.
              </p>
            </div>
          </div>
        </div>
      </div>

      <Button
        onClick={handleSave}
        disabled={updateColorSettingsMutation.isPending}
        className="w-full bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
      >
        {updateColorSettingsMutation.isPending ? "Saving..." : "Save Color Settings"}
      </Button>
    </div>
  );
}
