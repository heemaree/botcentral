import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { FaTicketAlt, FaPlus, FaEdit, FaTrash, FaCrown, FaLock } from "react-icons/fa";

export default function TicketsPage() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [ticketPanels, setTicketPanels] = useState([
    {
      id: 1,
      name: "General Support",
      description: "Get help with general questions and issues",
      channel: "#general-support",
      category: "Support",
      buttonText: "Create Ticket",
      buttonEmoji: "🎫",
      threadPermissions: false,
      status: "Active"
    },
    {
      id: 2,
      name: "Bug Reports",
      description: "Report bugs and technical issues",
      channel: "#bug-reports",
      category: "Technical",
      buttonText: "Report Bug",
      buttonEmoji: "🐛",
      threadPermissions: false,
      status: "Active"
    }
  ]);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newPanel, setNewPanel] = useState({
    name: "",
    description: "",
    channel: "",
    category: "",
    buttonText: "Create Ticket",
    buttonEmoji: "🎫",
    threadPermissions: false
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleCreatePanel = () => {
    if (!newPanel.name || !newPanel.description || !newPanel.channel) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const panel = {
      ...newPanel,
      id: Date.now(),
      status: "Active"
    };

    setTicketPanels([...ticketPanels, panel]);
    setNewPanel({
      name: "",
      description: "",
      channel: "",
      category: "",
      buttonText: "Create Ticket",
      buttonEmoji: "🎫",
      threadPermissions: false
    });
    setShowCreateForm(false);

    toast({
      title: "Ticket Panel Created",
      description: `"${panel.name}" panel has been created successfully`,
    });
  };

  const handleDeletePanel = (id: number) => {
    setTicketPanels(ticketPanels.filter(panel => panel.id !== id));
    toast({
      title: "Panel Deleted",
      description: "Ticket panel has been removed",
    });
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Tickets" subtitle="Create and manage ticket support panels for your Discord server" />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-6xl space-y-6">
            
            {/* Create New Panel Button */}
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-white mb-2">Ticket Panels</h2>
                <p className="text-gray-400">Manage support ticket systems for your community</p>
              </div>
              <Button 
                onClick={() => setShowCreateForm(true)}
                className="bg-[hsl(258,84%,67%)] hover:bg-[hsl(258,84%,67%)]/80 text-white"
              >
                <FaPlus className="mr-2" />
                Create Panel
              </Button>
            </div>

            {/* Create Panel Form */}
            {showCreateForm && (
              <Card className="bg-[hsl(230,10%,12%)] border border-[hsl(30,3%,22%)]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <FaTicketAlt className="mr-2" />
                    Create New Ticket Panel
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Set up a new ticket support panel for your Discord server
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white">Panel Name *</Label>
                      <Input
                        value={newPanel.name}
                        onChange={(e) => setNewPanel({...newPanel, name: e.target.value})}
                        placeholder="e.g., General Support"
                        className="bg-[hsl(237,71%,7%)] border border-[hsl(30,3%,22%)] text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Category</Label>
                      <Input
                        value={newPanel.category}
                        onChange={(e) => setNewPanel({...newPanel, category: e.target.value})}
                        placeholder="e.g., Support, Technical"
                        className="bg-[hsl(237,71%,7%)] border border-[hsl(30,3%,22%)] text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-white">Description *</Label>
                    <Textarea
                      value={newPanel.description}
                      onChange={(e) => setNewPanel({...newPanel, description: e.target.value})}
                      placeholder="Describe what this ticket panel is for..."
                      className="bg-[hsl(237,71%,7%)] border border-[hsl(30,3%,22%)] text-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label className="text-white">Discord Channel *</Label>
                      <Input
                        value={newPanel.channel}
                        onChange={(e) => setNewPanel({...newPanel, channel: e.target.value})}
                        placeholder="#ticket-support"
                        className="bg-[hsl(237,71%,7%)] border border-[hsl(30,3%,22%)] text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Button Text</Label>
                      <Input
                        value={newPanel.buttonText}
                        onChange={(e) => setNewPanel({...newPanel, buttonText: e.target.value})}
                        placeholder="Create Ticket"
                        className="bg-[hsl(237,71%,7%)] border border-[hsl(30,3%,22%)] text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Button Emoji</Label>
                      <Input
                        value={newPanel.buttonEmoji}
                        onChange={(e) => setNewPanel({...newPanel, buttonEmoji: e.target.value})}
                        placeholder="🎫"
                        className="bg-[hsl(237,71%,7%)] border border-[hsl(30,3%,22%)] text-white"
                      />
                    </div>
                  </div>

                  {/* Thread Permissions - Premium Feature */}
                  <div className="border border-[hsl(30,3%,22%)] rounded-lg p-4 bg-[hsl(237,71%,7%)]">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <Label className="text-white flex items-center">
                          <FaLock className="mr-2 text-yellow-500" />
                          Thread Permissions
                          <Badge className="ml-2 bg-yellow-900/50 text-yellow-300 border border-yellow-600/30">
                            Premium
                          </Badge>
                        </Label>
                        <p className="text-sm text-gray-400 mt-1">
                          Create tickets as private threads instead of channels
                        </p>
                      </div>
                      <Switch
                        checked={newPanel.threadPermissions}
                        onCheckedChange={(checked) => setNewPanel({...newPanel, threadPermissions: checked})}
                        disabled={true} // Disabled for free users
                        className="opacity-50"
                      />
                    </div>
                    <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-3">
                      <p className="text-yellow-300 text-sm flex items-center">
                        <FaCrown className="mr-2" />
                        Upgrade to Premium to enable thread-based tickets with advanced permissions
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button 
                      onClick={handleCreatePanel}
                      className="bg-[hsl(258,84%,67%)] hover:bg-[hsl(258,84%,67%)]/80 text-white"
                    >
                      Create Panel
                    </Button>
                    <Button 
                      onClick={() => setShowCreateForm(false)}
                      variant="outline"
                      className="border-[hsl(30,3%,22%)] text-gray-400 hover:text-white"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Existing Panels */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {ticketPanels.map((panel) => (
                <Card key={panel.id} className="bg-[hsl(230,10%,12%)] border border-[hsl(30,3%,22%)]">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white flex items-center">
                        <span className="mr-2">{panel.buttonEmoji}</span>
                        {panel.name}
                      </CardTitle>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="border-[hsl(30,3%,22%)] text-gray-400 hover:text-white">
                          <FaEdit />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-red-600/30 text-red-400 hover:text-red-300 hover:border-red-500/50"
                          onClick={() => handleDeletePanel(panel.id)}
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </div>
                    {panel.category && (
                      <Badge className="w-fit bg-blue-900/50 text-blue-300 border border-blue-600/30">
                        {panel.category}
                      </Badge>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-gray-400 text-sm">{panel.description}</p>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Channel:</span>
                        <span className="text-gray-300">{panel.channel}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Button Text:</span>
                        <span className="text-gray-300">{panel.buttonText}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Thread Mode:</span>
                        <span className="text-gray-300">
                          {panel.threadPermissions ? (
                            <Badge className="bg-green-900/50 text-green-300 border border-green-600/30">
                              Enabled
                            </Badge>
                          ) : (
                            <Badge className="bg-gray-600/50 text-gray-400 border border-gray-500/30">
                              Disabled
                            </Badge>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Status:</span>
                        <Badge className="bg-green-900/50 text-green-300 border border-green-600/30">
                          {panel.status}
                        </Badge>
                      </div>
                    </div>

                    {/* Preview Button */}
                    <div className="mt-4 p-3 bg-[hsl(237,71%,7%)] rounded-lg border border-[hsl(30,3%,22%)]">
                      <p className="text-xs text-gray-500 mb-2">Discord Preview:</p>
                      <Button 
                        className="w-full bg-[hsl(258,84%,67%)] hover:bg-[hsl(258,84%,67%)]/80 text-white"
                        disabled
                      >
                        {panel.buttonEmoji} {panel.buttonText}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Information Card */}
            <Card className="bg-[hsl(230,10%,12%)] border border-[hsl(30,3%,22%)]">
              <CardHeader>
                <CardTitle className="text-white">How Ticket Systems Work</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-400 space-y-3">
                <p>
                  <strong className="text-white">Basic Tickets:</strong> Users click the button to create a new channel where they can get support from your team.
                </p>
                <p>
                  <strong className="text-white">Thread Tickets (Premium):</strong> Creates private threads instead of channels, providing better organization and permissions control.
                </p>
                <div className="bg-blue-900/20 border border-blue-600/30 rounded-lg p-3 mt-4">
                  <p className="text-blue-300 text-sm">
                    💡 <strong>Pro Tip:</strong> Thread-based tickets are only visible to users with appropriate permissions, making them perfect for sensitive support issues.
                  </p>
                </div>
              </CardContent>
            </Card>

          </div>
        </main>
      </div>
    </div>
  );
}