import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import StatsOverview from "@/components/dashboard/stats-overview";
import BotStatusCards from "@/components/dashboard/bot-status-cards";
import RecentActivity from "@/components/dashboard/recent-activity";
import SystemStatus from "@/components/dashboard/system-status";
import BotSetup from "@/components/dashboard/bot-setup";
import ChannelStatsConfig from "@/components/dashboard/channel-stats-config";
import BoosterAnnouncements from "@/components/dashboard/booster-announcements";
import CustomEmbeds from "@/components/dashboard/custom-embeds";
import ReactionRoles from "@/components/dashboard/reaction-roles";
import EventsOverview from "@/components/dashboard/events-overview";
import PollsOverview from "@/components/dashboard/polls-overview";
import ModerationOverview from "@/components/dashboard/moderation-overview";
import RewardsOverview from "@/components/dashboard/rewards-overview";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Dashboard" subtitle="Manage your Discord bots and community" />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Bot Setup Section - Primary Focus */}
          <div className="mb-8">
            <BotSetup />
          </div>

          <StatsOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <BotStatusCards />
            <RecentActivity />
          </div>

          {/* System Status */}
          <div className="mb-8">
            <SystemStatus />
          </div>
        </main>
      </div>
    </div>
  );
}
