import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { FaLevelUpAlt, FaPlus, FaTrash, FaSave, FaBullhorn, FaHashtag, FaCoins, FaEnvelope, FaComment, FaSearch, FaTimes } from "react-icons/fa";

interface LevelReward {
  id: number;
  level: number;
  reward: string;
  roleId?: string;
  enabled: boolean;
}

export default function LevelSystem() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Level rewards data
  const [levelRewards, setLevelRewards] = useState<LevelReward[]>([
    { id: 1, level: 5, reward: 'Rising Star', roleId: '123456789', enabled: true },
    { id: 2, level: 10, reward: 'Level 10 Champion', roleId: '987654321', enabled: true },
    { id: 3, level: 25, reward: 'Veteran Member', roleId: '456789123', enabled: true },
    { id: 4, level: 50, reward: 'Elite Gamer', roleId: '789123456', enabled: true }
  ]);

  // Announcement settings
  const [announcementSettings, setAnnouncementSettings] = useState({
    enabled: true,
    useEmbed: true,
    customChannelId: '',
    customMessage: "🎉 Congratulations {user} on reaching Level {level}! You've earned the {reward} role!",
    pingMessage: "🎉 {user} leveled up!"
  });

  // Role selection for mentions
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [roleSearchOpen, setRoleSearchOpen] = useState(false);
  
  // Mock Discord roles data
  const mockRoles = [
    { id: '123456789', name: 'Admin', color: '#e74c3c' },
    { id: '987654321', name: 'Moderator', color: '#3498db' },
    { id: '456789123', name: 'VIP Member', color: '#f39c12' },
    { id: '789123456', name: 'Active Member', color: '#2ecc71' },
    { id: '321654987', name: 'Member', color: '#95a5a6' },
    { id: '654321987', name: 'Newcomer', color: '#9b59b6' },
    { id: '147258369', name: 'Bot Developer', color: '#e67e22' },
    { id: '963852741', name: 'Event Host', color: '#1abc9c' }
  ];

  const [newReward, setNewReward] = useState({
    level: 0,
    reward: '',
    roleId: '',
    enabled: true
  });

  // Helper functions for role management
  const addRole = (roleId: string) => {
    if (!selectedRoles.includes(roleId)) {
      setSelectedRoles([...selectedRoles, roleId]);
    }
  };

  const removeRole = (roleId: string) => {
    setSelectedRoles(selectedRoles.filter(id => id !== roleId));
  };

  const insertRoleMention = (roleId: string) => {
    const role = mockRoles.find(r => r.id === roleId);
    if (role) {
      const mention = `<@&${roleId}>`;
      const currentMessage = announcementSettings.pingMessage;
      setAnnouncementSettings(prev => ({
        ...prev,
        pingMessage: currentMessage + (currentMessage ? ' ' : '') + mention
      }));
    }
  };

  const addLevelReward = () => {
    if (newReward.level > 0 && newReward.reward.trim()) {
      const reward: LevelReward = {
        id: Date.now(),
        ...newReward
      };
      setLevelRewards(prev => [...prev, reward]);
      setNewReward({
        level: 0,
        reward: '',
        roleId: '',
        enabled: true
      });
      toast({
        title: "Success",
        description: "Level reward added successfully!",
      });
    }
  };

  const removeLevelReward = (id: number) => {
    setLevelRewards(prev => prev.filter(reward => reward.id !== id));
    toast({
      title: "Success",
      description: "Level reward removed successfully!",
    });
  };

  const toggleLevelReward = (id: number) => {
    setLevelRewards(prev => prev.map(reward => 
      reward.id === id ? { ...reward, enabled: !reward.enabled } : reward
    ));
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="dark min-h-screen bg-[#0b0f1e]" style={{ backgroundColor: '#0b0f1e', color: '#fafafa' }}>
      <div className="min-h-screen bg-[#0b0f1e] flex" style={{ backgroundColor: '#0b0f1e' }}>
        <Sidebar />
        <div className="flex-1 flex flex-col">
          <Header />
          <main className="flex-1 p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2 flex items-center">
                  <FaLevelUpAlt className="mr-3 text-[hsl(var(--gaming-amber))]" />
                  Level System
                </h1>
                <p className="text-gray-400">Reward users based on their experience levels and server engagement</p>
              </div>
            </div>

            {/* Level Rewards Configuration */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaCoins className="mr-3 text-[hsl(var(--gaming-amber))]" />
                  Level-Based Rewards
                  <span className="ml-auto text-sm bg-[hsl(var(--gaming-amber))]/20 text-[hsl(var(--gaming-amber))] px-2 py-1 rounded-full">
                    {levelRewards.filter(r => r.enabled).length} Active
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Automatically reward users when they reach specific experience levels. Perfect for recognizing long-term community engagement and encouraging continued participation.
                </p>
                
                {/* Current Level Rewards */}
                <div className="space-y-3">
                  {levelRewards.map((reward) => (
                    <div key={reward.id} className="flex items-center justify-between p-4 bg-[hsl(var(--gaming-muted))] rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FaLevelUpAlt className="text-[hsl(var(--gaming-amber))]" />
                        <div>
                          <div className="font-medium text-white">Level {reward.level}</div>
                          <div className="text-sm text-gray-400">{reward.reward}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={reward.enabled}
                          onCheckedChange={() => toggleLevelReward(reward.id)}
                        />
                        <Button
                          onClick={() => removeLevelReward(reward.id)}
                          size="sm"
                          variant="destructive"
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Add New Level Reward */}
                <div className="border-t border-[hsl(var(--gaming-border))] pt-4 space-y-3">
                  <h4 className="font-semibold text-white">Add New Level Reward</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <Label className="text-white">Target Level</Label>
                      <Input
                        type="number"
                        value={newReward.level || ''}
                        onChange={(e) => setNewReward(prev => ({ ...prev, level: parseInt(e.target.value) || 0 }))}
                        placeholder="15"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Reward Name</Label>
                      <Input
                        value={newReward.reward}
                        onChange={(e) => setNewReward(prev => ({ ...prev, reward: e.target.value }))}
                        placeholder="Level Master"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={addLevelReward} className="w-full bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80">
                        <FaPlus className="mr-2" />
                        Add Reward
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Level Up Announcements */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaBullhorn className="mr-3 text-[hsl(var(--gaming-accent))]" />
                  Level Up Announcements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Configure how level up announcements are sent to your community when users reach new levels.
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <FaBullhorn className="text-[hsl(var(--gaming-accent))]" />
                    <span className="text-white">Enable Level Up Announcements</span>
                  </div>
                  <Switch
                    checked={announcementSettings.enabled}
                    onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, enabled: checked }))}
                  />
                </div>

                {announcementSettings.enabled && (
                  <div className="space-y-4 pl-6">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <FaEnvelope className="text-[hsl(var(--gaming-primary))]" />
                        <span className="text-white text-sm">Use Embed</span>
                        <Switch
                          checked={announcementSettings.useEmbed}
                          onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, useEmbed: checked }))}
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <FaComment className="text-[hsl(var(--gaming-accent))]" />
                        <span className="text-white text-sm">Plain Text</span>
                        <Switch
                          checked={!announcementSettings.useEmbed}
                          onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, useEmbed: !checked }))}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-white">Announcement Channel</Label>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start border-[hsl(var(--gaming-border))] text-gray-400 hover:bg-[hsl(var(--gaming-muted))]"
                      >
                        <FaHashtag className="mr-2" />
                        Select Channel for Level Announcements
                      </Button>
                      <p className="text-xs text-gray-400 mt-1">
                        Choose where level up announcements will be sent
                      </p>
                    </div>
                    
                    {announcementSettings.useEmbed && (
                      <div>
                        <Label className="text-white">User Ping Message (Outside Embed)</Label>
                        <Textarea
                          value={announcementSettings.pingMessage}
                          onChange={(e) => setAnnouncementSettings(prev => ({ ...prev, pingMessage: e.target.value }))}
                          className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white h-16"
                          placeholder="🎉 {user} leveled up!"
                        />
                        <p className="text-xs text-gray-400 mt-1">
                          This message will appear above the embed to ping the user. Variables: {'{user}'}, {'{level}'}, {'{reward}'}
                        </p>
                        
                        {/* Role Selector */}
                        <div className="mt-3">
                          <Label className="text-white text-sm">Add Role Mentions</Label>
                          <div className="flex items-center space-x-2 mt-2">
                            <Popover open={roleSearchOpen} onOpenChange={setRoleSearchOpen}>
                              <PopoverTrigger asChild>
                                <Button
                                  variant="outline"
                                  className="border-[hsl(var(--gaming-border))] text-gray-400 hover:bg-[hsl(var(--gaming-muted))]"
                                >
                                  <FaSearch className="mr-2" />
                                  Add Role
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-[300px] p-0 bg-[hsl(var(--gaming-card))] border-[hsl(var(--gaming-border))]">
                                <Command className="bg-[hsl(var(--gaming-card))]">
                                  <CommandInput 
                                    placeholder="Search roles..." 
                                    className="text-white placeholder:text-gray-400"
                                  />
                                  <CommandEmpty className="text-gray-400 py-4 text-center">
                                    No roles found.
                                  </CommandEmpty>
                                  <CommandGroup className="max-h-60 overflow-auto">
                                    {mockRoles.map((role) => (
                                      <CommandItem
                                        key={role.id}
                                        value={role.name}
                                        onSelect={() => {
                                          insertRoleMention(role.id);
                                          setRoleSearchOpen(false);
                                        }}
                                        className="text-white hover:bg-[hsl(var(--gaming-hover))] cursor-pointer"
                                      >
                                        <div className="flex items-center space-x-2">
                                          <div 
                                            className="w-3 h-3 rounded-full"
                                            style={{ backgroundColor: role.color }}
                                          />
                                          <span>@{role.name}</span>
                                        </div>
                                      </CommandItem>
                                    ))}
                                  </CommandGroup>
                                </Command>
                              </PopoverContent>
                            </Popover>
                          </div>
                          <p className="text-xs text-gray-400 mt-1">
                            Click "Add Role" to search and insert role mentions into your ping message
                          </p>
                        </div>
                      </div>
                    )}
                    
                    <div>
                      <Label className="text-white">
                        {announcementSettings.useEmbed ? 'Embed Description' : 'Custom Message'}
                      </Label>
                      <Textarea
                        value={announcementSettings.customMessage}
                        onChange={(e) => setAnnouncementSettings(prev => ({ ...prev, customMessage: e.target.value }))}
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white h-20"
                        placeholder={announcementSettings.useEmbed 
                          ? "Congratulations! You have reached Level {level} and earned the {reward} role!" 
                          : "🎉 Congratulations {user} on reaching Level {level}!"
                        }
                      />
                      <p className="text-xs text-gray-400 mt-1">
                        {announcementSettings.useEmbed 
                          ? 'This text will appear inside the embed description'
                          : 'Variables: {user}, {level}, {reward}'
                        }
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* XP Configuration */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaCoins className="mr-3 text-[hsl(var(--gaming-amber))]" />
                  XP Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Configure how users earn experience points and level up in your server.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">XP per Message</Label>
                    <Input
                      type="number"
                      defaultValue={15}
                      className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      XP awarded for each message sent
                    </p>
                  </div>
                  <div>
                    <Label className="text-white">XP Multiplier Range</Label>
                    <Input
                      placeholder="1-2x"
                      defaultValue="1-2"
                      className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      Random multiplier range for XP gains
                    </p>
                  </div>
                  <div>
                    <Label className="text-white">Cooldown Period</Label>
                    <Input
                      type="number"
                      defaultValue={60}
                      className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      Seconds between XP gains (prevents spam)
                    </p>
                  </div>
                  <div>
                    <Label className="text-white">XP Required Formula</Label>
                    <Input
                      placeholder="level * 100"
                      defaultValue="level * 100"
                      className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      Formula to calculate XP needed for next level
                    </p>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <Button className="bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80 text-white">
                    <FaSave className="mr-2" />
                    Save Level System Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    </div>
  );
}