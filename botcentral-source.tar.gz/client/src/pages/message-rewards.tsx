import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { FaComments, FaPlus, FaTrash, FaSave, FaBullhorn, FaHashtag, FaEnvelope, FaComment, FaMedal, FaSearch, FaTimes } from "react-icons/fa";

interface MessageReward {
  id: number;
  messageCount: number;
  reward: string;
  roleId?: string;
  enabled: boolean;
}

export default function MessageRewards() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Message rewards data
  const [messageRewards, setMessageRewards] = useState<MessageReward[]>([
    { id: 1, messageCount: 50, reward: 'Chatty Newbie', roleId: '123456789', enabled: true },
    { id: 2, messageCount: 100, reward: 'Active Member', roleId: '987654321', enabled: true },
    { id: 3, messageCount: 500, reward: 'Super Chatty', roleId: '456789123', enabled: true },
    { id: 4, messageCount: 1000, reward: 'Discussion Master', roleId: '789123456', enabled: true }
  ]);

  // Announcement settings
  const [announcementSettings, setAnnouncementSettings] = useState({
    enabled: true,
    useEmbed: true,
    customChannelId: '',
    customMessage: "🎊 Amazing! {user} has sent {count} messages and earned the {reward} role!",
    pingMessage: "🎉 {user} reached a message milestone!"
  });

  // Role selection for mentions
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [roleSearchOpen, setRoleSearchOpen] = useState(false);
  
  // Mock Discord roles data
  const mockRoles = [
    { id: '123456789', name: 'Admin', color: '#e74c3c' },
    { id: '987654321', name: 'Moderator', color: '#3498db' },
    { id: '456789123', name: 'VIP Member', color: '#f39c12' },
    { id: '789123456', name: 'Active Member', color: '#2ecc71' },
    { id: '321654987', name: 'Member', color: '#95a5a6' },
    { id: '654321987', name: 'Newcomer', color: '#9b59b6' },
    { id: '147258369', name: 'Bot Developer', color: '#e67e22' },
    { id: '963852741', name: 'Event Host', color: '#1abc9c' }
  ];

  const [newReward, setNewReward] = useState({
    messageCount: 0,
    reward: '',
    roleId: '',
    enabled: true
  });

  // Helper functions for role management
  const addRole = (roleId: string) => {
    if (!selectedRoles.includes(roleId)) {
      setSelectedRoles([...selectedRoles, roleId]);
    }
  };

  const removeRole = (roleId: string) => {
    setSelectedRoles(selectedRoles.filter(id => id !== roleId));
  };

  const insertRoleMention = (roleId: string) => {
    const role = mockRoles.find(r => r.id === roleId);
    if (role) {
      const mention = `<@&${roleId}>`;
      const currentMessage = announcementSettings.pingMessage;
      setAnnouncementSettings(prev => ({
        ...prev,
        pingMessage: currentMessage + (currentMessage ? ' ' : '') + mention
      }));
    }
  };

  const addMessageReward = () => {
    if (newReward.messageCount > 0 && newReward.reward.trim()) {
      const reward: MessageReward = {
        id: Date.now(),
        ...newReward
      };
      setMessageRewards(prev => [...prev, reward]);
      setNewReward({
        messageCount: 0,
        reward: '',
        roleId: '',
        enabled: true
      });
      toast({
        title: "Success",
        description: "Message reward added successfully!",
      });
    }
  };

  const removeMessageReward = (id: number) => {
    setMessageRewards(prev => prev.filter(reward => reward.id !== id));
    toast({
      title: "Success",
      description: "Message reward removed successfully!",
    });
  };

  const toggleMessageReward = (id: number) => {
    setMessageRewards(prev => prev.map(reward => 
      reward.id === id ? { ...reward, enabled: !reward.enabled } : reward
    ));
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="dark min-h-screen bg-[#0b0f1e]" style={{ backgroundColor: '#0b0f1e', color: '#fafafa' }}>
      <div className="min-h-screen bg-[#0b0f1e] flex" style={{ backgroundColor: '#0b0f1e' }}>
        <Sidebar />
        <div className="flex-1 flex flex-col">
          <Header />
          <main className="flex-1 p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2 flex items-center">
                  <FaComments className="mr-3 text-[hsl(var(--gaming-accent))]" />
                  Message Rewards
                </h1>
                <p className="text-gray-400">Reward active members based on their message count and community engagement</p>
              </div>
            </div>

            {/* Message Rewards Configuration */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaMedal className="mr-3 text-[hsl(var(--gaming-accent))]" />
                  Message-Based Rewards
                  <span className="ml-auto text-sm bg-[hsl(var(--gaming-accent))]/20 text-[hsl(var(--gaming-accent))] px-2 py-1 rounded-full">
                    {messageRewards.filter(r => r.enabled).length} Active
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Reward active members based on their message count. Encourage participation and community discussion with milestone rewards.
                </p>
                
                {/* Current Message Rewards */}
                <div className="space-y-3">
                  {messageRewards.map((reward) => (
                    <div key={reward.id} className="flex items-center justify-between p-4 bg-[hsl(var(--gaming-muted))] rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FaComments className="text-[hsl(var(--gaming-accent))]" />
                        <div>
                          <div className="font-medium text-white">{reward.messageCount} Messages</div>
                          <div className="text-sm text-gray-400">{reward.reward}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={reward.enabled}
                          onCheckedChange={() => toggleMessageReward(reward.id)}
                        />
                        <Button
                          onClick={() => removeMessageReward(reward.id)}
                          size="sm"
                          variant="destructive"
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Add New Message Reward */}
                <div className="border-t border-[hsl(var(--gaming-border))] pt-4 space-y-3">
                  <h4 className="font-semibold text-white">Add New Message Reward</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <Label className="text-white">Message Count</Label>
                      <Input
                        type="number"
                        value={newReward.messageCount || ''}
                        onChange={(e) => setNewReward(prev => ({ ...prev, messageCount: parseInt(e.target.value) || 0 }))}
                        placeholder="250"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Reward Name</Label>
                      <Input
                        value={newReward.reward}
                        onChange={(e) => setNewReward(prev => ({ ...prev, reward: e.target.value }))}
                        placeholder="Active Chatter"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={addMessageReward} className="w-full bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80">
                        <FaPlus className="mr-2" />
                        Add Reward
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Message Reward Announcements */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaBullhorn className="mr-3 text-[hsl(var(--gaming-accent))]" />
                  Message Reward Announcements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Configure how message milestone announcements are sent when users reach message count goals.
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <FaBullhorn className="text-[hsl(var(--gaming-accent))]" />
                    <span className="text-white">Enable Message Reward Announcements</span>
                  </div>
                  <Switch
                    checked={announcementSettings.enabled}
                    onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, enabled: checked }))}
                  />
                </div>

                {announcementSettings.enabled && (
                  <div className="space-y-4 pl-6">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <FaEnvelope className="text-[hsl(var(--gaming-primary))]" />
                        <span className="text-white text-sm">Use Embed</span>
                        <Switch
                          checked={announcementSettings.useEmbed}
                          onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, useEmbed: checked }))}
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <FaComment className="text-[hsl(var(--gaming-accent))]" />
                        <span className="text-white text-sm">Plain Text</span>
                        <Switch
                          checked={!announcementSettings.useEmbed}
                          onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, useEmbed: !checked }))}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-white">Announcement Channel</Label>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start border-[hsl(var(--gaming-border))] text-gray-400 hover:bg-[hsl(var(--gaming-muted))]"
                      >
                        <FaHashtag className="mr-2" />
                        Select Channel for Message Announcements
                      </Button>
                      <p className="text-xs text-gray-400 mt-1">
                        Choose where message milestone announcements will be sent
                      </p>
                    </div>
                    
                    {announcementSettings.useEmbed && (
                      <div>
                        <Label className="text-white">User Ping Message (Outside Embed)</Label>
                        <Textarea
                          value={announcementSettings.pingMessage}
                          onChange={(e) => setAnnouncementSettings(prev => ({ ...prev, pingMessage: e.target.value }))}
                          className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white h-16"
                          placeholder="🎉 {user} reached a message milestone!"
                        />
                        <p className="text-xs text-gray-400 mt-1">
                          This message will appear above the embed to ping the user. Variables: {'{user}'}, {'{count}'}, {'{reward}'}
                        </p>
                        
                        {/* Role Selector */}
                        <div className="mt-3">
                          <Label className="text-white text-sm">Add Role Mentions</Label>
                          <div className="flex items-center space-x-2 mt-2">
                            <Popover open={roleSearchOpen} onOpenChange={setRoleSearchOpen}>
                              <PopoverTrigger asChild>
                                <Button
                                  variant="outline"
                                  className="border-[hsl(var(--gaming-border))] text-gray-400 hover:bg-[hsl(var(--gaming-muted))]"
                                >
                                  <FaSearch className="mr-2" />
                                  Add Role
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-[300px] p-0 bg-[hsl(var(--gaming-card))] border-[hsl(var(--gaming-border))]">
                                <Command className="bg-[hsl(var(--gaming-card))]">
                                  <CommandInput 
                                    placeholder="Search roles..." 
                                    className="text-white placeholder:text-gray-400"
                                  />
                                  <CommandEmpty className="text-gray-400 py-4 text-center">
                                    No roles found.
                                  </CommandEmpty>
                                  <CommandGroup className="max-h-60 overflow-auto">
                                    {mockRoles.map((role) => (
                                      <CommandItem
                                        key={role.id}
                                        value={role.name}
                                        onSelect={() => {
                                          insertRoleMention(role.id);
                                          setRoleSearchOpen(false);
                                        }}
                                        className="text-white hover:bg-[hsl(var(--gaming-hover))] cursor-pointer"
                                      >
                                        <div className="flex items-center space-x-2">
                                          <div 
                                            className="w-3 h-3 rounded-full"
                                            style={{ backgroundColor: role.color }}
                                          />
                                          <span>@{role.name}</span>
                                        </div>
                                      </CommandItem>
                                    ))}
                                  </CommandGroup>
                                </Command>
                              </PopoverContent>
                            </Popover>
                          </div>
                          <p className="text-xs text-gray-400 mt-1">
                            Click "Add Role" to search and insert role mentions into your ping message
                          </p>
                        </div>
                      </div>
                    )}
                    
                    <div>
                      <Label className="text-white">
                        {announcementSettings.useEmbed ? 'Embed Description' : 'Custom Message'}
                      </Label>
                      <Textarea
                        value={announcementSettings.customMessage}
                        onChange={(e) => setAnnouncementSettings(prev => ({ ...prev, customMessage: e.target.value }))}
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white h-20"
                        placeholder={announcementSettings.useEmbed 
                          ? "Amazing! You have sent {count} messages and earned the {reward} role!" 
                          : "🎊 Amazing! {user} has sent {count} messages!"
                        }
                      />
                      <p className="text-xs text-gray-400 mt-1">
                        {announcementSettings.useEmbed 
                          ? 'This text will appear inside the embed description'
                          : 'Variables: {user}, {count}, {reward}'
                        }
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Message Tracking Configuration */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaComments className="mr-3 text-[hsl(var(--gaming-accent))]" />
                  Message Tracking Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Configure how messages are tracked and counted for rewards.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Ignore Command Messages</Label>
                      <p className="text-xs text-gray-400 mt-1">Exclude bot command messages</p>
                    </div>
                    <Switch defaultChecked={true} />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Track Thread Messages</Label>
                      <p className="text-xs text-gray-400 mt-1">Include messages in threads</p>
                    </div>
                    <Switch defaultChecked={true} />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">Minimum Message Length</Label>
                    <Input
                      type="number"
                      defaultValue={5}
                      className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      Minimum characters to count message
                    </p>
                  </div>
                  <div>
                    <Label className="text-white">Message Cooldown</Label>
                    <Input
                      type="number"
                      defaultValue={5}
                      className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      Seconds between counted messages (spam protection)
                    </p>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <Button className="bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80 text-white">
                    <FaSave className="mr-2" />
                    Save Message Reward Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    </div>
  );
}