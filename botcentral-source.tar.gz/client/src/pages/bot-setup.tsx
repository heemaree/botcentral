import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { FaRobot, FaDiscord, FaCopy, FaCheck, FaCrown } from "react-icons/fa";
import Sidebar from "@/components/layout/sidebar";

export default function BotSetup() {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const { data: botConfig, isLoading } = useQuery({
    queryKey: ["/api/standard-bot/config"],
  });

  const { data: subscription } = useQuery({
    queryKey: ["/api/user/subscription"],
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({
      title: "Copied",
      description: "Client ID copied to clipboard",
    });
  };

  const botInviteUrl = botConfig ? 
    `https://discord.com/api/oauth2/authorize?client_id=${botConfig.clientId}&permissions=8&scope=bot` : 
    "";

  const isPremium = subscription?.subscriptionTier === "premium";

  return (
    <div className="flex h-screen bg-[hsl(224,71%,4%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-[hsl(224,71%,4%)] p-6">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-white mb-2">Bot Setup</h1>
              <p className="text-xl text-gray-400">Add the BotCentral standard bot to your Discord server</p>
            </div>

            {/* Setup Steps */}
            <div className="grid gap-6 mb-8">
              <Card className="bg-[hsl(230,12%,9%)] border-[hsl(30,3%,22%)]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <div className="w-8 h-8 bg-[hsl(258,84%,67%)] rounded-full flex items-center justify-center mr-3 text-white font-bold">
                      1
                    </div>
                    Add BotCentral Standard Bot
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {isLoading ? (
                    <div className="flex items-center justify-center p-8">
                      <div className="animate-spin w-8 h-8 border-4 border-[hsl(258,84%,67%)] border-t-transparent rounded-full"></div>
                    </div>
                  ) : botConfig ? (
                    <div className="space-y-4">
                      <p className="text-gray-400">
                        Use our standard bot to get started with BotCentral features immediately:
                      </p>
                      <div className="bg-[hsl(237,71%,7%)] rounded-lg p-4 space-y-3">
                        <div>
                          <Label className="text-white font-medium">Bot Name</Label>
                          <p className="text-gray-300">{botConfig.name}</p>
                        </div>
                        <div>
                          <Label className="text-white font-medium">Client ID</Label>
                          <div className="flex items-center space-x-2 mt-1">
                            <code className="bg-[hsl(230,12%,9%)] px-2 py-1 rounded text-gray-300 font-mono text-sm">
                              {botConfig.clientId}
                            </code>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => copyToClipboard(botConfig.clientId)}
                              className="h-8 px-2"
                            >
                              {copied ? <FaCheck className="h-3 w-3" /> : <FaCopy className="h-3 w-3" />}
                            </Button>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col space-y-2">
                        <Button 
                          onClick={() => window.open(botInviteUrl, '_blank')}
                          className="bg-[hsl(235,85%,62%)] hover:bg-[hsl(235,85%,62%)]/80 text-white flex items-center justify-center"
                        >
                          <FaDiscord className="mr-2" />
                          Add Bot to Server
                        </Button>
                        <p className="text-xs text-gray-500 text-center">
                          This will open Discord's bot authorization page
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-[hsl(47,100%,57%)]/20 border border-[hsl(47,100%,57%)]/50 rounded-lg p-4">
                      <p className="text-[hsl(47,100%,57%)] text-sm">
                        Bot configuration is loading...
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-[hsl(230,12%,9%)] border-[hsl(30,3%,22%)]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <div className="w-8 h-8 bg-[hsl(258,84%,67%)] rounded-full flex items-center justify-center mr-3 text-white font-bold">
                      2
                    </div>
                    Available Features
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400 mb-4">
                    Once the bot is added to your server, you can use these features:
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-[hsl(237,71%,7%)] rounded-lg p-4">
                      <h4 className="text-white font-medium mb-2">Free Features</h4>
                      <ul className="text-gray-300 text-sm space-y-1">
                        <li>• Custom Embeds (3 limit)</li>
                        <li>• Reaction Roles (3 limit)</li>
                        <li>• Basic Moderation</li>
                        <li>• Community Hub</li>
                        <li>• Events & Polls</li>
                      </ul>
                    </div>
                    <div className="bg-[hsl(237,71%,7%)] rounded-lg p-4">
                      <h4 className="text-white font-medium mb-2 flex items-center">
                        <FaCrown className="mr-2 text-[hsl(258,84%,67%)]" />
                        Premium Features
                      </h4>
                      <ul className="text-gray-300 text-sm space-y-1">
                        <li>• Unlimited Embeds</li>
                        <li>• Advanced Moderation</li>
                        <li>• Server Statistics</li>
                        <li>• Booster Announcements</li>
                        <li>• Custom Bot Token</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[hsl(230,12%,9%)] border-[hsl(30,3%,22%)]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <FaCrown className="mr-3 text-[hsl(258,84%,67%)]" />
                    Custom Bot Token (Premium)
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {isPremium ? (
                    <div>
                      <p className="text-gray-400 mb-4">
                        As a premium user, you can configure your own Discord bot token for personalized branding:
                      </p>
                      <Button 
                        onClick={() => window.location.href = '/premium-plans'}
                        className="bg-[hsl(258,84%,67%)] hover:bg-[hsl(258,84%,67%)]/80 text-white"
                      >
                        Configure Custom Bot Token
                      </Button>
                    </div>
                  ) : (
                    <div className="bg-[hsl(47,100%,57%)]/20 border border-[hsl(47,100%,57%)]/50 rounded-lg p-4">
                      <div className="flex items-start space-x-3">
                        <FaCrown className="text-[hsl(258,84%,67%)] mt-1" />
                        <div>
                          <h4 className="text-white font-medium mb-2">Premium Feature</h4>
                          <p className="text-gray-300 text-sm mb-3">
                            Custom bot tokens allow you to use your own Discord application with personalized name, avatar, and branding. This feature is available with a premium subscription.
                          </p>
                          <Button 
                            onClick={() => window.location.href = '/premium-plans'}
                            className="bg-[hsl(258,84%,67%)] hover:bg-[hsl(258,84%,67%)]/80 text-white"
                          >
                            Upgrade to Premium
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-[hsl(230,12%,9%)] border-[hsl(30,3%,22%)]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <div className="w-8 h-8 bg-[hsl(258,84%,67%)] rounded-full flex items-center justify-center mr-3 text-white font-bold">
                      3
                    </div>
                    Start Using BotCentral
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400 mb-4">
                    Ready to get started? Access all features from your dashboard:
                  </p>
                  <div className="flex space-x-3">
                    <Button 
                      onClick={() => window.location.href = '/'}
                      className="bg-[hsl(258,84%,67%)] hover:bg-[hsl(258,84%,67%)]/80 text-white"
                    >
                      Go to Dashboard
                    </Button>
                    <Button 
                      onClick={() => window.location.href = '/premium-plans'}
                      variant="outline"
                      className="border-[hsl(30,3%,22%)] text-white hover:bg-[hsl(237,71%,7%)]"
                    >
                      View Premium Plans
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}