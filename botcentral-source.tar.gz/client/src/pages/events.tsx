import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import UpcomingEvents from "@/components/dashboard/upcoming-events";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertEventSchema, type Event } from "@shared/schema";
import { z } from "zod";
import { FaCalendarAlt, FaPlus, FaUsers, FaTrophy, FaGamepad, FaFilm } from "react-icons/fa";

const eventFormSchema = insertEventSchema.extend({
  title: z.string().min(1, "Event title is required"),
  description: z.string().optional(),
  date: z.string().min(1, "Event date is required"),
  maxAttendees: z.number().optional(),
});

export default function Events() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const form = useForm<z.infer<typeof eventFormSchema>>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      title: "",
      description: "",
      date: "",
      attendeeCount: 0,
    },
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: events, isLoading: eventsLoading } = useQuery<Event[]>({
    queryKey: ["/api/events"],
    enabled: isAuthenticated,
  });

  const createEventMutation = useMutation({
    mutationFn: async (data: z.infer<typeof eventFormSchema>) => {
      await apiRequest("POST", "/api/events", {
        ...data,
        date: new Date(data.date).toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Event created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create event. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: z.infer<typeof eventFormSchema>) => {
    createEventMutation.mutate(data);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const isUpcoming = date > now;
    
    return {
      formatted: date.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
      isUpcoming,
      isPast: date < now,
    };
  };

  const getEventIcon = (title: string) => {
    const titleLower = title.toLowerCase();
    if (titleLower.includes("tournament") || titleLower.includes("competition")) {
      return <FaTrophy className="text-[hsl(var(--gaming-amber))]" />;
    }
    if (titleLower.includes("game") || titleLower.includes("gaming")) {
      return <FaGamepad className="text-[hsl(var(--gaming-cyan))]" />;
    }
    if (titleLower.includes("movie") || titleLower.includes("film")) {
      return <FaFilm className="text-[hsl(var(--gaming-purple))]" />;
    }
    return <FaCalendarAlt className="text-[hsl(var(--gaming-emerald))]" />;
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const upcomingEvents = events?.filter(event => formatDate(event.date).isUpcoming) || [];
  const pastEvents = events?.filter(event => formatDate(event.date).isPast) || [];

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Events" subtitle="Schedule and manage community events" />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Upcoming Events Widget */}
          <div className="mb-8">
            <UpcomingEvents />
          </div>
          
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-2xl font-bold text-white">Community Events</h2>
              <p className="text-gray-400">Organize tournaments, meetups, and activities</p>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))] text-white glow-effect">
                  <FaPlus className="mr-2" />
                  Create Event
                </Button>
              </DialogTrigger>
              <DialogContent className="gaming-card border-[hsl(var(--gaming-border))] text-white">
                <DialogHeader>
                  <DialogTitle>Create New Event</DialogTitle>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Event Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Weekly Tournament" {...field} className="gaming-bg border-[hsl(var(--gaming-border))] text-white" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Join us for our weekly community tournament..." {...field} className="gaming-bg border-[hsl(var(--gaming-border))] text-white" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date & Time</FormLabel>
                          <FormControl>
                            <Input type="datetime-local" {...field} className="gaming-bg border-[hsl(var(--gaming-border))] text-white" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="maxAttendees"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Max Attendees (Optional)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="50" 
                              {...field} 
                              onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                              className="gaming-bg border-[hsl(var(--gaming-border))] text-white" 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="flex gap-2 pt-4">
                      <Button type="submit" disabled={createEventMutation.isPending} className="flex-1 bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))]">
                        {createEventMutation.isPending ? "Creating..." : "Create Event"}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)} className="border-[hsl(var(--gaming-border))] text-gray-300 hover:text-white">
                        Cancel
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          {eventsLoading ? (
            <div className="space-y-6">
              <div className="animate-pulse">
                <div className="h-6 bg-gray-700 rounded w-48 mb-4"></div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} className="gaming-card border-[hsl(var(--gaming-border))]">
                      <CardContent className="p-6">
                        <div className="space-y-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-12 h-12 bg-gray-700 rounded-lg"></div>
                            <div className="space-y-2">
                              <div className="h-4 bg-gray-700 rounded w-32"></div>
                              <div className="h-3 bg-gray-700 rounded w-24"></div>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <div className="h-3 bg-gray-700 rounded w-full"></div>
                            <div className="h-3 bg-gray-700 rounded w-3/4"></div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-8">
              {/* Upcoming Events */}
              <div>
                <h3 className="text-xl font-semibold text-white mb-4">Upcoming Events</h3>
                {upcomingEvents.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {upcomingEvents.map((event) => {
                      const dateInfo = formatDate(event.date);
                      return (
                        <Card key={event.id} className="gaming-card border-[hsl(var(--gaming-border))] hover:border-[hsl(var(--discord-primary))] transition-all">
                          <CardContent className="p-6">
                            <div className="flex items-center space-x-3 mb-4">
                              <div className="w-12 h-12 bg-[hsl(var(--gaming-emerald))]/20 rounded-lg flex items-center justify-center">
                                {getEventIcon(event.title)}
                              </div>
                              <div>
                                <h4 className="font-semibold text-white">{event.title}</h4>
                                <p className="text-sm text-gray-400">{dateInfo.formatted}</p>
                              </div>
                            </div>
                            
                            {event.description && (
                              <p className="text-gray-300 text-sm mb-4">{event.description}</p>
                            )}
                            
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <FaUsers className="text-gray-400 text-sm" />
                                <span className="text-sm text-gray-400">
                                  {event.attendeeCount || 0} attending
                                  {event.maxAttendees && ` / ${event.maxAttendees}`}
                                </span>
                              </div>
                              <Badge className="bg-[hsl(var(--gaming-emerald))]/20 text-[hsl(var(--gaming-emerald))] border-[hsl(var(--gaming-emerald))]">
                                Upcoming
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                ) : (
                  <Card className="gaming-card border-[hsl(var(--gaming-border))]">
                    <CardContent className="text-center py-12">
                      <FaCalendarAlt className="text-6xl text-gray-600 mx-auto mb-4" />
                      <h4 className="text-lg font-semibold text-white mb-2">No Upcoming Events</h4>
                      <p className="text-gray-400 mb-4">Create your first community event</p>
                      <Button 
                        onClick={() => setIsCreateDialogOpen(true)}
                        className="bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))] text-white"
                      >
                        <FaPlus className="mr-2" />
                        Create Event
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Past Events */}
              {pastEvents.length > 0 && (
                <div>
                  <h3 className="text-xl font-semibold text-white mb-4">Past Events</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {pastEvents.map((event) => {
                      const dateInfo = formatDate(event.date);
                      return (
                        <Card key={event.id} className="gaming-card border-[hsl(var(--gaming-border))] opacity-75">
                          <CardContent className="p-6">
                            <div className="flex items-center space-x-3 mb-4">
                              <div className="w-12 h-12 bg-gray-600/20 rounded-lg flex items-center justify-center">
                                {getEventIcon(event.title)}
                              </div>
                              <div>
                                <h4 className="font-semibold text-white">{event.title}</h4>
                                <p className="text-sm text-gray-400">{dateInfo.formatted}</p>
                              </div>
                            </div>
                            
                            {event.description && (
                              <p className="text-gray-300 text-sm mb-4">{event.description}</p>
                            )}
                            
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <FaUsers className="text-gray-400 text-sm" />
                                <span className="text-sm text-gray-400">
                                  {event.attendeeCount || 0} attended
                                </span>
                              </div>
                              <Badge variant="secondary" className="text-gray-500">
                                Completed
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
