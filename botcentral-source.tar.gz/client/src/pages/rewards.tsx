import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { type LeaderboardEntry } from "@shared/schema";
import { FaTrophy, FaGift, FaComments, FaUserPlus, FaCog, FaPlus, FaTrash, FaSave, FaEye, FaBullhorn, FaHashtag, FaAt, FaCoins, FaStar, FaLevelUpAlt, FaMedal, FaGamepad, FaUsers, FaEnvelope, FaComment, FaSearch, FaTimes } from "react-icons/fa";

interface RewardRule {
  id: number;
  type: 'level' | 'message' | 'invite';
  threshold: number;
  reward: string;
  roleId?: string;
  channelId?: string;
  enabled: boolean;
}

export default function Rewards() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Leaderboard data queries
  const { data: messagesLeaderboard } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard/messages"],
    enabled: isAuthenticated,
  });

  const { data: invitersLeaderboard } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard/inviters"],
    enabled: isAuthenticated,
  });

  const { data: engagementLeaderboard } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard/engagement"],
    enabled: isAuthenticated,
  });

  const { data: levelsLeaderboard } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard/levels"],
    enabled: isAuthenticated,
  });

  // Mock reward rules data - replace with real API calls
  const [rewardRules, setRewardRules] = useState<RewardRule[]>([
    { id: 1, type: 'level', threshold: 10, reward: 'Level 10 Champion', roleId: '123456789', enabled: true },
    { id: 2, type: 'message', threshold: 100, reward: 'Chatty Member', roleId: '987654321', enabled: true },
    { id: 3, type: 'invite', threshold: 5, reward: 'Community Builder', roleId: '456789123', enabled: true }
  ]);

  // Announcement system state
  const [announcementSettings, setAnnouncementSettings] = useState({
    levelUpEnabled: true,
    messageRewardEnabled: true,
    inviteRewardEnabled: true,
    customChannelId: '',
    useEmbed: {
      level: true,
      message: true,
      invite: true
    },
    customMessage: {
      level: "🎉 Congratulations {user} on reaching Level {level}! You've earned the {reward} role!",
      message: "🎊 Amazing! {user} has sent {count} messages and earned the {reward} role!",
      invite: "🚀 Fantastic work {user}! You've invited {count} members and earned the {reward} role!"
    },
    pingMessage: {
      level: "🎉 {user} leveled up!",
      message: "🎊 {user} earned a message reward!",
      invite: "🚀 {user} reached an invite milestone!"
    }
  });

  // Role selection for mentions
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [roleSearchOpen, setRoleSearchOpen] = useState(false);
  
  // Mock Discord roles data
  const mockRoles = [
    { id: '123456789', name: 'Admin', color: '#e74c3c' },
    { id: '987654321', name: 'Moderator', color: '#3498db' },
    { id: '456789123', name: 'VIP Member', color: '#f39c12' },
    { id: '789123456', name: 'Active Member', color: '#2ecc71' },
    { id: '321654987', name: 'Member', color: '#95a5a6' },
    { id: '654321987', name: 'Newcomer', color: '#9b59b6' },
    { id: '147258369', name: 'Bot Developer', color: '#e67e22' },
    { id: '963852741', name: 'Event Host', color: '#1abc9c' }
  ];

  const [newRule, setNewRule] = useState({
    type: 'level' as 'level' | 'message' | 'invite',
    threshold: 0,
    reward: '',
    roleId: '',
    enabled: true
  });

  // Helper functions for role management
  const addRole = (roleId: string) => {
    if (!selectedRoles.includes(roleId)) {
      setSelectedRoles([...selectedRoles, roleId]);
    }
  };

  const removeRole = (roleId: string) => {
    setSelectedRoles(selectedRoles.filter(id => id !== roleId));
  };

  const insertRoleMention = (roleId: string, rewardType: 'level' | 'message' | 'invite') => {
    const role = mockRoles.find(r => r.id === roleId);
    if (role) {
      const mention = `<@&${roleId}>`;
      const currentMessage = announcementSettings.pingMessage[rewardType];
      setAnnouncementSettings(prev => ({
        ...prev,
        pingMessage: {
          ...prev.pingMessage,
          [rewardType]: currentMessage + (currentMessage ? ' ' : '') + mention
        }
      }));
    }
  };

  const addRewardRule = () => {
    if (newRule.threshold > 0 && newRule.reward.trim()) {
      const rule: RewardRule = {
        id: Date.now(),
        ...newRule
      };
      setRewardRules(prev => [...prev, rule]);
      setNewRule({
        type: 'level',
        threshold: 0,
        reward: '',
        roleId: '',
        enabled: true
      });
    }
  };

  const removeRewardRule = (id: number) => {
    setRewardRules(prev => prev.filter(rule => rule.id !== id));
  };

  const toggleRewardRule = (id: number) => {
    setRewardRules(prev => prev.map(rule => 
      rule.id === id ? { ...rule, enabled: !rule.enabled } : rule
    ));
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return "text-[hsl(var(--gaming-amber))]";
      case 2: return "text-gray-300";
      case 3: return "text-[hsl(var(--gaming-purple))]";
      default: return "text-gray-400";
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <FaTrophy className="text-[hsl(var(--gaming-amber))]" />;
      case 2: return <FaMedal className="text-gray-300" />;
      case 3: return <FaMedal className="text-[hsl(var(--gaming-purple))]" />;
      default: return <span className="text-gray-400 font-mono">#{rank}</span>;
    }
  };

  const LeaderboardCard = ({ 
    entries, 
    title, 
    icon, 
    scoreLabel,
    isLoading 
  }: { 
    entries?: LeaderboardEntry[], 
    title: string, 
    icon: React.ReactNode,
    scoreLabel: string,
    isLoading?: boolean 
  }) => (
    <Card className="gaming-card border-[hsl(var(--gaming-border))]">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-white flex items-center">
          {icon}
          <span className="ml-3">{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse flex items-center space-x-3 p-3">
                <div className="w-8 h-8 bg-gray-700 rounded"></div>
                <div className="w-10 h-10 bg-gray-700 rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-700 rounded w-32"></div>
                  <div className="h-3 bg-gray-700 rounded w-16"></div>
                </div>
                <div className="w-12 h-4 bg-gray-700 rounded"></div>
              </div>
            ))}
          </div>
        ) : entries && entries.length > 0 ? (
          <div className="space-y-3">
            {entries.slice(0, 10).map((entry, index) => {
              const rank = index + 1;
              return (
                <div key={entry.id} className="flex items-center space-x-3 p-3 rounded-lg bg-[hsl(var(--gaming-muted))] hover:bg-[hsl(var(--gaming-muted))]/80 transition-colors">
                  <div className={`flex items-center justify-center w-8 h-8 ${getRankColor(rank)}`}>
                    {getRankIcon(rank)}
                  </div>
                  <div className="w-10 h-10 bg-gradient-to-br from-[hsl(var(--gaming-primary))] to-[hsl(var(--gaming-accent))] rounded-full flex items-center justify-center">
                    <FaUsers className="text-white text-sm" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-white">{entry.username}</div>
                    <div className="text-sm text-gray-400">#{entry.userId}</div>
                  </div>
                  <Badge className="bg-[hsl(var(--gaming-accent))] text-white">
                    {entry.score} {scoreLabel}
                  </Badge>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-400">
            <FaTrophy className="mx-auto text-4xl mb-4 opacity-50" />
            <p>No leaderboard data available yet.</p>
            <p className="text-sm mt-2">Start engaging to see rankings!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="dark min-h-screen bg-[#0b0f1e]" style={{ backgroundColor: '#0b0f1e', color: '#fafafa' }}>
      <div className="min-h-screen bg-[#0b0f1e] flex" style={{ backgroundColor: '#0b0f1e' }}>
        <Sidebar />
        <div className="flex-1 flex flex-col">
          <Header />
          <main className="flex-1 p-6 space-y-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Reward System</h1>
              <p className="text-gray-400">Set up automated rewards for levels, messages, and invites</p>
            </div>
          </div>

          {/* Level System Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <FaLevelUpAlt className="text-2xl text-[hsl(var(--gaming-amber))]" />
              <h2 className="text-2xl font-bold text-white">Level System</h2>
            </div>
            
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaLevelUpAlt className="mr-3 text-[hsl(var(--gaming-amber))]" />
                  Level-Based Rewards
                  <span className="ml-auto text-sm bg-[hsl(var(--gaming-amber))]/20 text-[hsl(var(--gaming-amber))] px-2 py-1 rounded-full">
                    {rewardRules.filter(r => r.type === 'level' && r.enabled).length} Active
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Automatically reward users when they reach specific experience levels. Perfect for recognizing long-term community engagement.
                </p>
                
                {/* Level Reward Rules */}
                <div className="space-y-3">
                  {rewardRules.filter(rule => rule.type === 'level').map((rule) => (
                    <div key={rule.id} className="flex items-center justify-between p-4 bg-[hsl(var(--gaming-muted))] rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FaCoins className="text-[hsl(var(--gaming-amber))]" />
                        <div>
                          <div className="font-medium text-white">Level {rule.threshold}</div>
                          <div className="text-sm text-gray-400">{rule.reward}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={rule.enabled}
                          onCheckedChange={() => toggleRewardRule(rule.id)}
                        />
                        <Button
                          onClick={() => removeRewardRule(rule.id)}
                          size="sm"
                          variant="destructive"
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Add New Level Reward */}
                <div className="border-t border-[hsl(var(--gaming-border))] pt-4 space-y-3">
                  <h4 className="font-semibold text-white">Add Level Reward</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <Label className="text-white">Target Level</Label>
                      <Input
                        type="number"
                        value={newRule.type === 'level' ? newRule.threshold : ''}
                        onChange={(e) => setNewRule(prev => ({ ...prev, type: 'level', threshold: parseInt(e.target.value) || 0 }))}
                        placeholder="10"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Reward Name</Label>
                      <Input
                        value={newRule.type === 'level' ? newRule.reward : ''}
                        onChange={(e) => setNewRule(prev => ({ ...prev, type: 'level', reward: e.target.value }))}
                        placeholder="Level Master"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={addRewardRule} className="w-full bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80">
                        <FaPlus className="mr-2" />
                        Add Reward
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Announcement Options for Level */}
                <div className="border-t border-[hsl(var(--gaming-border))] pt-4 space-y-3">
                  <h4 className="font-semibold text-white">Level Up Announcements</h4>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <FaBullhorn className="text-[hsl(var(--gaming-accent))]" />
                      <span className="text-white">Enable Level Up Announcements</span>
                    </div>
                    <Switch
                      checked={announcementSettings.levelUpEnabled}
                      onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, levelUpEnabled: checked }))}
                    />
                  </div>

                  {announcementSettings.levelUpEnabled && (
                    <div className="space-y-3 pl-6">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <FaEnvelope className="text-[hsl(var(--gaming-primary))]" />
                          <span className="text-white text-sm">Use Embed</span>
                          <Switch
                            checked={announcementSettings.useEmbed.level}
                            onCheckedChange={(checked) => setAnnouncementSettings(prev => ({
                              ...prev,
                              useEmbed: { ...prev.useEmbed, level: checked }
                            }))}
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <FaComment className="text-[hsl(var(--gaming-accent))]" />
                          <span className="text-white text-sm">Plain Text</span>
                          <Switch
                            checked={!announcementSettings.useEmbed.level}
                            onCheckedChange={(checked) => setAnnouncementSettings(prev => ({
                              ...prev,
                              useEmbed: { ...prev.useEmbed, level: !checked }
                            }))}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-white">Custom Message</Label>
                        <Textarea
                          value={announcementSettings.customMessage.level}
                          onChange={(e) => setAnnouncementSettings(prev => ({
                            ...prev,
                            customMessage: { ...prev.customMessage, level: e.target.value }
                          }))}
                          className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white h-20"
                          placeholder="🎉 Congratulations {user} on reaching Level {level}!"
                        />
                        <p className="text-xs text-gray-400 mt-1">
                          Variables: {'{user}'}, {'{level}'}, {'{reward}'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Message Rewards Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <FaComments className="text-2xl text-[hsl(var(--gaming-accent))]" />
              <h2 className="text-2xl font-bold text-white">Message Rewards</h2>
            </div>
            
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaComments className="mr-3 text-[hsl(var(--gaming-accent))]" />
                  Message-Based Rewards
                  <span className="ml-auto text-sm bg-[hsl(var(--gaming-accent))]/20 text-[hsl(var(--gaming-accent))] px-2 py-1 rounded-full">
                    {rewardRules.filter(r => r.type === 'message' && r.enabled).length} Active
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Reward active members based on their message count. Encourage participation and community discussion.
                </p>
                
                {/* Message Reward Rules */}
                <div className="space-y-3">
                  {rewardRules.filter(rule => rule.type === 'message').map((rule) => (
                    <div key={rule.id} className="flex items-center justify-between p-4 bg-[hsl(var(--gaming-muted))] rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FaComments className="text-[hsl(var(--gaming-accent))]" />
                        <div>
                          <div className="font-medium text-white">{rule.threshold} Messages</div>
                          <div className="text-sm text-gray-400">{rule.reward}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={rule.enabled}
                          onCheckedChange={() => toggleRewardRule(rule.id)}
                        />
                        <Button
                          onClick={() => removeRewardRule(rule.id)}
                          size="sm"
                          variant="destructive"
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Add New Message Reward */}
                <div className="border-t border-[hsl(var(--gaming-border))] pt-4 space-y-3">
                  <h4 className="font-semibold text-white">Add Message Reward</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <Label className="text-white">Message Count</Label>
                      <Input
                        type="number"
                        value={newRule.type === 'message' ? newRule.threshold : ''}
                        onChange={(e) => setNewRule(prev => ({ ...prev, type: 'message', threshold: parseInt(e.target.value) || 0 }))}
                        placeholder="100"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Reward Name</Label>
                      <Input
                        value={newRule.type === 'message' ? newRule.reward : ''}
                        onChange={(e) => setNewRule(prev => ({ ...prev, type: 'message', reward: e.target.value }))}
                        placeholder="Active Chatter"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={addRewardRule} className="w-full bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80">
                        <FaPlus className="mr-2" />
                        Add Reward
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Announcement Options for Messages */}
                <div className="border-t border-[hsl(var(--gaming-border))] pt-4 space-y-3">
                  <h4 className="font-semibold text-white">Message Reward Announcements</h4>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <FaBullhorn className="text-[hsl(var(--gaming-accent))]" />
                      <span className="text-white">Enable Message Reward Announcements</span>
                    </div>
                    <Switch
                      checked={announcementSettings.messageRewardEnabled}
                      onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, messageRewardEnabled: checked }))}
                    />
                  </div>

                  {announcementSettings.messageRewardEnabled && (
                    <div className="space-y-3 pl-6">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <FaEnvelope className="text-[hsl(var(--gaming-primary))]" />
                          <span className="text-white text-sm">Use Embed</span>
                          <Switch
                            checked={announcementSettings.useEmbed.message}
                            onCheckedChange={(checked) => setAnnouncementSettings(prev => ({
                              ...prev,
                              useEmbed: { ...prev.useEmbed, message: checked }
                            }))}
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <FaComment className="text-[hsl(var(--gaming-accent))]" />
                          <span className="text-white text-sm">Plain Text</span>
                          <Switch
                            checked={!announcementSettings.useEmbed.message}
                            onCheckedChange={(checked) => setAnnouncementSettings(prev => ({
                              ...prev,
                              useEmbed: { ...prev.useEmbed, message: !checked }
                            }))}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-white">Custom Message</Label>
                        <Textarea
                          value={announcementSettings.customMessage.message}
                          onChange={(e) => setAnnouncementSettings(prev => ({
                            ...prev,
                            customMessage: { ...prev.customMessage, message: e.target.value }
                          }))}
                          className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white h-20"
                          placeholder="🎊 Amazing! {user} has sent {count} messages!"
                        />
                        <p className="text-xs text-gray-400 mt-1">
                          Variables: {'{user}'}, {'{count}'}, {'{reward}'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Invite Rewards Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <FaUserPlus className="text-2xl text-[hsl(var(--gaming-primary))]" />
              <h2 className="text-2xl font-bold text-white">Invite Rewards</h2>
            </div>
            
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaUserPlus className="mr-3 text-[hsl(var(--gaming-primary))]" />
                  Invite-Based Rewards
                  <span className="ml-auto text-sm bg-[hsl(var(--gaming-primary))]/20 text-[hsl(var(--gaming-primary))] px-2 py-1 rounded-full">
                    {rewardRules.filter(r => r.type === 'invite' && r.enabled).length} Active
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">
                  Reward community builders who bring new members to your server. Encourage growth through referrals.
                </p>
                
                {/* Invite Reward Rules */}
                <div className="space-y-3">
                  {rewardRules.filter(rule => rule.type === 'invite').map((rule) => (
                    <div key={rule.id} className="flex items-center justify-between p-4 bg-[hsl(var(--gaming-muted))] rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FaUserPlus className="text-[hsl(var(--gaming-primary))]" />
                        <div>
                          <div className="font-medium text-white">{rule.threshold} Invites</div>
                          <div className="text-sm text-gray-400">{rule.reward}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={rule.enabled}
                          onCheckedChange={() => toggleRewardRule(rule.id)}
                        />
                        <Button
                          onClick={() => removeRewardRule(rule.id)}
                          size="sm"
                          variant="destructive"
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Add New Invite Reward */}
                <div className="border-t border-[hsl(var(--gaming-border))] pt-4 space-y-3">
                  <h4 className="font-semibold text-white">Add Invite Reward</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <Label className="text-white">Invite Count</Label>
                      <Input
                        type="number"
                        value={newRule.type === 'invite' ? newRule.threshold : ''}
                        onChange={(e) => setNewRule(prev => ({ ...prev, type: 'invite', threshold: parseInt(e.target.value) || 0 }))}
                        placeholder="5"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Reward Name</Label>
                      <Input
                        value={newRule.type === 'invite' ? newRule.reward : ''}
                        onChange={(e) => setNewRule(prev => ({ ...prev, type: 'invite', reward: e.target.value }))}
                        placeholder="Community Builder"
                        className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={addRewardRule} className="w-full bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80">
                        <FaPlus className="mr-2" />
                        Add Reward
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Announcement Options for Invites */}
                <div className="border-t border-[hsl(var(--gaming-border))] pt-4 space-y-3">
                  <h4 className="font-semibold text-white">Invite Reward Announcements</h4>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <FaBullhorn className="text-[hsl(var(--gaming-accent))]" />
                      <span className="text-white">Enable Invite Reward Announcements</span>
                    </div>
                    <Switch
                      checked={announcementSettings.inviteRewardEnabled}
                      onCheckedChange={(checked) => setAnnouncementSettings(prev => ({ ...prev, inviteRewardEnabled: checked }))}
                    />
                  </div>

                  {announcementSettings.inviteRewardEnabled && (
                    <div className="space-y-3 pl-6">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <FaEnvelope className="text-[hsl(var(--gaming-primary))]" />
                          <span className="text-white text-sm">Use Embed</span>
                          <Switch
                            checked={announcementSettings.useEmbed.invite}
                            onCheckedChange={(checked) => setAnnouncementSettings(prev => ({
                              ...prev,
                              useEmbed: { ...prev.useEmbed, invite: checked }
                            }))}
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <FaComment className="text-[hsl(var(--gaming-accent))]" />
                          <span className="text-white text-sm">Plain Text</span>
                          <Switch
                            checked={!announcementSettings.useEmbed.invite}
                            onCheckedChange={(checked) => setAnnouncementSettings(prev => ({
                              ...prev,
                              useEmbed: { ...prev.useEmbed, invite: !checked }
                            }))}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-white">Custom Message</Label>
                        <Textarea
                          value={announcementSettings.customMessage.invite}
                          onChange={(e) => setAnnouncementSettings(prev => ({
                            ...prev,
                            customMessage: { ...prev.customMessage, invite: e.target.value }
                          }))}
                          className="bg-[hsl(var(--gaming-muted))] border-[hsl(var(--gaming-border))] text-white h-20"
                          placeholder="🚀 Fantastic work {user}! You've invited {count} members!"
                        />
                        <p className="text-xs text-gray-400 mt-1">
                          Variables: {'{user}'}, {'{count}'}, {'{reward}'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Leaderboards Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <FaTrophy className="text-2xl text-[hsl(var(--gaming-amber))]" />
              <h2 className="text-2xl font-bold text-white">Leaderboards</h2>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <LeaderboardCard
                entries={invitersLeaderboard}
                title="Top Inviters"
                icon={<FaUserPlus className="text-[hsl(var(--gaming-primary))]" />}
                scoreLabel="invites"
                isLoading={!invitersLeaderboard}
              />

              <LeaderboardCard
                entries={engagementLeaderboard}
                title="Most Engaged Members"
                icon={<FaComments className="text-[hsl(var(--gaming-accent))]" />}
                scoreLabel="messages"
                isLoading={!engagementLeaderboard}
              />

              <LeaderboardCard
                entries={levelsLeaderboard}
                title="Highest Level Members"
                icon={<FaTrophy className="text-[hsl(var(--gaming-amber))]" />}
                scoreLabel="XP"
                isLoading={!levelsLeaderboard}
              />

              <LeaderboardCard
                entries={messagesLeaderboard}
                title="Most Active Messagers"
                icon={<FaGamepad className="text-[hsl(var(--gaming-purple))]" />}
                scoreLabel="messages"
                isLoading={!messagesLeaderboard}
              />
            </div>
          </div>

          {/* Setup Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <FaCog className="text-2xl text-[hsl(var(--gaming-accent))]" />
              <h2 className="text-2xl font-bold text-white">Global Setup</h2>
            </div>
            
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaCog className="mr-3 text-[hsl(var(--gaming-accent))]" />
                  Global Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-white">Default Announcement Channel</Label>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start border-[hsl(var(--gaming-border))] text-gray-400 hover:bg-[hsl(var(--gaming-muted))]"
                  >
                    <FaHashtag className="mr-2" />
                    Select Channel for All Announcements
                  </Button>
                  <p className="text-xs text-gray-400 mt-1">
                    Choose where all reward announcements will be sent by default
                  </p>
                </div>

                <div className="flex justify-end pt-4">
                  <Button className="bg-[hsl(var(--gaming-primary))] hover:bg-[hsl(var(--gaming-primary))]/80 text-white">
                    <FaSave className="mr-2" />
                    Save All Reward Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          </main>
        </div>
      </div>
    </div>
  );
}