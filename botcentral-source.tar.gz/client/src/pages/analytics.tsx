import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FaChartLine, FaUsers, FaComments, FaRobot, FaCalendarAlt, FaArrowUp } from "react-icons/fa";

export default function Analytics() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const analyticsData = [
    {
      title: "Server Growth",
      value: "127",
      change: "+12%",
      trend: "up",
      icon: <FaUsers className="text-[hsl(var(--gaming-emerald))]" />,
      description: "Total servers using your bots"
    },
    {
      title: "Active Users",
      value: "25.3K",
      change: "+8.4%",
      trend: "up",
      icon: <FaUsers className="text-[hsl(var(--gaming-cyan))]" />,
      description: "Users interacting with bots"
    },
    {
      title: "Commands/Day",
      value: "8.7K",
      change: "+15.2%",
      trend: "up",
      icon: <FaRobot className="text-[hsl(var(--gaming-purple))]" />,
      description: "Daily command executions"
    },
    {
      title: "Event Participation",
      value: "89%",
      change: "+5.1%",
      trend: "up",
      icon: <FaCalendarAlt className="text-[hsl(var(--gaming-amber))]" />,
      description: "Average event attendance rate"
    }
  ];

  const engagementMetrics = [
    { label: "Messages per Day", value: "1,234", color: "gaming-cyan" },
    { label: "Active Voice Channels", value: "23", color: "gaming-purple" },
    { label: "Reaction Rate", value: "76%", color: "gaming-emerald" },
    { label: "User Retention", value: "82%", color: "gaming-amber" }
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Analytics" subtitle="Detailed insights and performance metrics" />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {analyticsData.map((metric, index) => (
              <Card key={index} className="gaming-card border-[hsl(var(--gaming-border))] hover:border-[hsl(var(--discord-primary))] transition-all">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm font-medium">{metric.title}</p>
                      <p className="text-3xl font-bold text-white mt-1">{metric.value}</p>
                      <div className="flex items-center mt-2">
                        <FaArrowUp className="text-[hsl(var(--gaming-emerald))] text-sm mr-1" />
                        <span className="text-[hsl(var(--gaming-emerald))] text-sm font-medium">{metric.change}</span>
                        <span className="text-gray-400 text-sm ml-1">this month</span>
                      </div>
                    </div>
                    <div className="w-12 h-12 bg-current/20 rounded-lg flex items-center justify-center">
                      {metric.icon}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Bot Performance */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaRobot className="mr-3 text-[hsl(var(--gaming-purple))]" />
                  Bot Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 gaming-bg rounded-lg">
                    <div>
                      <h4 className="font-medium text-white">ModBot Pro</h4>
                      <p className="text-sm text-gray-400">Uptime: 99.9%</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-[hsl(var(--gaming-emerald))] font-medium">3.2K commands</p>
                      <p className="text-xs text-gray-400">today</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 gaming-bg rounded-lg">
                    <div>
                      <h4 className="font-medium text-white">EventMaster</h4>
                      <p className="text-sm text-gray-400">Uptime: 98.7%</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-[hsl(var(--gaming-cyan))] font-medium">1.8K commands</p>
                      <p className="text-xs text-gray-400">today</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 gaming-bg rounded-lg">
                    <div>
                      <h4 className="font-medium text-white">MusicBot</h4>
                      <p className="text-sm text-gray-400">Uptime: 97.3%</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-[hsl(var(--gaming-amber))] font-medium">2.1K commands</p>
                      <p className="text-xs text-gray-400">today</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Engagement Metrics */}
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <FaComments className="mr-3 text-[hsl(var(--gaming-cyan))]" />
                  Community Engagement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {engagementMetrics.map((metric, index) => (
                    <div key={index}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-400">{metric.label}</span>
                        <span className="text-sm text-white font-medium">{metric.value}</span>
                      </div>
                      <div className="w-full bg-gaming-bg rounded-full h-2">
                        <div 
                          className={`bg-[hsl(var(--${metric.color}))] h-2 rounded-full transition-all duration-300`}
                          style={{ width: `${parseInt(metric.value)}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Usage Trends */}
          <Card className="gaming-card border-[hsl(var(--gaming-border))]">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-white flex items-center">
                <FaChartLine className="mr-3 text-[hsl(var(--gaming-emerald))]" />
                Usage Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center gaming-bg rounded-lg">
                <div className="text-center">
                  <FaChartLine className="text-6xl text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Chart visualization would be displayed here</p>
                  <p className="text-sm text-gray-500 mt-2">Integration with charting library required</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
