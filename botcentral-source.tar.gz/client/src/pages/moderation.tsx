import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { FaUserShield, FaHistory, FaFilter, FaFlag, FaPlus, FaEdit, FaTrash, FaEye, FaCheck, FaTimes, FaExclamationTriangle, FaBan, FaDiscord, FaUserSecret } from "react-icons/fa";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const createRoleSchema = z.object({
  userId: z.string().min(1, "User ID is required"),
  role: z.string().min(1, "Role is required"),
  guildId: z.string().optional(),
  permissions: z.array(z.string()).optional(),
  expiresAt: z.string().optional(),
});

const createFilterSchema = z.object({
  name: z.string().min(1, "Filter name is required"),
  filterType: z.string().min(1, "Filter type is required"),
  pattern: z.string().min(1, "Pattern is required"),
  action: z.string().min(1, "Action is required"),
  severity: z.string().min(1, "Severity is required"),
  guildId: z.string().optional(),
  whitelist: z.array(z.string()).optional(),
});

const createReportSchema = z.object({
  reportedUserId: z.string().min(1, "Reported user ID is required"),
  contentType: z.string().min(1, "Content type is required"),
  contentId: z.string().optional(),
  reason: z.string().min(1, "Reason is required"),
  description: z.string().optional(),
  guildId: z.string().optional(),
  channelId: z.string().optional(),
  messageId: z.string().optional(),
});

const createLogSchema = z.object({
  action: z.string().min(1, "Action is required"),
  targetUserId: z.string().min(1, "Target user ID is required"),
  reason: z.string().optional(),
  details: z.string().optional(),
  severity: z.string().min(1, "Severity is required"),
  guildId: z.string().optional(),
  channelId: z.string().optional(),
  messageId: z.string().optional(),
  duration: z.number().optional(),
});

const createAutomationRuleSchema = z.object({
  name: z.string().min(1, "Rule name is required"),
  description: z.string().optional(),
  triggerType: z.string().min(1, "Trigger type is required"),
  triggerConditions: z.string().min(1, "Trigger conditions are required"),
  actions: z.array(z.string()).min(1, "At least one action is required"),
  actionSettings: z.string().optional(),
  guildId: z.string().optional(),
  channelId: z.string().optional(),
  priority: z.number().min(1).max(10).default(1),
  cooldownSeconds: z.number().min(0).default(0),
});

const createLoggingConfigSchema = z.object({
  name: z.string().min(1, "Configuration name is required"),
  guildId: z.string().min(1, "Guild ID is required"),
  channelId: z.string().min(1, "Channel ID is required"),
  channelName: z.string().optional(),
  logType: z.string().min(1, "Log type is required"),
  webhookUrl: z.string().optional(),
  description: z.string().optional(),
  isActive: z.boolean().default(true),
});

const createAltDetectionSchema = z.object({
  name: z.string().min(1, "Rule name is required"),
  description: z.string().optional(),
  guildId: z.string().min(1, "Guild ID is required"),
  minAccountAge: z.number().min(0, "Account age must be positive").default(7), // days
  requireAvatar: z.boolean().default(true),
  requireVerification: z.boolean().default(false),
  minMutualServers: z.number().min(0).default(0),
  bannedUsernamePatterns: z.array(z.string()).default([]),
  action: z.string().min(1, "Action is required"), // kick, ban, quarantine, alert
  notifyChannel: z.string().optional(),
  exemptRoles: z.array(z.string()).default([]),
  isActive: z.boolean().default(true),
  priority: z.number().min(1).max(10).default(5),
});

const createAutoRoleSchema = z.object({
  name: z.string().min(1, "Auto-role name is required"),
  description: z.string().optional(),
  roleId: z.string().min(1, "Role ID is required"),
  roleName: z.string().min(1, "Role name is required"),
  triggerType: z.string().min(1, "Trigger type is required"),
  triggerValue: z.number().optional(),
  conditions: z.string().optional(),
  guildId: z.string().min(1, "Guild ID is required"),
  channelId: z.string().optional(),
  removeOnLeave: z.boolean().default(false),
  stackable: z.boolean().default(true),
  priority: z.number().min(1).max(10).default(1),
});

type CreateRoleForm = z.infer<typeof createRoleSchema>;
type CreateFilterForm = z.infer<typeof createFilterSchema>;
type CreateReportForm = z.infer<typeof createReportSchema>;
type CreateLogForm = z.infer<typeof createLogSchema>;
type CreateAutomationRuleForm = z.infer<typeof createAutomationRuleSchema>;
type CreateAutoRoleForm = z.infer<typeof createAutoRoleSchema>;
type CreateLoggingConfigForm = z.infer<typeof createLoggingConfigSchema>;
type CreateAltDetectionForm = z.infer<typeof createAltDetectionSchema>;

export default function Moderation() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [isRoleDialogOpen, setIsRoleDialogOpen] = useState(false);
  const [isFilterDialogOpen, setIsFilterDialogOpen] = useState(false);
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
  const [isLogDialogOpen, setIsLogDialogOpen] = useState(false);
  const [isAutomationDialogOpen, setIsAutomationDialogOpen] = useState(false);
  const [isAutoRoleDialogOpen, setIsAutoRoleDialogOpen] = useState(false);
  const [isLoggingConfigDialogOpen, setIsLoggingConfigDialogOpen] = useState(false);
  const [isAltDetectionDialogOpen, setIsAltDetectionDialogOpen] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Form setups
  const roleForm = useForm<CreateRoleForm>({
    resolver: zodResolver(createRoleSchema),
    defaultValues: {
      userId: "",
      role: "member",
      guildId: "",
      permissions: [],
      expiresAt: "",
    },
  });

  const filterForm = useForm<CreateFilterForm>({
    resolver: zodResolver(createFilterSchema),
    defaultValues: {
      name: "",
      filterType: "word",
      pattern: "",
      action: "warn",
      severity: "medium",
      guildId: "",
      whitelist: [],
    },
  });

  const reportForm = useForm<CreateReportForm>({
    resolver: zodResolver(createReportSchema),
    defaultValues: {
      reportedUserId: "",
      contentType: "message",
      contentId: "",
      reason: "inappropriate",
      description: "",
      guildId: "",
      channelId: "",
      messageId: "",
    },
  });

  const logForm = useForm<CreateLogForm>({
    resolver: zodResolver(createLogSchema),
    defaultValues: {
      action: "warn",
      targetUserId: "",
      reason: "",
      details: "",
      severity: "low",
      guildId: "",
      channelId: "",
      messageId: "",
      duration: undefined,
    },
  });

  const automationForm = useForm<CreateAutomationRuleForm>({
    resolver: zodResolver(createAutomationRuleSchema),
    defaultValues: {
      name: "",
      description: "",
      triggerType: "message",
      triggerConditions: "",
      actions: [],
      actionSettings: "",
      guildId: "",
      channelId: "",
      priority: 1,
      cooldownSeconds: 0,
    },
  });

  const autoRoleForm = useForm<CreateAutoRoleForm>({
    resolver: zodResolver(createAutoRoleSchema),
    defaultValues: {
      name: "",
      description: "",
      roleId: "",
      roleName: "",
      triggerType: "join",
      triggerValue: undefined,
      conditions: "",
      guildId: "",
      channelId: "",
      removeOnLeave: false,
      stackable: true,
      priority: 1,
    },
  });

  const loggingConfigForm = useForm<CreateLoggingConfigForm>({
    resolver: zodResolver(createLoggingConfigSchema),
    defaultValues: {
      name: "",
      guildId: "",
      channelId: "",
      channelName: "",
      logType: "messages",
      webhookUrl: "",
      description: "",
      isActive: true,
    },
  });

  const altDetectionForm = useForm<CreateAltDetectionForm>({
    resolver: zodResolver(createAltDetectionSchema),
    defaultValues: {
      name: "",
      description: "",
      guildId: "",
      minAccountAge: 7,
      requireAvatar: true,
      requireVerification: false,
      minMutualServers: 0,
      bannedUsernamePatterns: [],
      action: "kick",
      notifyChannel: "",
      exemptRoles: [],
      isActive: true,
      priority: 5,
    },
  });

  // Queries
  const { data: moderationLogs, isLoading: logsLoading } = useQuery({
    queryKey: ['/api/moderation/logs'],
    enabled: isAuthenticated,
  });

  const { data: contentFilters, isLoading: filtersLoading } = useQuery({
    queryKey: ['/api/moderation/filters'],
    enabled: isAuthenticated,
  });

  const { data: reports, isLoading: reportsLoading } = useQuery({
    queryKey: ['/api/moderation/reports'],
    enabled: isAuthenticated,
  });

  const { data: automationRules, isLoading: automationLoading } = useQuery({
    queryKey: ['/api/automation/rules'],
    enabled: isAuthenticated,
  });

  const { data: autoRoles, isLoading: autoRolesLoading } = useQuery({
    queryKey: ['/api/auto-roles'],
    enabled: isAuthenticated,
  });

  const { data: loggingConfigs, isLoading: loggingConfigsLoading } = useQuery({
    queryKey: ['/api/logging/configs'],
    enabled: isAuthenticated,
  });

  const { data: altDetectionRules, isLoading: altDetectionLoading } = useQuery({
    queryKey: ['/api/alt-detection/rules'],
    enabled: isAuthenticated,
  });

  // Mutations
  const createRoleMutation = useMutation({
    mutationFn: async (roleData: CreateRoleForm) => {
      return apiRequest('/api/moderation/roles', 'POST', roleData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/logs'] });
      toast({
        title: "Success",
        description: "User role assigned successfully!",
      });
      setIsRoleDialogOpen(false);
      roleForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to assign user role. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createFilterMutation = useMutation({
    mutationFn: async (filterData: CreateFilterForm) => {
      return apiRequest('/api/moderation/filters', 'POST', filterData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/filters'] });
      toast({
        title: "Success",
        description: "Content filter created successfully!",
      });
      setIsFilterDialogOpen(false);
      filterForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create content filter. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createReportMutation = useMutation({
    mutationFn: async (reportData: CreateReportForm) => {
      return apiRequest('/api/moderation/reports', 'POST', reportData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/reports'] });
      toast({
        title: "Success",
        description: "Report submitted successfully!",
      });
      setIsReportDialogOpen(false);
      reportForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit report. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createLogMutation = useMutation({
    mutationFn: async (logData: CreateLogForm) => {
      return apiRequest('/api/moderation/logs', 'POST', logData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/logs'] });
      toast({
        title: "Success",
        description: "Moderation action logged successfully!",
      });
      setIsLogDialogOpen(false);
      logForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to log moderation action. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateReportMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<any>) => {
      return apiRequest(`/api/moderation/reports/${id}`, 'PUT', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/reports'] });
      toast({
        title: "Success",
        description: "Report updated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update report.",
        variant: "destructive",
      });
    },
  });

  const createAutomationRuleMutation = useMutation({
    mutationFn: async (ruleData: CreateAutomationRuleForm) => {
      return apiRequest('/api/automation/rules', 'POST', ruleData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/automation/rules'] });
      toast({
        title: "Success",
        description: "Automation rule created successfully!",
      });
      setIsAutomationDialogOpen(false);
      automationForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create automation rule. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createAutoRoleMutation = useMutation({
    mutationFn: async (autoRoleData: CreateAutoRoleForm) => {
      return apiRequest('/api/auto-roles', 'POST', autoRoleData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auto-roles'] });
      toast({
        title: "Success",
        description: "Auto-role created successfully!",
      });
      setIsAutoRoleDialogOpen(false);
      autoRoleForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create auto-role. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createLoggingConfigMutation = useMutation({
    mutationFn: async (configData: CreateLoggingConfigForm) => {
      return apiRequest('/api/logging/configs', 'POST', configData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/logging/configs'] });
      toast({
        title: "Success",
        description: "Discord logging channel configured successfully!",
      });
      setIsLoggingConfigDialogOpen(false);
      loggingConfigForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to configure logging channel. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createAltDetectionMutation = useMutation({
    mutationFn: async (ruleData: CreateAltDetectionForm) => {
      return apiRequest('/api/alt-detection/rules', 'POST', ruleData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/alt-detection/rules'] });
      toast({
        title: "Success",
        description: "Alt detection rule created successfully!",
      });
      setIsAltDetectionDialogOpen(false);
      altDetectionForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create alt detection rule. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handlers
  const onSubmitRole = (data: CreateRoleForm) => {
    createRoleMutation.mutate(data);
  };

  const onSubmitFilter = (data: CreateFilterForm) => {
    createFilterMutation.mutate(data);
  };

  const onSubmitReport = (data: CreateReportForm) => {
    createReportMutation.mutate(data);
  };

  const onSubmitLog = (data: CreateLogForm) => {
    createLogMutation.mutate(data);
  };

  const onSubmitAutomationRule = (data: CreateAutomationRuleForm) => {
    createAutomationRuleMutation.mutate(data);
  };

  const onSubmitAutoRole = (data: CreateAutoRoleForm) => {
    createAutoRoleMutation.mutate(data);
  };

  const onSubmitLoggingConfig = (data: CreateLoggingConfigForm) => {
    createLoggingConfigMutation.mutate(data);
  };

  const onSubmitAltDetection = (data: CreateAltDetectionForm) => {
    createAltDetectionMutation.mutate(data);
  };

  const resolveReport = (id: number, status: string) => {
    updateReportMutation.mutate({ 
      id, 
      status, 
      resolvedAt: new Date().toISOString() 
    });
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-500 border-green-500';
      case 'medium': return 'text-yellow-500 border-yellow-500';
      case 'high': return 'text-orange-500 border-orange-500';
      case 'critical': return 'text-red-500 border-red-500';
      default: return 'text-gray-500 border-gray-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-500 border-yellow-500';
      case 'investigating': return 'text-blue-500 border-blue-500';
      case 'resolved': return 'text-green-500 border-green-500';
      case 'dismissed': return 'text-gray-500 border-gray-500';
      default: return 'text-gray-500 border-gray-500';
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Moderation Center" subtitle="Manage users, content filters, and community safety" />
        <main className="flex-1 overflow-y-auto p-6">
          
          <Tabs defaultValue="logs" className="w-full">
            <TabsList className="grid w-full grid-cols-7 bg-[hsl(230,10%,12%)] border border-[hsl(30,3%,22%)]">
              <TabsTrigger value="logs" className="data-[state=active]:bg-[hsl(235,86%,65%)] data-[state=active]:text-white">
                <FaHistory className="mr-2" />
                Logs
              </TabsTrigger>
              <TabsTrigger value="filters" className="data-[state=active]:bg-[hsl(235,86%,65%)] data-[state=active]:text-white">
                <FaFilter className="mr-2" />
                Filters
              </TabsTrigger>
              <TabsTrigger value="reports" className="data-[state=active]:bg-[hsl(235,86%,65%)] data-[state=active]:text-white">
                <FaFlag className="mr-2" />
                Reports
              </TabsTrigger>
              <TabsTrigger value="roles" className="data-[state=active]:bg-[hsl(235,86%,65%)] data-[state=active]:text-white">
                <FaUserShield className="mr-2" />
                Roles
              </TabsTrigger>

              <TabsTrigger value="autoroles" className="data-[state=active]:bg-[hsl(235,86%,65%)] data-[state=active]:text-white">
                <FaBan className="mr-2" />
                Auto-Roles
              </TabsTrigger>
              <TabsTrigger value="altdetection" className="data-[state=active]:bg-[hsl(235,86%,65%)] data-[state=active]:text-white">
                <FaUserSecret className="mr-2" />
                Alt Detection
              </TabsTrigger>
            </TabsList>

            {/* Moderation Logs Tab */}
            <TabsContent value="logs" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white">Discord Bot Logging Configuration</h2>
                <Dialog open={isLoggingConfigDialogOpen} onOpenChange={setIsLoggingConfigDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white">
                      <FaDiscord className="mr-2" />
                      Add Log Channel
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-white">Configure Discord Logging Channel</DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Set up Discord channel for automated logging and monitoring.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <Form {...loggingConfigForm}>
                      <form onSubmit={loggingConfigForm.handleSubmit(onSubmitLoggingConfig)} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={loggingConfigForm.control}
                            name="logType"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Log Activity Type</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                      <SelectValue placeholder="Select activity type" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                    <SelectItem value="messages">Message Activity</SelectItem>
                                    <SelectItem value="voice_activity">Voice Channel Activity</SelectItem>
                                    <SelectItem value="member_join">Member Join Events</SelectItem>
                                    <SelectItem value="member_leave">Member Leave Events</SelectItem>
                                    <SelectItem value="invite_logs">Invite Creation/Usage</SelectItem>
                                    <SelectItem value="role_changes">Role Changes</SelectItem>
                                    <SelectItem value="channel_updates">Channel Updates</SelectItem>
                                    <SelectItem value="server_updates">Server Updates</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={loggingConfigForm.control}
                            name="guildId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Discord Server ID</FormLabel>
                                <FormControl>
                                  <Input
                                    {...field}
                                    placeholder="Enter Discord server ID"
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={loggingConfigForm.control}
                          name="channelId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Discord Channel ID</FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  placeholder="Enter Discord channel ID (e.g., 123456789012345678)"
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={loggingConfigForm.control}
                          name="channelName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Channel Name (Optional)</FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  placeholder="Enter channel name for reference"
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="flex justify-end gap-3 pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsLoggingConfigDialogOpen(false)}
                            className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                          >
                            Cancel
                          </Button>
                          <Button
                            type="submit"
                            disabled={createLoggingConfigMutation.isPending}
                            className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                          >
                            {createLoggingConfigMutation.isPending ? "Configuring..." : "Configure Channel"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="mb-6 p-4 bg-[hsl(230,10%,12%)] border border-[hsl(30,3%,22%)] rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  <FaDiscord className="text-[hsl(235,86%,65%)] text-xl" />
                  <h3 className="text-lg font-semibold text-white">About Discord Bot Logging</h3>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed">
                  Configure your Discord bot to automatically log different activities to specific channels. 
                  Set up separate channels for message activity, voice events, member joins/leaves, and more to keep your server organized.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {loggingConfigsLoading ? (
                  Array.from({ length: 3 }, (_, i) => (
                    <Card key={i} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <div className="h-4 bg-[hsl(237,71%,7%)] rounded animate-pulse"></div>
                          <div className="h-3 bg-[hsl(237,71%,7%)] rounded w-2/3 animate-pulse"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : loggingConfigs && (loggingConfigs as any[]).length > 0 ? (
                  (loggingConfigs as any[]).map((config: any) => (
                    <Card key={config.id} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <Badge variant="outline" className="border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)]">
                                {config.logType}
                              </Badge>
                              <Badge variant="outline" className="border-green-500 text-green-400">
                                Active
                              </Badge>
                            </div>
                            <div className="text-white font-medium mb-1">
                              Channel: #{config.channelName || config.channelId}
                            </div>
                            <div className="text-gray-400 text-sm mb-2">
                              Server ID: {config.guildId}
                            </div>
                            <div className="text-gray-500 text-xs">
                              Configured {new Date(config.createdAt).toLocaleString()}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                            >
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-red-500 text-red-400 hover:bg-red-500/10"
                            >
                              Remove
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                    <CardContent className="p-8 text-center">
                      <FaDiscord className="mx-auto text-4xl text-gray-500 mb-4" />
                      <h3 className="text-lg font-medium text-white mb-2">No Logging Channels Configured</h3>
                      <p className="text-gray-400 mb-4">
                        Set up Discord channels for your bot to log different activities automatically.
                      </p>
                      <Button
                        onClick={() => setIsLoggingConfigDialogOpen(true)}
                        className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                      >
                        <FaPlus className="mr-2" />
                        Configure First Channel
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            {/* Content Filters Tab */}
            <TabsContent value="filters" className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold text-white">Content Filters</h3>
                <Dialog open={isFilterDialogOpen} onOpenChange={setIsFilterDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white">
                      <FaPlus className="mr-2" />
                      Create Filter
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-xl font-semibold text-white flex items-center">
                        <FaFilter className="mr-2 text-[hsl(235,86%,65%)]" />
                        Create Content Filter
                      </DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Set up automated content filtering rules to moderate your Discord server.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <Form {...filterForm}>
                      <form onSubmit={filterForm.handleSubmit(onSubmitFilter)} className="space-y-4">
                        <FormField
                          control={filterForm.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Filter Name</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Inappropriate Language Filter"
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={filterForm.control}
                            name="filterType"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Filter Type</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                      <SelectValue placeholder="Select type" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                    <SelectItem value="word">Word Filter</SelectItem>
                                    <SelectItem value="regex">Regular Expression</SelectItem>
                                    <SelectItem value="link">Link Filter</SelectItem>
                                    <SelectItem value="spam">Spam Detection</SelectItem>
                                    <SelectItem value="toxicity">Toxicity Detection</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={filterForm.control}
                            name="action"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Action</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                      <SelectValue placeholder="Select action" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                    <SelectItem value="warn">Warn User</SelectItem>
                                    <SelectItem value="delete">Delete Content</SelectItem>
                                    <SelectItem value="flag">Flag for Review</SelectItem>
                                    <SelectItem value="auto_moderate">Auto Moderate</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={filterForm.control}
                          name="pattern"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Pattern</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Enter words, phrases, or regex pattern..."
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="flex justify-end gap-3 pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsFilterDialogOpen(false)}
                            className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                          >
                            Cancel
                          </Button>
                          <Button
                            type="submit"
                            disabled={createFilterMutation.isPending}
                            className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                          >
                            {createFilterMutation.isPending ? "Creating..." : "Create Filter"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filtersLoading ? (
                  Array.from({ length: 4 }, (_, i) => (
                    <Card key={i} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                      <CardHeader>
                        <div className="h-6 bg-[hsl(237,71%,7%)] rounded animate-pulse"></div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="h-4 bg-[hsl(237,71%,7%)] rounded animate-pulse"></div>
                          <div className="h-4 bg-[hsl(237,71%,7%)] rounded w-2/3 animate-pulse"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  (contentFilters as any[])?.map((filter: any) => (
                    <Card key={filter.id} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-white text-lg font-semibold">
                            {filter.name}
                          </CardTitle>
                          <Badge variant="outline" className={filter.isActive ? "border-green-500 text-green-500" : "border-red-500 text-red-500"}>
                            {filter.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Type:</span>
                            <span className="text-white">{filter.filterType}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Action:</span>
                            <span className="text-white">{filter.action}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Severity:</span>
                            <Badge variant="outline" className={getSeverityColor(filter.severity)}>
                              {filter.severity}
                            </Badge>
                          </div>
                          <div className="mt-3 p-2 bg-[hsl(237,71%,7%)] rounded text-xs text-gray-300">
                            {filter.pattern}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )) || []
                )}
              </div>
            </TabsContent>

            {/* Reports Tab */}
            <TabsContent value="reports" className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold text-white">User Reports</h3>
                <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white">
                      <FaPlus className="mr-2" />
                      Create Report
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-xl font-semibold text-white flex items-center">
                        <FaFlag className="mr-2 text-[hsl(235,86%,65%)]" />
                        Submit Report
                      </DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Report violations or issues that require moderator attention.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <Form {...reportForm}>
                      <form onSubmit={reportForm.handleSubmit(onSubmitReport)} className="space-y-4">
                        <FormField
                          control={reportForm.control}
                          name="reportedUserId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Reported User ID</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="123456789012345678"
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={reportForm.control}
                            name="contentType"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Content Type</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                      <SelectValue placeholder="Select content type" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                    <SelectItem value="message">Message</SelectItem>
                                    <SelectItem value="poll">Poll</SelectItem>
                                    <SelectItem value="event">Event</SelectItem>
                                    <SelectItem value="user">User Profile</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={reportForm.control}
                            name="reason"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Reason</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                      <SelectValue placeholder="Select reason" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                    <SelectItem value="spam">Spam</SelectItem>
                                    <SelectItem value="harassment">Harassment</SelectItem>
                                    <SelectItem value="inappropriate">Inappropriate Content</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={reportForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Description</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Provide additional details about this report..."
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="flex justify-end gap-3 pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsReportDialogOpen(false)}
                            className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                          >
                            Cancel
                          </Button>
                          <Button
                            type="submit"
                            disabled={createReportMutation.isPending}
                            className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                          >
                            {createReportMutation.isPending ? "Submitting..." : "Submit Report"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {reportsLoading ? (
                  Array.from({ length: 3 }, (_, i) => (
                    <Card key={i} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <div className="h-4 bg-[hsl(237,71%,7%)] rounded animate-pulse"></div>
                          <div className="h-3 bg-[hsl(237,71%,7%)] rounded w-2/3 animate-pulse"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  (reports as any[])?.map((report: any) => (
                    <Card key={report.id} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <Badge variant="outline" className={getStatusColor(report.status)}>
                                {report.status}
                              </Badge>
                              <Badge variant="outline" className="border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)]">
                                {report.reason}
                              </Badge>
                            </div>
                            <div className="text-white font-medium mb-1">
                              Reported User: {report.reportedUserId}
                            </div>
                            <div className="text-gray-400 text-sm mb-2">
                              Content Type: {report.contentType}
                            </div>
                            {report.description && (
                              <div className="text-gray-400 text-sm mb-2">{report.description}</div>
                            )}
                            <div className="text-gray-500 text-xs">
                              Reported: {new Date(report.createdAt).toLocaleString()}
                            </div>
                          </div>
                          {report.status === 'pending' && (
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => resolveReport(report.id, 'resolved')}
                                className="bg-green-600 hover:bg-green-700 text-white"
                              >
                                <FaCheck className="mr-1" />
                                Resolve
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => resolveReport(report.id, 'dismissed')}
                                className="border-gray-500 text-gray-300 hover:bg-gray-700"
                              >
                                <FaTimes className="mr-1" />
                                Dismiss
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  )) || []
                )}
              </div>
            </TabsContent>

            {/* User Roles Tab */}
            <TabsContent value="roles" className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold text-white">User Role Management</h3>
                <Dialog open={isRoleDialogOpen} onOpenChange={setIsRoleDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white">
                      <FaPlus className="mr-2" />
                      Assign Role
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-xl font-semibold text-white flex items-center">
                        <FaUserShield className="mr-2 text-[hsl(235,86%,65%)]" />
                        Assign User Role
                      </DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Assign roles and permissions to Discord users for moderation management.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <Form {...roleForm}>
                      <form onSubmit={roleForm.handleSubmit(onSubmitRole)} className="space-y-4">
                        <FormField
                          control={roleForm.control}
                          name="userId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">User ID</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="123456789012345678"
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={roleForm.control}
                            name="role"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Role</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                      <SelectValue placeholder="Select role" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                    <SelectItem value="member">Member</SelectItem>
                                    <SelectItem value="moderator">Moderator</SelectItem>
                                    <SelectItem value="admin">Admin</SelectItem>
                                    <SelectItem value="banned">Banned</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={roleForm.control}
                            name="guildId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Guild ID (Optional)</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="123456789012345678"
                                    {...field}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={roleForm.control}
                          name="expiresAt"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Expires At (Optional)</FormLabel>
                              <FormControl>
                                <Input
                                  type="datetime-local"
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="flex justify-end gap-3 pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsRoleDialogOpen(false)}
                            className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                          >
                            Cancel
                          </Button>
                          <Button
                            type="submit"
                            disabled={createRoleMutation.isPending}
                            className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                          >
                            {createRoleMutation.isPending ? "Assigning..." : "Assign Role"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <FaUserShield />
                    Role Management Overview
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-gray-300">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="bg-[hsl(237,71%,7%)] p-4 rounded">
                        <div className="text-sm text-gray-400">Members</div>
                        <div className="text-2xl font-semibold text-white">0</div>
                      </div>
                      <div className="bg-[hsl(237,71%,7%)] p-4 rounded">
                        <div className="text-sm text-gray-400">Moderators</div>
                        <div className="text-2xl font-semibold text-blue-400">0</div>
                      </div>
                      <div className="bg-[hsl(237,71%,7%)] p-4 rounded">
                        <div className="text-sm text-gray-400">Admins</div>
                        <div className="text-2xl font-semibold text-green-400">0</div>
                      </div>
                      <div className="bg-[hsl(237,71%,7%)] p-4 rounded">
                        <div className="text-sm text-gray-400">Banned</div>
                        <div className="text-2xl font-semibold text-red-400">0</div>
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      Use the "Assign Role" button to manage user permissions and access levels.
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Auto-Roles Tab */}
            <TabsContent value="autoroles" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white">Auto-Roles</h2>
                <Dialog open={isAutoRoleDialogOpen} onOpenChange={setIsAutoRoleDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white">
                      <FaPlus className="mr-2" />
                      Create Auto-Role
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-white">Create Auto-Role</DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Set up automatic role assignment based on conditions.
                      </DialogDescription>
                    </DialogHeader>
                    <Form {...autoRoleForm}>
                      <form onSubmit={automationForm.handleSubmit(onSubmitAutomationRule)} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={automationForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Rule Name</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="Auto-ban spam messages"
                                    {...field}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={automationForm.control}
                            name="triggerType"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Trigger Type</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                      <SelectValue placeholder="Select trigger" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                    <SelectItem value="message">Message</SelectItem>
                                    <SelectItem value="join">User Join</SelectItem>
                                    <SelectItem value="leave">User Leave</SelectItem>
                                    <SelectItem value="reaction">Reaction</SelectItem>
                                    <SelectItem value="warning">Warning Threshold</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={automationForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Description</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Automatically ban users who post spam messages"
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={automationForm.control}
                          name="triggerConditions"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Trigger Conditions</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="contains:spam OR mentions:@everyone"
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={automationForm.control}
                            name="priority"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Priority (1-10)</FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    min="1"
                                    max="10"
                                    {...field}
                                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={automationForm.control}
                            name="cooldownSeconds"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Cooldown (seconds)</FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    min="0"
                                    {...field}
                                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="flex justify-end gap-3 pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsAutomationDialogOpen(false)}
                            className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                          >
                            Cancel
                          </Button>
                          <Button
                            type="submit"
                            disabled={createAutomationRuleMutation.isPending}
                            className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                          >
                            {createAutomationRuleMutation.isPending ? "Creating..." : "Create Rule"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <FaExclamationTriangle />
                    Automation Rules
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {automationLoading ? (
                    <div className="text-gray-400">Loading automation rules...</div>
                  ) : !automationRules || automationRules.length === 0 ? (
                    <div className="text-gray-400">No automation rules found. Create your first rule to get started.</div>
                  ) : (
                    <div className="space-y-4">
                      {automationRules.map((rule: any) => (
                        <div key={rule.id} className="bg-[hsl(237,71%,7%)] p-4 rounded border border-[hsl(30,3%,22%)]">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <h3 className="font-semibold text-white">{rule.name}</h3>
                              <p className="text-gray-400 text-sm">{rule.description}</p>
                              <div className="mt-2 flex items-center gap-4 text-xs text-gray-500">
                                <span>Trigger: {rule.triggerType}</span>
                                <span>Priority: {rule.priority}</span>
                                <span>Triggered: {rule.triggerCount || 0} times</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-1 rounded text-xs ${rule.isActive ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                                {rule.isActive ? 'Active' : 'Inactive'}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Auto-Roles Tab */}
            <TabsContent value="autoroles" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white">Auto-Roles</h2>
                <Dialog open={isAutoRoleDialogOpen} onOpenChange={setIsAutoRoleDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white">
                      <FaPlus className="mr-2" />
                      Create Auto-Role
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-white">Create Auto-Role</DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Set up automatic role assignment based on user actions or conditions.
                      </DialogDescription>
                    </DialogHeader>
                    <Form {...autoRoleForm}>
                      <form onSubmit={autoRoleForm.handleSubmit(onSubmitAutoRole)} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={autoRoleForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Auto-Role Name</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="Welcome Role"
                                    {...field}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={autoRoleForm.control}
                            name="roleName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Role Name</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="@Member"
                                    {...field}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={autoRoleForm.control}
                            name="roleId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Role ID</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="123456789012345678"
                                    {...field}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={autoRoleForm.control}
                            name="triggerType"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Trigger Type</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                      <SelectValue placeholder="Select trigger" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                    <SelectItem value="join">User Join</SelectItem>
                                    <SelectItem value="message_count">Message Count</SelectItem>
                                    <SelectItem value="time_spent">Time Spent</SelectItem>
                                    <SelectItem value="reaction">Reaction</SelectItem>
                                    <SelectItem value="voice_time">Voice Time</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={autoRoleForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Description</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Automatically assign Member role when users join the server"
                                  {...field}
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-3 gap-4">
                          <FormField
                            control={autoRoleForm.control}
                            name="triggerValue"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Trigger Value</FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    placeholder="10"
                                    {...field}
                                    onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={autoRoleForm.control}
                            name="priority"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Priority</FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    min="1"
                                    max="10"
                                    {...field}
                                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={autoRoleForm.control}
                            name="guildId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Guild ID</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="987654321098765432"
                                    {...field}
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="flex items-center space-x-6">
                          <FormField
                            control={autoRoleForm.control}
                            name="removeOnLeave"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    className="border-[hsl(30,3%,22%)]"
                                  />
                                </FormControl>
                                <FormLabel className="text-gray-200">Remove on Leave</FormLabel>
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={autoRoleForm.control}
                            name="stackable"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    className="border-[hsl(30,3%,22%)]"
                                  />
                                </FormControl>
                                <FormLabel className="text-gray-200">Stackable</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="flex justify-end gap-3 pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsAutoRoleDialogOpen(false)}
                            className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                          >
                            Cancel
                          </Button>
                          <Button
                            type="submit"
                            disabled={createAutoRoleMutation.isPending}
                            className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                          >
                            {createAutoRoleMutation.isPending ? "Creating..." : "Create Auto-Role"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <FaBan />
                    Auto-Roles
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {autoRolesLoading ? (
                    <div className="text-gray-400">Loading auto-roles...</div>
                  ) : !autoRoles || autoRoles.length === 0 ? (
                    <div className="text-gray-400">No auto-roles found. Create your first auto-role to get started.</div>
                  ) : (
                    <div className="space-y-4">
                      {autoRoles.map((autoRole: any) => (
                        <div key={autoRole.id} className="bg-[hsl(237,71%,7%)] p-4 rounded border border-[hsl(30,3%,22%)]">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <h3 className="font-semibold text-white">{autoRole.name}</h3>
                              <p className="text-gray-400 text-sm">{autoRole.description}</p>
                              <div className="mt-2 flex items-center gap-4 text-xs text-gray-500">
                                <span>Role: {autoRole.roleName}</span>
                                <span>Trigger: {autoRole.triggerType}</span>
                                <span>Assigned: {autoRole.assignedCount || 0} times</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-1 rounded text-xs ${autoRole.isActive ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                                {autoRole.isActive ? 'Active' : 'Inactive'}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Alt Detection Tab */}
            <TabsContent value="altdetection" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white">Alt Account Detection</h2>
                <Dialog open={isAltDetectionDialogOpen} onOpenChange={setIsAltDetectionDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white">
                      <FaPlus className="mr-2" />
                      Create Rule
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white max-w-3xl">
                    <DialogHeader>
                      <DialogTitle className="text-white">Create Alt Detection Rule</DialogTitle>
                    </DialogHeader>
                    
                    <Form {...altDetectionForm}>
                      <form onSubmit={altDetectionForm.handleSubmit(onSubmitAltDetection)} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={altDetectionForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Rule Name</FormLabel>
                                <FormControl>
                                  <Input
                                    {...field}
                                    placeholder="New Account Filter"
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={altDetectionForm.control}
                            name="guildId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Discord Server ID</FormLabel>
                                <FormControl>
                                  <Input
                                    {...field}
                                    placeholder="123456789012345678"
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={altDetectionForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Description</FormLabel>
                              <FormControl>
                                <Textarea
                                  {...field}
                                  placeholder="Describe what this rule detects..."
                                  className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={altDetectionForm.control}
                            name="minAccountAge"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Minimum Account Age (Days)</FormLabel>
                                <FormControl>
                                  <Input
                                    {...field}
                                    type="number"
                                    min="0"
                                    placeholder="7"
                                    className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white"
                                    onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={altDetectionForm.control}
                            name="action"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-gray-200">Action</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-[hsl(237,71%,7%)] border-[hsl(30,3%,22%)] text-white">
                                      <SelectValue placeholder="Select action" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                                    <SelectItem value="kick">Kick User</SelectItem>
                                    <SelectItem value="ban">Ban User</SelectItem>
                                    <SelectItem value="quarantine">Quarantine Role</SelectItem>
                                    <SelectItem value="alert">Alert Only</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                          <FormField
                            control={altDetectionForm.control}
                            name="requireAvatar"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border border-[hsl(30,3%,22%)] p-4">
                                <div className="space-y-0.5">
                                  <FormLabel className="text-base text-gray-200">
                                    Require Avatar
                                  </FormLabel>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={altDetectionForm.control}
                            name="requireVerification"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border border-[hsl(30,3%,22%)] p-4">
                                <div className="space-y-0.5">
                                  <FormLabel className="text-base text-gray-200">
                                    Require Verification
                                  </FormLabel>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={altDetectionForm.control}
                            name="isActive"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border border-[hsl(30,3%,22%)] p-4">
                                <div className="space-y-0.5">
                                  <FormLabel className="text-base text-gray-200">
                                    Active Rule
                                  </FormLabel>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="flex justify-end gap-3 pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsAltDetectionDialogOpen(false)}
                            className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                          >
                            Cancel
                          </Button>
                          <Button
                            type="submit"
                            disabled={createAltDetectionMutation.isPending}
                            className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                          >
                            {createAltDetectionMutation.isPending ? "Creating..." : "Create Rule"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="mb-6 p-4 bg-[hsl(230,10%,12%)] border border-[hsl(30,3%,22%)] rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  <FaUserSecret className="text-[hsl(235,86%,65%)] text-xl" />
                  <h3 className="text-lg font-semibold text-white">About Alt Detection</h3>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed">
                  Configure automated rules to detect potential alternative accounts based on account age, verification status, 
                  avatar presence, and other factors. Set up automated actions like kicks, bans, or quarantine roles to protect your server.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {altDetectionLoading ? (
                  Array.from({ length: 3 }, (_, i) => (
                    <Card key={i} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <div className="h-4 bg-[hsl(237,71%,7%)] rounded animate-pulse"></div>
                          <div className="h-3 bg-[hsl(237,71%,7%)] rounded w-2/3 animate-pulse"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : altDetectionRules && (altDetectionRules as any[]).length > 0 ? (
                  (altDetectionRules as any[]).map((rule: any) => (
                    <Card key={rule.id} className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] hover:border-[hsl(235,86%,65%)] transition-all">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <Badge variant="outline" className="border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)]">
                                {rule.action}
                              </Badge>
                              <Badge variant="outline" className={rule.isActive ? "border-green-500 text-green-400" : "border-gray-500 text-gray-400"}>
                                {rule.isActive ? 'Active' : 'Inactive'}
                              </Badge>
                            </div>
                            <div className="text-white font-medium mb-1">
                              {rule.name}
                            </div>
                            <div className="text-gray-400 text-sm mb-2">
                              Min Age: {rule.minAccountAge} days • 
                              {rule.requireAvatar ? " Avatar Required" : " No Avatar Required"} • 
                              {rule.requireVerification ? " Verification Required" : " No Verification Required"}
                            </div>
                            <div className="text-gray-500 text-xs">
                              Created {new Date(rule.createdAt).toLocaleString()} • Triggered {rule.triggerCount || 0} times
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-[hsl(30,3%,22%)] text-gray-300 hover:bg-[hsl(230,10%,12%)]"
                            >
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-red-500 text-red-400 hover:bg-red-500/10"
                            >
                              Delete
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)]">
                    <CardContent className="p-8 text-center">
                      <FaUserSecret className="mx-auto text-4xl text-gray-500 mb-4" />
                      <h3 className="text-lg font-medium text-white mb-2">No Alt Detection Rules</h3>
                      <p className="text-gray-400 mb-4">
                        Create detection rules to automatically identify and handle potential alternative accounts.
                      </p>
                      <Button
                        onClick={() => setIsAltDetectionDialogOpen(true)}
                        className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(240,61%,56%)] text-white"
                      >
                        <FaPlus className="mr-2" />
                        Create First Rule
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}