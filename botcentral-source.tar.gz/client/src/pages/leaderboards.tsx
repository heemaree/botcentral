import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { type LeaderboardEntry } from "@shared/schema";
import { FaTrophy, FaMedal, FaComments, FaUsers, FaGamepad, FaBullhorn, FaCode, FaEye, FaCog, FaHashtag, FaPlus, FaSave, FaAt, FaUserPlus } from "react-icons/fa";

export default function Leaderboards() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: messagesLeaderboard } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard/messages"],
    enabled: isAuthenticated,
  });

  const { data: invitersLeaderboard } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard/inviters"],
    enabled: isAuthenticated,
  });

  const { data: engagementLeaderboard } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard/engagement"],
    enabled: isAuthenticated,
  });

  const { data: levelsLeaderboard } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard/levels"],
    enabled: isAuthenticated,
  });

  // Announcement system state
  const [announcementData, setAnnouncementData] = useState({
    title: "📢 Community Announcement",
    description: "Important update for all community members!\n\nThanks to our top inviters @admin and @moderator for growing our community!",
    color: "#10b981",
    channel: "",
    taggedUsers: [
      { id: "123456789", username: "admin", displayName: "ServerAdmin" },
      { id: "987654321", username: "moderator", displayName: "ModTeam" }
    ]
  });

  const [newUserTag, setNewUserTag] = useState("");

  const addUserTag = () => {
    if (newUserTag.trim() && !announcementData.taggedUsers.find(user => user.username === newUserTag.trim())) {
      const newUser = {
        id: Date.now().toString(),
        username: newUserTag.trim(),
        displayName: newUserTag.trim()
      };
      setAnnouncementData(prev => ({
        ...prev,
        taggedUsers: [...prev.taggedUsers, newUser]
      }));
      setNewUserTag("");
    }
  };

  const removeUserTag = (userId: string) => {
    setAnnouncementData(prev => ({
      ...prev,
      taggedUsers: prev.taggedUsers.filter(user => user.id !== userId)
    }));
  };

  const insertUserMention = (username: string) => {
    const mention = `@${username}`;
    setAnnouncementData(prev => ({
      ...prev,
      description: prev.description + ` ${mention}`
    }));
  };

  // Function to render text with user mentions highlighted
  const renderTextWithMentions = (text: string) => {
    const mentionRegex = /@(\w+)/g;
    const parts = text.split(mentionRegex);
    
    return parts.map((part, index) => {
      if (index % 2 === 1) { // This is a username
        const user = announcementData.taggedUsers.find(u => u.username === part);
        if (user) {
          return (
            <span 
              key={index} 
              className="bg-[hsl(235,86%,65%)] text-white px-1 rounded cursor-pointer hover:bg-[hsl(235,86%,75%)] transition-colors"
              title={`Click to view ${user.displayName}'s profile`}
            >
              @{part}
            </span>
          );
        }
        return `@${part}`;
      }
      return part;
    });
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return "text-[hsl(var(--gaming-amber))]";
      case 2: return "text-gray-300";
      case 3: return "text-[hsl(var(--gaming-purple))]";
      default: return "text-gray-400";
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <FaTrophy className="text-[hsl(var(--gaming-amber))]" />;
      case 2: return <FaMedal className="text-gray-300" />;
      case 3: return <FaMedal className="text-[hsl(var(--gaming-purple))]" />;
      default: return <span className="text-gray-400 font-mono">#{rank}</span>;
    }
  };

  const LeaderboardCard = ({ 
    entries, 
    title, 
    icon, 
    scoreLabel,
    isLoading 
  }: { 
    entries?: LeaderboardEntry[], 
    title: string, 
    icon: React.ReactNode,
    scoreLabel: string,
    isLoading?: boolean 
  }) => (
    <Card className="gaming-card border-[hsl(var(--gaming-border))]">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-white flex items-center">
          {icon}
          <span className="ml-3">{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse flex items-center space-x-3 p-3">
                <div className="w-8 h-8 bg-gray-700 rounded"></div>
                <div className="w-10 h-10 bg-gray-700 rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-700 rounded w-32"></div>
                  <div className="h-3 bg-gray-700 rounded w-16"></div>
                </div>
                <div className="w-12 h-4 bg-gray-700 rounded"></div>
              </div>
            ))}
          </div>
        ) : entries && entries.length > 0 ? (
          <div className="space-y-3">
            {entries.slice(0, 10).map((entry, index) => {
              const rank = index + 1;
              return (
                <div key={entry.id} className="flex items-center space-x-3 p-3 rounded-lg bg-[hsl(var(--gaming-muted))] hover:bg-[hsl(var(--gaming-muted))]/80 transition-colors">
                  <div className={`flex items-center justify-center w-8 h-8 ${getRankColor(rank)}`}>
                    {getRankIcon(rank)}
                  </div>
                  <div className="w-10 h-10 bg-gradient-to-br from-[hsl(var(--gaming-primary))] to-[hsl(var(--gaming-accent))] rounded-full flex items-center justify-center">
                    <FaUsers className="text-white text-sm" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-white">{entry.username}</div>
                    <div className="text-sm text-gray-400">#{entry.userId}</div>
                  </div>
                  <Badge className="bg-[hsl(var(--gaming-accent))] text-white">
                    {entry.score} {scoreLabel}
                  </Badge>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-400">
            <FaTrophy className="mx-auto text-4xl mb-4 opacity-50" />
            <p>No leaderboard data available yet.</p>
            <p className="text-sm mt-2">Start inviting friends to see rankings!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="dark min-h-screen bg-[#0b0f1e]" style={{ backgroundColor: '#0b0f1e', color: '#fafafa' }}>
      <div className="min-h-screen bg-[#0b0f1e] flex" style={{ backgroundColor: '#0b0f1e' }}>
        <Sidebar />
        <div className="flex-1 flex flex-col">
          <Header />
          <main className="flex-1 p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Community Leaderboards</h1>
              <p className="text-gray-400">Track top community members and their contributions</p>
            </div>
          </div>

          <Tabs defaultValue="inviters" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-[hsl(var(--gaming-muted))]">
              <TabsTrigger value="inviters" className="data-[state=active]:bg-[hsl(var(--gaming-primary))]">
                <FaUserPlus className="mr-2" />
                Inviters
              </TabsTrigger>
              <TabsTrigger value="engagement" className="data-[state=active]:bg-[hsl(var(--gaming-primary))]">
                <FaComments className="mr-2" />
                Engagement
              </TabsTrigger>
              <TabsTrigger value="levels" className="data-[state=active]:bg-[hsl(var(--gaming-primary))]">
                <FaTrophy className="mr-2" />
                Levels
              </TabsTrigger>
              <TabsTrigger value="messages" className="data-[state=active]:bg-[hsl(var(--gaming-primary))]">
                <FaGamepad className="mr-2" />
                Messages
              </TabsTrigger>
            </TabsList>

            <TabsContent value="inviters" className="space-y-6">
              <LeaderboardCard
                entries={invitersLeaderboard}
                title="Top Inviters"
                icon={<FaUserPlus className="text-[hsl(var(--gaming-primary))]" />}
                scoreLabel="invites"
                isLoading={!invitersLeaderboard}
              />
            </TabsContent>

            <TabsContent value="engagement" className="space-y-6">
              <LeaderboardCard
                entries={engagementLeaderboard}
                title="Most Engaged Members"
                icon={<FaComments className="text-[hsl(var(--gaming-accent))]" />}
                scoreLabel="messages"
                isLoading={!engagementLeaderboard}
              />
            </TabsContent>

            <TabsContent value="levels" className="space-y-6">
              <LeaderboardCard
                entries={levelsLeaderboard}
                title="Highest Level Members"
                icon={<FaTrophy className="text-[hsl(var(--gaming-amber))]" />}
                scoreLabel="XP"
                isLoading={!levelsLeaderboard}
              />
            </TabsContent>

            <TabsContent value="messages" className="space-y-6">
              <LeaderboardCard
                entries={messagesLeaderboard}
                title="Most Active Messagers"
                icon={<FaGamepad className="text-[hsl(var(--gaming-purple))]" />}
                scoreLabel="messages"
                isLoading={!messagesLeaderboard}
              />
            </TabsContent>
          </Tabs>

          {/* Announcement System */}
          <Card className="bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] text-white">
            <CardHeader>
              <CardTitle className="flex items-center text-xl">
                <FaBullhorn className="mr-3 text-[hsl(160,84%,39%)]" />
                Community Announcements
                <span className="ml-auto text-sm bg-[hsl(160,84%,39%)]/20 text-[hsl(160,84%,39%)] px-2 py-1 rounded-full">
                  Create & Send
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-gray-400">
                Create and send community announcements with custom embeds and user mentions. Perfect for celebrating top inviters and community milestones.
              </p>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Announcement Preview */}
                <div className="space-y-4">
                  <h4 className="font-semibold text-white flex items-center">
                    <FaEye className="mr-2 text-[hsl(235,86%,65%)]" />
                    Announcement Preview
                  </h4>
                  <div className="space-y-2">
                    {/* Announcement embed preview */}
                    <div className="bg-[hsl(220,13%,18%)] border-l-4 rounded-r-lg p-4 space-y-3" style={{ borderLeftColor: announcementData.color }}>
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: announcementData.color }}>
                          <FaBullhorn className="text-white text-sm" />
                        </div>
                        <div>
                          <h5 className="font-semibold" style={{ color: announcementData.color }}>{announcementData.title}</h5>
                          <p className="text-xs text-gray-400">Community Update</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm text-gray-300 whitespace-pre-wrap">
                          {renderTextWithMentions(announcementData.description)}
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div className="bg-[hsl(220,13%,25%)] rounded p-2">
                            <span style={{ color: announcementData.color }}>🏆 Top Inviters</span>
                            <p className="text-gray-400">See leaderboard</p>
                          </div>
                          <div className="bg-[hsl(220,13%,25%)] rounded p-2">
                            <span className="text-[hsl(235,86%,65%)]">👥 Community</span>
                            <p className="text-gray-400">Join discussions</p>
                          </div>
                        </div>
                      </div>
                      <div className="text-xs text-gray-500 border-t border-gray-600 pt-2">
                        BotCentral • Today at 12:00 PM
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Configuration Options */}
                <div className="space-y-4">
                  <h4 className="font-semibold text-white flex items-center">
                    <FaCog className="mr-2 text-[hsl(235,86%,65%)]" />
                    Configuration
                  </h4>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white">Target Channel</Label>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,65%)] hover:text-white"
                      >
                        <FaHashtag className="mr-2" />
                        Select Announcement Channel
                      </Button>
                    </div>
                    
                    <div>
                      <Label className="text-white">Embed Color</Label>
                      <div className="flex space-x-2 mt-2">
                        {["#10b981", "#6366f1", "#ec4899", "#f97316", "#ef4444"].map((color) => (
                          <div 
                            key={color}
                            className={`w-8 h-8 rounded cursor-pointer border-2 ${announcementData.color === color ? 'border-white' : 'border-transparent'}`}
                            style={{ backgroundColor: color }}
                            onClick={() => setAnnouncementData(prev => ({ ...prev, color }))}
                          ></div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-white">Announcement Title</Label>
                      <Input
                        value={announcementData.title}
                        onChange={(e) => setAnnouncementData(prev => ({ ...prev, title: e.target.value }))}
                        className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                        placeholder="📢 Community Announcement"
                      />
                    </div>

                    <div>
                      <Label className="text-white">Message</Label>
                      <Textarea
                        value={announcementData.description}
                        onChange={(e) => setAnnouncementData(prev => ({ ...prev, description: e.target.value }))}
                        className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white h-24"
                        placeholder="Enter your announcement message here. Use @username to mention users."
                      />
                      <p className="text-xs text-gray-400 mt-1">
                        Tip: Type @username to mention users. They'll be clickable in Discord!
                      </p>
                    </div>

                    {/* User Tagging Section */}
                    <div>
                      <Label className="text-white flex items-center">
                        <FaAt className="mr-2" />
                        User Tags
                      </Label>
                      <div className="space-y-3">
                        <div className="flex gap-2">
                          <Input
                            value={newUserTag}
                            onChange={(e) => setNewUserTag(e.target.value)}
                            placeholder="Enter username"
                            className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                            onKeyPress={(e) => e.key === 'Enter' && addUserTag()}
                          />
                          <Button onClick={addUserTag} size="sm" className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,75%)]">
                            <FaPlus />
                          </Button>
                        </div>
                        
                        {/* Tagged Users List */}
                        <div className="space-y-2">
                          <p className="text-sm text-gray-400">Tagged Users:</p>
                          <div className="flex flex-wrap gap-2">
                            {announcementData.taggedUsers.map((user) => (
                              <Badge 
                                key={user.id}
                                className="bg-[hsl(235,86%,65%)] text-white flex items-center gap-2 px-3 py-1"
                              >
                                <FaUsers className="text-xs" />
                                @{user.username}
                                <button 
                                  onClick={() => removeUserTag(user.id)}
                                  className="ml-1 text-xs hover:text-red-300"
                                >
                                  ×
                                </button>
                              </Badge>
                            ))}
                          </div>
                          
                          {/* Quick Insert Buttons */}
                          {announcementData.taggedUsers.length > 0 && (
                            <div className="mt-2">
                              <p className="text-xs text-gray-400 mb-2">Quick insert:</p>
                              <div className="flex flex-wrap gap-1">
                                {announcementData.taggedUsers.map((user) => (
                                  <Button
                                    key={user.id}
                                    onClick={() => insertUserMention(user.username)}
                                    size="sm"
                                    variant="outline"
                                    className="text-xs border-[hsl(235,86%,65%)] text-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,65%)] hover:text-white"
                                  >
                                    @{user.username}
                                  </Button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex space-x-3 pt-4">
                      <Button className="flex-1 bg-[hsl(160,84%,39%)] hover:bg-[hsl(160,84%,39%)]/80 text-white">
                        <FaSave className="mr-2" />
                        Save Announcement
                      </Button>
                      <Button className="flex-1 bg-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,65%)]/80 text-white">
                        <FaBullhorn className="mr-2" />
                        Send Announcement
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          </main>
        </div>
      </div>
    </div>
  );
}