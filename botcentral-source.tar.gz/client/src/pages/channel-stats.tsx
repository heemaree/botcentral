import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { FaChartLine, FaUsers, FaVolumeUp, FaHashtag, FaSave, FaCog, FaLock } from "react-icons/fa";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";

export default function ChannelStats() {
  const [statsConfig, setStatsConfig] = useState({
    enabled: false,
    totalMembersChannel: "",
    onlineMembersChannel: "",
    voiceChannelsChannel: "",
    categoryChannel: "",
    channelType: "voice", // voice, text, category
    updateInterval: "5", // minutes
    displayFormat: "Members: {count}",
    includeOffline: true,
    includeBots: false
  });

  // Get user subscription status
  const { data: subscriptionData } = useQuery({
    queryKey: ["/api/user/subscription"],
  });
  
  const isPremium = subscriptionData?.subscriptionTier === "premium" || subscriptionData?.subscriptionTier === "yearly";

  const handleSave = () => {
    if (!isPremium) {
      // Show premium upgrade prompt
      return;
    }
    // Save configuration logic here
    console.log("Saving channel statistics configuration:", statsConfig);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Server Stats" subtitle="Configure automated server statistics display" />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="border-b border-[hsl(30,3%,22%)] pb-6">
          <div className="flex items-center space-x-3 mb-2">
            <FaChartLine className="text-2xl text-[hsl(235,86%,65%)]" />
            <h1 className="text-3xl font-bold">Server Stats Configuration</h1>
            {!isPremium && (
              <Badge variant="secondary" className="bg-yellow-600 text-white">
                <FaLock className="mr-1" />
                Premium Feature
              </Badge>
            )}
          </div>
          <p className="text-gray-400">
            Configure automated server statistics to display real-time server information in channel names
          </p>
        </div>

        {/* Premium Notice */}
        {!isPremium && (
          <Card className="bg-gradient-to-r from-yellow-900/20 to-orange-900/20 border-yellow-600/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <FaLock className="text-yellow-500 text-xl" />
                  <div>
                    <h3 className="text-lg font-semibold text-yellow-400">Premium Feature Required</h3>
                    <p className="text-gray-300">
                      Channel Statistics requires a premium subscription to configure and use.
                    </p>
                  </div>
                </div>
                <Button 
                  onClick={() => window.location.href = '/premium-plans'}
                  className="bg-yellow-600 hover:bg-yellow-700 text-white"
                >
                  Upgrade Now
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Configuration */}
        <Card className={`bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] ${!isPremium ? 'opacity-60' : ''}`}>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FaCog className="text-[hsl(235,86%,65%)]" />
              <span>Statistics Configuration</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Enable/Disable */}
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white font-medium">Enable Channel Statistics</Label>
                <p className="text-sm text-gray-400">
                  Automatically update channel names with server statistics
                </p>
              </div>
              <Switch
                checked={statsConfig.enabled}
                onCheckedChange={(checked) => 
                  setStatsConfig(prev => ({ ...prev, enabled: checked }))
                }
                disabled={!isPremium}
              />
            </div>

            {/* Channel Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <Label className="text-white">Total Members Channel</Label>
                <div className="flex items-center space-x-2">
                  <FaUsers className="text-gray-400" />
                  <Input
                    value={statsConfig.totalMembersChannel}
                    onChange={(e) => setStatsConfig(prev => ({ ...prev, totalMembersChannel: e.target.value }))}
                    className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                    placeholder="Select or enter channel name"
                    disabled={!isPremium}
                  />
                </div>
              </div>

              <div className="space-y-4">
                <Label className="text-white">Online Members Channel</Label>
                <div className="flex items-center space-x-2">
                  <FaUsers className="text-green-400" />
                  <Input
                    value={statsConfig.onlineMembersChannel}
                    onChange={(e) => setStatsConfig(prev => ({ ...prev, onlineMembersChannel: e.target.value }))}
                    className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                    placeholder="Select or enter channel name"
                    disabled={!isPremium}
                  />
                </div>
              </div>
            </div>

            {/* Channel Type Selection */}
            <div className="space-y-4">
              <Label className="text-white">Preferred Channel Type</Label>
              <Select
                value={statsConfig.channelType}
                onValueChange={(value) => setStatsConfig(prev => ({ ...prev, channelType: value }))}
                disabled={!isPremium}
              >
                <SelectTrigger className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)]">
                  <SelectItem value="voice">
                    <div className="flex items-center space-x-2">
                      <FaVolumeUp className="text-blue-400" />
                      <span>Voice Channel (Recommended)</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="text">
                    <div className="flex items-center space-x-2">
                      <FaHashtag className="text-gray-400" />
                      <span>Text Channel</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="category">
                    <div className="flex items-center space-x-2">
                      <FaCog className="text-purple-400" />
                      <span>Category</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-gray-400">
                Voice channels are recommended as they can't be accidentally deleted by users
              </p>
            </div>

            {/* Display Format */}
            <div className="space-y-4">
              <Label className="text-white">Display Format</Label>
              <Input
                value={statsConfig.displayFormat}
                onChange={(e) => setStatsConfig(prev => ({ ...prev, displayFormat: e.target.value }))}
                className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white"
                placeholder="Members: {count}"
                disabled={!isPremium}
              />
              <p className="text-sm text-gray-400">
                Use {"{count}"} as placeholder for the actual number. Example: "👥 Members: {"{count}"}"
              </p>
            </div>

            {/* Advanced Options */}
            <div className="space-y-4">
              <Label className="text-white font-medium">Advanced Options</Label>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm text-white">Include Offline Members</Label>
                    <p className="text-xs text-gray-400">Count all members including offline ones</p>
                  </div>
                  <Switch
                    checked={statsConfig.includeOffline}
                    onCheckedChange={(checked) => 
                      setStatsConfig(prev => ({ ...prev, includeOffline: checked }))
                    }
                    disabled={!isPremium}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm text-white">Include Bots</Label>
                    <p className="text-xs text-gray-400">Count bot accounts in statistics</p>
                  </div>
                  <Switch
                    checked={statsConfig.includeBots}
                    onCheckedChange={(checked) => 
                      setStatsConfig(prev => ({ ...prev, includeBots: checked }))
                    }
                    disabled={!isPremium}
                  />
                </div>
              </div>
            </div>

            {/* Update Interval */}
            <div className="space-y-4">
              <Label className="text-white">Update Interval</Label>
              <Select
                value={statsConfig.updateInterval}
                onValueChange={(value) => setStatsConfig(prev => ({ ...prev, updateInterval: value }))}
                disabled={!isPremium}
              >
                <SelectTrigger className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[hsl(220,13%,18%)] border border-[hsl(235,86%,65%)]">
                  <SelectItem value="1">Every 1 minute</SelectItem>
                  <SelectItem value="5">Every 5 minutes</SelectItem>
                  <SelectItem value="10">Every 10 minutes</SelectItem>
                  <SelectItem value="30">Every 30 minutes</SelectItem>
                  <SelectItem value="60">Every 1 hour</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-gray-400">
                More frequent updates may be rate-limited by Discord
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Preview */}
        <Card className={`bg-[hsl(230,10%,12%)] border-[hsl(30,3%,22%)] ${!isPremium ? 'opacity-60' : ''}`}>
          <CardHeader>
            <CardTitle className="text-white">Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 p-3 bg-[hsl(220,13%,18%)] rounded-lg">
                <FaVolumeUp className="text-blue-400" />
                <span className="text-white">
                  {statsConfig.displayFormat.replace('{count}', '1,247')}
                </span>
              </div>
              <p className="text-sm text-gray-400">
                This is how your channel name will appear with current settings
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button 
            onClick={handleSave}
            disabled={!isPremium || !statsConfig.enabled}
            className="bg-[hsl(235,86%,65%)] hover:bg-[hsl(235,86%,55%)] text-white px-6"
          >
            <FaSave className="mr-2" />
            Save Configuration
          </Button>
        </div>
          </div>
        </main>
      </div>
    </div>
  );
}