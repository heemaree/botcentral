import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBotSchema, type Bot } from "@shared/schema";
import { z } from "zod";
import { FaRobot, FaPlus, FaCog, FaFileAlt, FaTrash, FaServer, FaUsers } from "react-icons/fa";

const botFormSchema = insertBotSchema.extend({
  name: z.string().min(1, "Bot name is required"),
  description: z.string().optional(),
  token: z.string().min(1, "Bot token is required"),
});

export default function BotManagement() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const form = useForm<z.infer<typeof botFormSchema>>({
    resolver: zodResolver(botFormSchema),
    defaultValues: {
      name: "",
      description: "",
      token: "",
      status: "offline",
    },
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: bots, isLoading: botsLoading } = useQuery<Bot[]>({
    queryKey: ["/api/bots"],
    enabled: isAuthenticated,
  });

  const createBotMutation = useMutation({
    mutationFn: async (data: z.infer<typeof botFormSchema>) => {
      await apiRequest("POST", "/api/bots", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Bot created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create bot. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteBotMutation = useMutation({
    mutationFn: async (botId: number) => {
      await apiRequest("DELETE", `/api/bots/${botId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      toast({
        title: "Success",
        description: "Bot deleted successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete bot. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: z.infer<typeof botFormSchema>) => {
    createBotMutation.mutate(data);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-[hsl(var(--status-online))]';
      case 'idle': return 'bg-[hsl(var(--status-idle))]';
      default: return 'bg-[hsl(var(--status-offline))]';
    }
  };

  const getStatusText = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[hsl(237,71%,7%)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Personalized Bot" subtitle="Create and manage your personal Discord bots with custom tokens" />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-2xl font-bold text-white">Your Bots</h2>
              <p className="text-gray-400">Manage your Discord bot collection</p>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))] text-white glow-effect">
                  <FaPlus className="mr-2" />
                  Create New Bot
                </Button>
              </DialogTrigger>
              <DialogContent className="gaming-card border-[hsl(var(--gaming-border))] text-white">
                <DialogHeader>
                  <DialogTitle>Create New Bot</DialogTitle>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bot Name</FormLabel>
                          <FormControl>
                            <Input placeholder="ModBot Pro" {...field} className="gaming-bg border-[hsl(var(--gaming-border))] text-white" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Moderation and auto-mod features" {...field} className="gaming-bg border-[hsl(var(--gaming-border))] text-white" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="token"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bot Token</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Your bot token from Discord Developer Portal" {...field} className="gaming-bg border-[hsl(var(--gaming-border))] text-white" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="flex gap-2 pt-4">
                      <Button type="submit" disabled={createBotMutation.isPending} className="flex-1 bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))]">
                        {createBotMutation.isPending ? "Creating..." : "Create Bot"}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)} className="border-[hsl(var(--gaming-border))] text-gray-300 hover:text-white">
                        Cancel
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          {botsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="gaming-card border-[hsl(var(--gaming-border))]">
                  <CardContent className="p-6">
                    <div className="animate-pulse">
                      <div className="flex items-center space-x-4 mb-4">
                        <div className="w-12 h-12 bg-gray-700 rounded-full"></div>
                        <div className="space-y-2">
                          <div className="h-4 bg-gray-700 rounded w-24"></div>
                          <div className="h-3 bg-gray-700 rounded w-32"></div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="h-3 bg-gray-700 rounded w-full"></div>
                        <div className="h-3 bg-gray-700 rounded w-3/4"></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : bots && bots.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bots.map((bot) => (
                <Card key={bot.id} className="gaming-card border-[hsl(var(--gaming-border))] hover:border-[hsl(var(--discord-primary))] transition-all">
                  <CardHeader className="pb-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-[hsl(var(--discord-primary))]/20 rounded-full flex items-center justify-center">
                          <FaRobot className="text-[hsl(var(--discord-primary))] text-xl" />
                        </div>
                        <div>
                          <CardTitle className="text-white">{bot.name}</CardTitle>
                          <div className="flex items-center space-x-2 mt-1">
                            <div className={`w-2 h-2 rounded-full ${getStatusColor(bot.status)} animate-pulse-slow`}></div>
                            <Badge variant="secondary" className="text-xs">
                              {getStatusText(bot.status)}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-400 text-sm mb-4">{bot.description || "No description provided"}</p>
                    
                    <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                      <div className="flex items-center space-x-1">
                        <FaServer className="text-xs" />
                        <span>{bot.serverCount || 0} servers</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <FaUsers className="text-xs" />
                        <span>{bot.userCount || 0} users</span>
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" className="flex-1 border-[hsl(var(--gaming-border))] text-gray-300 hover:text-white">
                        <FaCog className="mr-1" />
                        Configure
                      </Button>
                      <Button size="sm" variant="outline" className="border-[hsl(var(--gaming-border))] text-gray-300 hover:text-white">
                        <FaFileAlt />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => deleteBotMutation.mutate(bot.id)}
                        disabled={deleteBotMutation.isPending}
                        className="border-[hsl(var(--status-offline))] text-[hsl(var(--status-offline))] hover:bg-[hsl(var(--status-offline))] hover:text-white"
                      >
                        <FaTrash />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="gaming-card border-[hsl(var(--gaming-border))]">
              <CardContent className="text-center py-16">
                <FaRobot className="text-6xl text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">No Bots Yet</h3>
                <p className="text-gray-400 mb-6">Create your first Discord bot to get started</p>
                <Button 
                  onClick={() => setIsCreateDialogOpen(true)}
                  className="bg-[hsl(var(--discord-primary))] hover:bg-[hsl(var(--discord-dark))] text-white glow-effect"
                >
                  <FaPlus className="mr-2" />
                  Create Your First Bot
                </Button>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  );
}
