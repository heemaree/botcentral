# BotCentral Deployment Guide for mc-node

## Prerequisites

1. **Node.js hosting account** on mc-node
2. **PostgreSQL database** (you can use your existing Neon database or set up a new one)
3. **Discord Application** credentials
4. **Domain/subdomain** for your deployment

## Step 1: Prepare Your Files

### Required Environment Variables
Create a `.env` file with these variables:

```env
# Database
DATABASE_URL=your_postgresql_connection_string

# Discord OAuth
DISCORD_CLIENT_ID=1389008016367685723
DISCORD_CLIENT_SECRET=your_discord_client_secret

# Replit Auth (if keeping Replit login)
SESSION_SECRET=your_session_secret_key
ISSUER_URL=https://replit.com/oidc
REPL_ID=your_repl_id

# Production Settings
NODE_ENV=production
PORT=3000
REPLIT_DOMAINS=your_mcnode_domain.com
```

### Files to Upload to mc-node

1. **All source files** (server/, client/, shared/, package.json, etc.)
2. **Environment file** (.env with your credentials)
3. **Build configuration** (already configured in package.json)

## Step 2: Build the Application

Run these commands on mc-node after uploading:

```bash
# Install dependencies
npm install

# Build the application
npm run build

# Push database schema (if needed)
npm run db:push
```

## Step 3: mc-node Configuration

### Start Script
In your mc-node control panel, set the start command to:
```bash
npm start
```

### Domain Setup
1. Point your domain to mc-node servers
2. Update `REPLIT_DOMAINS` in your .env file to match your domain
3. Update Discord OAuth redirect URI to: `https://yourdomain.com/api/discord/callback`

## Step 4: Discord Application Updates

In your Discord Developer Portal:

1. Go to your Discord application (ID: 1389008016367685723)
2. Update OAuth2 Redirect URIs:
   - Remove: `https://replit-domain/api/discord/callback`
   - Add: `https://yourdomain.com/api/discord/callback`
3. Save changes

## Step 5: Database Migration (if needed)

If you want to use a different database:

1. Set up new PostgreSQL database
2. Update `DATABASE_URL` in .env
3. Run: `npm run db:push` to create tables
4. Optionally migrate existing data

## Alternative: Static File Hosting

For better performance, you can serve static files separately:

### Build static files only:
```bash
npx vite build
```

### Upload dist/ folder to CDN/static hosting
### Update server to serve from static location

## Troubleshooting

### Common Issues:

1. **Port conflicts**: Ensure PORT environment variable matches mc-node requirements
2. **Domain mismatch**: Update all OAuth redirect URIs to match your new domain
3. **Database connection**: Verify DATABASE_URL format and accessibility
4. **Session issues**: Generate a new SESSION_SECRET for production

### Health Check
Test your deployment:
- Visit: `https://yourdomain.com/api/auth/user` (should return 401 when not logged in)
- Visit: `https://yourdomain.com` (should show landing page)

## Performance Optimization

1. **Enable gzip compression** in mc-node settings
2. **Set up CDN** for static assets if available
3. **Database connection pooling** (already configured with Neon)
4. **Environment-specific logging** (already configured)

## Security Checklist

- [ ] SESSION_SECRET is unique and secure
- [ ] Discord client secret is not exposed
- [ ] Database credentials are secure
- [ ] HTTPS is enabled
- [ ] CORS is properly configured for your domain

## Monitoring

Monitor these endpoints:
- `GET /api/auth/user` - Authentication health
- `GET /api/discord/connection` - Discord integration health
- `GET /api/dashboard/stats` - Application health

Your BotCentral dashboard will be fully functional on mc-node with all features including Discord OAuth, premium features, and database functionality.